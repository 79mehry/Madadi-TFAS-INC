# Madadi TFAS INC - Professional Accounting Website

A modern, professional accounting and financial services website built with React, TypeScript, and Tailwind CSS.

## 🚀 Features

- **Multi-language Support** (English, Persian, Spanish, French)
- **Smart Accounting Dashboard** with real-time analytics
- **AI-Powered Financial Management**
- **Invoice Management System**
- **Expense Tracking with OCR**
- **Tax Filing Assistant**
- **Subscription Tracker**
- **Client & Employee Portals**
- **Legal Compliance Pages** (PIPEDA, CRA compliant)
- **Beautiful Caramel/Nescafe Theme**

## 🛠️ Tech Stack

- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **Vite** for build tooling
- **Lucide React** for icons
- **Responsive Design**

## 📦 Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Start development server:
```bash
npm run dev
```

4. Build for production:
```bash
npm run build
```

## 🌐 Deployment

### Vercel Deployment:
1. Push code to GitHub
2. Connect repository to Vercel
3. Deploy automatically

### Netlify Deployment:
1. Build the project: `npm run build`
2. Upload `dist` folder to Netlify
3. Configure redirects for SPA

## 🇨🇦 Canadian Compliance

- **CRA Compliant** tax calculations
- **PIPEDA** privacy compliance
- **Alberta Provincial** regulations
- **Calgary-specific** business requirements

## 📄 License

Professional accounting website for Madadi TFAS INC.

## 📞 Contact

- **Email**: info@madadi-tfas.com
- **Phone**: +1 (403) 555-0123
- **Location**: Calgary, Alberta, Canada