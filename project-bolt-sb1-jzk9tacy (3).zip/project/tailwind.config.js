/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Caramel/Nescafe Theme Colors
        caramel: {
          50: '#FDF8F3',
          100: '#F9EDE0',
          200: '#F2D4B3',
          300: '#E8B886',
          400: '#D49C59',
          500: '#C08552', // Main caramel
          600: '#A66B3E',
          700: '#8B5A33',
          800: '#6B4426',
          900: '#4A2F1A'
        },
        nescafe: {
          50: '#FAF7F2',
          100: '#F3EAD9',
          200: '#E6D2B3',
          300: '#D4B08A',
          400: '#C19660',
          500: '#A67C52', // Main nescafe
          600: '#8B6441',
          700: '#6F4F32',
          800: '#533C26',
          900: '#3A2A1C'
        },
        coffee: {
          50: '#F8F6F3',
          100: '#F0EAE3',
          200: '#DDD1C2',
          300: '#C4B29E',
          400: '#A8927A',
          500: '#8B7355', // Coffee brown
          600: '#6F5A44',
          700: '#544235',
          800: '#3D2F26',
          900: '#2A1F19'
        }
      }
    },
  },
  plugins: [],
};