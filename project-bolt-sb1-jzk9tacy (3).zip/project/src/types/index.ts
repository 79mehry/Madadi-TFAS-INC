export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'employee' | 'client';
  avatar?: string;
  phone?: string;
  company?: string;
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface Client extends User {
  role: 'client';
  subscription: 'basic' | 'professional' | 'enterprise';
  subscriptionStatus: 'active' | 'expired' | 'trial';
  nextPayment?: string;
  totalPaid: number;
  documents: Document[];
  tasks: Task[];
}

export interface Employee extends User {
  role: 'employee';
  department: string;
  permissions: string[];
  assignedClients: string[];
}

export interface Task {
  id: string;
  title: string;
  description: string;
  clientId: string;
  assignedTo: string;
  status: 'pending' | 'in-progress' | 'completed' | 'overdue';
  priority: 'low' | 'medium' | 'high';
  dueDate: string;
  createdAt: string;
}

export interface Document {
  id: string;
  name: string;
  type: string;
  size: string;
  uploadDate: string;
  clientId: string;
  category: 'tax' | 'financial' | 'legal' | 'payroll' | 'other';
  status: 'pending' | 'reviewed' | 'approved';
}

export interface SoftwareProduct {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'accounting' | 'payroll' | 'tax' | 'crm';
  features: string[];
  image: string;
  popular: boolean;
}

export interface Subscription {
  id: string;
  name: string;
  price: number;
  billingCycle: 'monthly' | 'annual';
  features: string[];
  popular: boolean;
  discount?: number;
}

export interface WebsiteContent {
  companyName: string;
  phone: string;
  email: string;
  address: string;
  heroTitle: string;
  heroSubtitle: string;
  aboutText: string;
  services: ServiceContent[];
}

export interface ServiceContent {
  id: string;
  title: string;
  description: string;
  image: string;
  features: string[];
  price?: number;
}

// Smart Accounting Features Types
export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  currency: string;
  category: string;
  type: 'income' | 'expense';
  bankAccount?: string;
  isRecurring?: boolean;
  tags?: string[];
  status: 'pending' | 'completed' | 'cancelled';
  clientId: string;
}

export interface BankAccount {
  id: string;
  bankName: string;
  accountNumber: string;
  accountType: 'checking' | 'savings' | 'credit';
  balance: number;
  currency: string;
  isConnected: boolean;
  lastSync: string;
  clientId: string;
}

export interface FinancialReport {
  id: string;
  type: 'monthly' | 'quarterly' | 'annual' | 'custom';
  period: {
    start: string;
    end: string;
  };
  totalIncome: number;
  totalExpenses: number;
  netIncome: number;
  categoryBreakdown: CategoryBreakdown[];
  trends: TrendData[];
  clientId: string;
  generatedAt: string;
}

export interface CategoryBreakdown {
  category: string;
  amount: number;
  percentage: number;
  transactions: number;
}

export interface TrendData {
  period: string;
  income: number;
  expenses: number;
  netIncome: number;
}

export interface Reminder {
  id: string;
  title: string;
  description: string;
  type: 'payment' | 'tax' | 'recurring' | 'deadline';
  dueDate: string;
  amount?: number;
  currency?: string;
  isRecurring: boolean;
  frequency?: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'annually';
  status: 'active' | 'completed' | 'snoozed';
  priority: 'low' | 'medium' | 'high';
  clientId: string;
  createdAt: string;
}

export interface Currency {
  code: string;
  name: string;
  symbol: string;
  rate: number; // Exchange rate to base currency (CAD)
}

export interface SmartCategory {
  id: string;
  name: string;
  keywords: string[];
  type: 'income' | 'expense';
  parentCategory?: string;
  taxDeductible: boolean;
  businessExpense: boolean;
}

// New Advanced Features Types
export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientName: string;
  clientEmail: string;
  clientAddress: string;
  amount: number;
  currency: string;
  status: 'draft' | 'sent' | 'paid' | 'overdue';
  issueDate: string;
  dueDate: string;
  items: InvoiceItem[];
  notes?: string;
  taxRate: number;
  discount: number;
}

export interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  rate: number;
  amount: number;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  currency: string;
  category: string;
  date: string;
  receiptUrl?: string;
  paymentMethod: string;
  vendor: string;
  taxDeductible: boolean;
  status: 'pending' | 'approved' | 'rejected';
  tags: string[];
  notes?: string;
}

export interface TaxFiling {
  id: string;
  taxYear: number;
  filingType: 'personal' | 'corporate' | 'gst' | 'payroll';
  status: 'draft' | 'review' | 'filed' | 'accepted';
  dueDate: string;
  estimatedRefund?: number;
  estimatedOwing?: number;
  documents: string[];
  deductions: TaxDeduction[];
  clientId: string;
}

export interface TaxDeduction {
  id: string;
  category: string;
  description: string;
  amount: number;
  supportingDocuments: string[];
}

export interface RecurringPayment {
  id: string;
  name: string;
  amount: number;
  currency: string;
  frequency: 'weekly' | 'monthly' | 'quarterly' | 'annually';
  nextPaymentDate: string;
  category: string;
  vendor: string;
  status: 'active' | 'paused' | 'cancelled';
  autoRenewal: boolean;
  reminderDays: number;
  clientId: string;
}

export interface FinancialGoal {
  id: string;
  title: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  category: 'savings' | 'investment' | 'debt' | 'purchase' | 'emergency';
  priority: 'low' | 'medium' | 'high';
  status: 'active' | 'completed' | 'paused';
  milestones: GoalMilestone[];
  clientId: string;
}

export interface GoalMilestone {
  id: string;
  title: string;
  targetAmount: number;
  targetDate: string;
  completed: boolean;
  completedDate?: string;
}

export interface FinancialHealthScore {
  id: string;
  overallScore: number;
  categories: {
    budgeting: number;
    savings: number;
    debt: number;
    investments: number;
    emergency: number;
  };
  recommendations: string[];
  lastCalculated: string;
  clientId: string;
}

export interface AIAdvice {
  id: string;
  type: 'spending' | 'saving' | 'investment' | 'tax' | 'general';
  title: string;
  advice: string;
  priority: 'low' | 'medium' | 'high';
  actionItems: string[];
  estimatedImpact: string;
  createdAt: string;
  clientId: string;
}

export interface JobPosting {
  id: string;
  title: string;
  description: string;
  budget: {
    min: number;
    max: number;
    currency: string;
    type: 'fixed' | 'hourly';
  };
  skills: string[];
  duration: string;
  location: 'remote' | 'onsite' | 'hybrid';
  clientId: string;
  status: 'open' | 'in-progress' | 'completed' | 'cancelled';
  proposals: JobProposal[];
  postedDate: string;
  deadline?: string;
}

export interface JobProposal {
  id: string;
  freelancerId: string;
  coverLetter: string;
  proposedRate: number;
  estimatedDuration: string;
  portfolio: string[];
  status: 'pending' | 'accepted' | 'rejected';
  submittedDate: string;
}

export interface FreelancerProfile {
  id: string;
  userId: string;
  title: string;
  description: string;
  skills: string[];
  hourlyRate: number;
  availability: 'full-time' | 'part-time' | 'contract';
  portfolio: PortfolioItem[];
  reviews: Review[];
  rating: number;
  completedJobs: number;
}

export interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  images: string[];
  technologies: string[];
  projectUrl?: string;
  completedDate: string;
}

export interface Review {
  id: string;
  clientId: string;
  rating: number;
  comment: string;
  projectTitle: string;
  createdDate: string;
}

export interface Domain {
  id: string;
  name: string;
  tld: string;
  registrationDate: string;
  expirationDate: string;
  autoRenewal: boolean;
  privacyProtection: boolean;
  transferLock: boolean;
  status: 'active' | 'expired' | 'pending';
  nameservers: string[];
  dnsRecords: DnsRecord[];
}

export interface DnsRecord {
  id: string;
  type: 'A' | 'AAAA' | 'CNAME' | 'MX' | 'TXT' | 'NS' | 'SRV' | 'CAA';
  name: string;
  value: string;
  ttl: number;
  priority?: number;
}

export interface DomainSearch {
  domain: string;
  tld: string;
  available: boolean;
  price: number;
  currency: string;
  premium: boolean;
}
export interface ReferralProgram {
  id: string;
  referrerId: string;
  referredUserId?: string;
  referralCode: string;
  status: 'pending' | 'completed' | 'expired';
  reward: {
    type: 'credit' | 'discount' | 'cash';
    amount: number;
    currency?: string;
  };
  createdDate: string;
  completedDate?: string;
}

export interface EducationalResource {
  id: string;
  title: string;
  description: string;
  content: string;
  category: 'financial' | 'tax' | 'business' | 'marketing' | 'legal';
  type: 'article' | 'video' | 'pdf' | 'webinar';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedReadTime: number;
  tags: string[];
  author: string;
  publishedDate: string;
  views: number;
  likes: number;
}

export interface CommunityPost {
  id: string;
  authorId: string;
  title: string;
  content: string;
  category: 'question' | 'discussion' | 'tip' | 'success-story';
  tags: string[];
  likes: number;
  replies: CommunityReply[];
  createdDate: string;
  lastActivity: string;
}

export interface CommunityReply {
  id: string;
  authorId: string;
  content: string;
  likes: number;
  createdDate: string;
  parentReplyId?: string;
}

export interface AutomationRule {
  id: string;
  name: string;
  description: string;
  trigger: {
    type: 'date' | 'amount' | 'category' | 'client';
    condition: string;
    value: any;
  };
  action: {
    type: 'send-email' | 'create-invoice' | 'send-reminder' | 'categorize';
    parameters: any;
  };
  isActive: boolean;
  lastRun?: string;
  clientId: string;
}

export interface CustomReport {
  id: string;
  name: string;
  description: string;
  reportType: 'profit-loss' | 'cash-flow' | 'tax-summary' | 'expense-analysis' | 'custom';
  filters: {
    dateRange: { start: string; end: string };
    categories: string[];
    accounts: string[];
    tags: string[];
  };
  metrics: string[];
  visualization: 'table' | 'chart' | 'graph' | 'mixed';
  schedule?: {
    frequency: 'daily' | 'weekly' | 'monthly' | 'quarterly';
    recipients: string[];
  };
  clientId: string;
  createdDate: string;
}