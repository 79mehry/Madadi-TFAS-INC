import React, { useState } from 'react';
import { 
  Users, 
  FileText, 
  DollarSign, 
  Settings, 
  BarChart3, 
  Calendar,
  Package,
  Edit3,
  Plus,
  Search,
  Filter,
  Download,
  Upload,
  Bell,
  TrendingUp,
  UserCheck,
 Clock,
 Shield,
 Key,
 Eye,
 EyeOff,
 Lock,
 AlertTriangle,
 Image,
 Type,
 CreditCard,
 Globe
} from 'lucide-react';
import MediaManager from './MediaManager';
import ContentEditor from './ContentEditor';

interface AdminPanelProps {
  onBack: () => void;
}

const AdminPanel: React.FC<AdminPanelProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
 const [showPasswords, setShowPasswords] = useState<{[key: string]: boolean}>({});
 const [showUserModal, setShowUserModal] = useState(false);
 const [selectedUser, setSelectedUser] = useState<any>(null);
 const [userModalType, setUserModalType] = useState<'add' | 'edit' | 'password'>('add');

  // Mock data
  const stats = {
    totalClients: 156,
    activeEmployees: 8,
    monthlyRevenue: 45600,
    pendingTasks: 23,
    completedTasks: 187,
    newClients: 12
  };

  const recentClients = [
    { id: '1', name: 'ABC Corp', email: 'contact@abc.com', subscription: 'Professional', status: 'active', joinDate: '2024-01-15' },
    { id: '2', name: 'XYZ Ltd', email: 'info@xyz.com', subscription: 'Enterprise', status: 'active', joinDate: '2024-01-10' },
    { id: '3', name: 'StartUp Inc', email: 'hello@startup.com', subscription: 'Basic', status: 'trial', joinDate: '2024-01-20' }
  ];

  const employees = [
    { id: '1', name: 'Sarah Johnson', email: 'sarah@madadi-tfas.com', department: 'Tax Services', clients: 25, status: 'active' },
    { id: '2', name: 'Mike Chen', email: 'mike@madadi-tfas.com', department: 'Bookkeeping', clients: 30, status: 'active' },
    { id: '3', name: 'Lisa Rodriguez', email: 'lisa@madadi-tfas.com', department: 'Consulting', clients: 18, status: 'active' }
  ];

 const systemUsers = [
   { 
     id: '1', 
     username: 'admin', 
     email: 'admin@madadi-tfas.com', 
     role: 'admin', 
     name: 'System Administrator',
     lastLogin: '2024-01-15 10:30 AM',
     status: 'active',
     permissions: ['all']
   },
   { 
     id: '2', 
     username: 'manager01', 
     email: 'manager@madadi-tfas.com', 
     role: 'manager', 
     name: 'John Manager',
     lastLogin: '2024-01-14 2:15 PM',
     status: 'active',
     permissions: ['clients', 'employees', 'reports']
   },
   { 
     id: '3', 
     username: 'sarah.j', 
     email: 'sarah@madadi-tfas.com', 
     role: 'employee', 
     name: 'Sarah Johnson',
     lastLogin: '2024-01-15 9:45 AM',
     status: 'active',
     permissions: ['clients', 'tasks']
   }
 ];

 const handleUserAction = (action: 'add' | 'edit' | 'password', user?: any) => {
   setUserModalType(action);
   setSelectedUser(user || null);
   setShowUserModal(true);
 };

 const togglePasswordVisibility = (userId: string) => {
   setShowPasswords(prev => ({
     ...prev,
     [userId]: !prev[userId]
   }));
 };
  const subscriptionPlans = [
    {
      name: 'Basic',
      monthlyPrice: 99,
      annualPrice: 990,
      features: ['Monthly Bookkeeping', 'Tax Filing', 'Basic Support'],
      clients: 45
    },
    {
      name: 'Professional',
      monthlyPrice: 199,
      annualPrice: 1990,
      features: ['Weekly Bookkeeping', 'Tax Planning', 'Payroll Services', 'Priority Support'],
      clients: 78
    },
    {
      name: 'Enterprise',
      monthlyPrice: 399,
      annualPrice: 3990,
      features: ['Daily Bookkeeping', 'Full Tax Services', 'Payroll & HR', 'Dedicated Manager', '24/7 Support'],
      clients: 33
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-caramel-50 to-nescafe-50">
      <div className="bg-white shadow-sm border-b border-caramel-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-caramel-600 hover:text-caramel-700 transition-colors font-medium"
              >
                ← Back to Website
              </button>
              <h1 className="text-2xl font-bold text-coffee-900">Admin Panel</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="w-6 h-6 text-coffee-600" />
                <span className="absolute -top-2 -right-2 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">5</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-caramel-100 to-caramel-200 rounded-full flex items-center justify-center">
                  <span className="text-caramel-600 font-semibold">A</span>
                </div>
                <span className="text-coffee-700 font-medium">Admin</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-caramel-200">
          <div className="border-b border-caramel-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
                { id: 'clients', label: 'Clients', icon: Users },
                { id: 'employees', label: 'Employees', icon: UserCheck },
                { id: 'subscriptions', label: 'Subscriptions', icon: DollarSign },
                { id: 'software', label: 'Software Sales', icon: Package },
                { id: 'content', label: 'Website Content', icon: Edit3 },
                { id: 'domains', label: 'Domain Management', icon: Globe },
                { id: 'security', label: 'Security & Users', icon: Shield },
                { id: 'settings', label: 'Settings', icon: Settings }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 font-medium text-sm flex items-center space-x-2 transition-colors ${
                    activeTab === tab.id
                      ? 'text-caramel-600 border-b-2 border-caramel-600'
                      : 'text-coffee-500 hover:text-coffee-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-xl text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-100">Total Clients</p>
                        <p className="text-3xl font-bold">{stats.totalClients}</p>
                      </div>
                      <Users className="w-8 h-8 text-blue-200" />
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-green-500 to-green-600 p-6 rounded-xl text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-100">Monthly Revenue</p>
                        <p className="text-3xl font-bold">${stats.monthlyRevenue.toLocaleString()}</p>
                      </div>
                      <DollarSign className="w-8 h-8 text-green-200" />
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-6 rounded-xl text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-amber-100">Pending Tasks</p>
                        <p className="text-3xl font-bold">{stats.pendingTasks}</p>
                      </div>
                      <Clock className="w-8 h-8 text-amber-200" />
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-6 rounded-xl text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-100">New Clients</p>
                        <p className="text-3xl font-bold">{stats.newClients}</p>
                      </div>
                      <TrendingUp className="w-8 h-8 text-purple-200" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Clients</h3>
                    <div className="space-y-4">
                      {recentClients.map((client) => (
                        <div key={client.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900">{client.name}</p>
                            <p className="text-sm text-gray-600">{client.email}</p>
                          </div>
                          <div className="text-right">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              client.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {client.status}
                            </span>
                            <p className="text-sm text-gray-600 mt-1">{client.subscription}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Subscription Distribution</h3>
                    <div className="space-y-4">
                      {subscriptionPlans.map((plan) => (
                        <div key={plan.name} className="flex items-center justify-between">
                          <span className="text-gray-700">{plan.name}</span>
                          <div className="flex items-center space-x-2">
                            <div className="w-24 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-amber-600 h-2 rounded-full" 
                                style={{ width: `${(plan.clients / stats.totalClients) * 100}%` }}
                              ></div>
                            </div>
                            <span className="text-sm text-gray-600">{plan.clients}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'clients' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">Client Management</h3>
                  <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2">
                    <Plus className="w-4 h-4" />
                    <span>Add Client</span>
                  </button>
                </div>
                
                <div className="flex space-x-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search clients..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    />
                  </div>
                  <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <Filter className="w-4 h-4" />
                    <span>Filter</span>
                  </button>
                  <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <Download className="w-4 h-4" />
                    <span>Export</span>
                  </button>
                </div>

                <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Subscription</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Join Date</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {recentClients.map((client) => (
                        <tr key={client.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-gray-900">{client.name}</div>
                              <div className="text-sm text-gray-500">{client.email}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{client.subscription}</td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              client.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {client.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.joinDate}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button className="text-amber-600 hover:text-amber-900 mr-3">Edit</button>
                            <button className="text-red-600 hover:text-red-900">Delete</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'subscriptions' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">Subscription Plans</h3>
                  <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                    Update Pricing
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {subscriptionPlans.map((plan) => (
                    <div key={plan.name} className="bg-white border border-gray-200 rounded-xl p-6">
                      <div className="text-center mb-6">
                        <h4 className="text-xl font-bold text-gray-900 mb-2">{plan.name}</h4>
                        <div className="mb-4">
                          <span className="text-3xl font-bold text-gray-900">${plan.monthlyPrice}</span>
                          <span className="text-gray-600">/month</span>
                        </div>
                        <div className="text-sm text-gray-600">
                          Annual: ${plan.annualPrice} (Save ${(plan.monthlyPrice * 12) - plan.annualPrice})
                        </div>
                      </div>
                      
                      <ul className="space-y-3 mb-6">
                        {plan.features.map((feature, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-amber-600 rounded-full"></div>
                            <span className="text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>
                      
                      <div className="text-center">
                        <p className="text-sm text-gray-600 mb-3">{plan.clients} active clients</p>
                        <button className="w-full bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition-colors">
                          Edit Plan
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'content' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Website Content Management</h3>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h4 className="font-semibold text-gray-900 mb-4">Company Information</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Company Name</label>
                        <input
                          type="text"
                          defaultValue="Madadi TFAS INC"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                        <input
                          type="text"
                          defaultValue="+1 (403) 555-0123"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                        <input
                          type="email"
                          defaultValue="info@madadi-tfas.com"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
                        <input
                          type="text"
                          defaultValue="Calgary, Alberta, Canada"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h4 className="font-semibold text-gray-900 mb-4">Hero Section</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Main Title</label>
                        <input
                          type="text"
                          defaultValue="Precision in Numbers, Vision in Finance"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Subtitle</label>
                        <textarea
                          defaultValue="Madadi Financial and Accounting Services INC"
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Hero Image</label>
                        <div className="flex items-center space-x-3">
                          <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                            <Upload className="w-4 h-4" />
                            <span>Upload Image</span>
                          </button>
                          <span className="text-sm text-gray-500">Current: hero-bg.jpg</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Payment Settings */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                    <CreditCard className="w-5 h-5 text-amber-600" />
                    <span>Payment Settings</span>
                  </h4>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Bank Account Name</label>
                        <input
                          type="text"
                          placeholder="Madadi TFAS INC"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Bank Account Number</label>
                        <input
                          type="text"
                          placeholder="1234567890"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Routing Number</label>
                        <input
                          type="text"
                          placeholder="123456789"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Stripe Secret Key</label>
                        <input
                          type="password"
                          placeholder="sk_live_..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Stripe Publishable Key</label>
                        <input
                          type="text"
                          placeholder="pk_live_..."
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">PayPal Business Email</label>
                        <input
                          type="email"
                          placeholder="business@madadi-tfas.com"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-blue-700">
                      <strong>Payment Integration:</strong> Connect Stripe or PayPal to automatically process payments. 
                      All subscription and software purchase payments will be sent directly to your connected account.
                    </p>
                  </div>
                </div>

                {/* Software Management */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                      <Package className="w-5 h-5 text-amber-600" />
                      <span>Software Products Management</span>
                    </h4>
                    <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                      Add New Software
                    </button>
                  </div>
                  <div className="space-y-4">
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h5 className="font-medium text-gray-900">QuickBooks Pro 2024</h5>
                          <p className="text-sm text-gray-600">Complete accounting solution</p>
                          <div className="flex items-center space-x-4 mt-2">
                            <span className="text-lg font-bold text-amber-600">$299</span>
                            <span className="text-sm text-gray-500 line-through">$399</span>
                            <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs">Popular</span>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button className="text-amber-600 hover:text-amber-700 px-3 py-1 border border-amber-600 rounded">
                            Edit
                          </button>
                          <button className="text-red-600 hover:text-red-700 px-3 py-1 border border-red-600 rounded">
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h5 className="font-medium text-gray-900">Sage 50 Accounting</h5>
                          <p className="text-sm text-gray-600">Advanced accounting software</p>
                          <div className="flex items-center space-x-4 mt-2">
                            <span className="text-lg font-bold text-amber-600">$449</span>
                            <span className="text-sm text-gray-500 line-through">$549</span>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button className="text-amber-600 hover:text-amber-700 px-3 py-1 border border-amber-600 rounded">
                            Edit
                          </button>
                          <button className="text-red-600 hover:text-red-700 px-3 py-1 border border-red-600 rounded">
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="font-semibold text-gray-900">Services Management</h4>
                    <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                      Add Service
                    </button>
                  </div>
                  <div className="text-sm text-gray-600">
                    Click on any service to edit its content, images, and pricing.
                  </div>
                </div>

                <div className="flex justify-end space-x-4">
                  <button className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    Preview Changes
                  </button>
                  <button className="bg-amber-600 text-white px-6 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                    Save Changes
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'domains' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">Domain Management</h3>
                  <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2">
                    <Plus className="w-4 h-4" />
                    <span>Purchase New Domain</span>
                  </button>
                </div>
                
                {/* Current Domain */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                        <Globe className="w-5 h-5 text-amber-600" />
                        <span>Current Domain</span>
                      </h4>
                      <p className="text-gray-600 mt-1">Your website is currently accessible at:</p>
                    </div>
                    <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">Active</span>
                  </div>
                  
                  <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg mb-4">
                    <span className="text-xl font-medium text-gray-900">madadi-tfas.com</span>
                    <button className="text-blue-600 hover:text-blue-700 text-sm">
                      Manage DNS
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div className="border border-gray-200 rounded-lg p-3">
                      <p className="text-sm font-medium text-gray-700">Registration Date</p>
                      <p className="text-gray-900">January 15, 2024</p>
                    </div>
                    <div className="border border-gray-200 rounded-lg p-3">
                      <p className="text-sm font-medium text-gray-700">Expiration Date</p>
                      <p className="text-gray-900">January 15, 2025</p>
                    </div>
                    <div className="border border-gray-200 rounded-lg p-3">
                      <p className="text-sm font-medium text-gray-700">Auto-Renewal</p>
                      <p className="text-green-600">Enabled</p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button className="text-amber-600 hover:text-amber-700 px-3 py-1 border border-amber-600 rounded">
                      Renew Domain
                    </button>
                    <button className="text-blue-600 hover:text-blue-700 px-3 py-1 border border-blue-600 rounded">
                      Update Contact Info
                    </button>
                    <button className="text-purple-600 hover:text-purple-700 px-3 py-1 border border-purple-600 rounded">
                      Transfer Domain
                    </button>
                  </div>
                </div>
                
                {/* Domain Search */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Search for New Domain</h4>
                  <div className="flex space-x-2 mb-6">
                    <input
                      type="text"
                      placeholder="Enter domain name (e.g., calgarytaxfinance)"
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    />
                    <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500">
                      <option value=".com">.com</option>
                      <option value=".ca">.ca</option>
                      <option value=".net">.net</option>
                      <option value=".org">.org</option>
                      <option value=".io">.io</option>
                    </select>
                    <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                      Search
                    </button>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <h5 className="font-medium text-gray-900">calgarytaxfinance.com</h5>
                          <p className="text-sm text-gray-600">Perfect for your tax and finance services</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-gray-900">$14.99/year</p>
                          <button className="mt-2 bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition-colors text-sm">
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <h5 className="font-medium text-gray-900">calgarytaxfinance.ca</h5>
                          <p className="text-sm text-gray-600">Canadian domain for local business</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-gray-900">$19.99/year</p>
                          <button className="mt-2 bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition-colors text-sm">
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <h5 className="font-medium text-gray-900">calgarytaxfinance.net</h5>
                          <p className="text-sm text-gray-600">Alternative domain option</p>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-gray-900">$12.99/year</p>
                          <button className="mt-2 bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition-colors text-sm">
                            Add to Cart
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* DNS Management */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">DNS Management</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Value</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">TTL</th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        <tr>
                          <td className="px-4 py-3 text-sm text-gray-900">A</td>
                          <td className="px-4 py-3 text-sm text-gray-900">@</td>
                          <td className="px-4 py-3 text-sm text-gray-900">192.168.1.1</td>
                          <td className="px-4 py-3 text-sm text-gray-900">3600</td>
                          <td className="px-4 py-3 text-sm">
                            <button className="text-amber-600 hover:text-amber-700 mr-2">Edit</button>
                            <button className="text-red-600 hover:text-red-700">Delete</button>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 text-sm text-gray-900">CNAME</td>
                          <td className="px-4 py-3 text-sm text-gray-900">www</td>
                          <td className="px-4 py-3 text-sm text-gray-900">@</td>
                          <td className="px-4 py-3 text-sm text-gray-900">3600</td>
                          <td className="px-4 py-3 text-sm">
                            <button className="text-amber-600 hover:text-amber-700 mr-2">Edit</button>
                            <button className="text-red-600 hover:text-red-700">Delete</button>
                          </td>
                        </tr>
                        <tr>
                          <td className="px-4 py-3 text-sm text-gray-900">MX</td>
                          <td className="px-4 py-3 text-sm text-gray-900">@</td>
                          <td className="px-4 py-3 text-sm text-gray-900">mail.madadi-tfas.com</td>
                          <td className="px-4 py-3 text-sm text-gray-900">3600</td>
                          <td className="px-4 py-3 text-sm">
                            <button className="text-amber-600 hover:text-amber-700 mr-2">Edit</button>
                            <button className="text-red-600 hover:text-red-700">Delete</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  <div className="mt-4">
                    <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                      Add DNS Record
                    </button>
                  </div>
                </div>
                
                {/* Domain Settings */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-semibold text-gray-900 mb-4">Domain Settings</h4>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Domain Privacy Protection</label>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">WHOIS Privacy</p>
                          <p className="text-sm text-gray-600">Hide your personal information from public WHOIS database</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                        </label>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Auto-Renewal</label>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Automatic Domain Renewal</p>
                          <p className="text-sm text-gray-600">Renew domain automatically before expiration</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                        </label>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Domain Lock</label>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-gray-900">Transfer Lock</p>
                          <p className="text-sm text-gray-600">Prevent unauthorized domain transfers</p>
                        </div>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-amber-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-amber-600"></div>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Account Settings</h3>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* User Management Modal */}
      {showUserModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              {userModalType === 'add' ? 'Add New User' : 
               userModalType === 'edit' ? 'Edit User' : 'Reset Password'}
            </h3>
            
            <div className="space-y-4">
              {userModalType !== 'password' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                    <input
                      type="text"
                      defaultValue={selectedUser?.name || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Username</label>
                    <input
                      type="text"
                      defaultValue={selectedUser?.username || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      placeholder="john.doe"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input
                      type="email"
                      defaultValue={selectedUser?.email || ''}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      placeholder="john@madadi-tfas.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
                    <select 
                      defaultValue={selectedUser?.role || 'employee'}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    >
                      <option value="employee">Employee</option>
                      <option value="manager">Manager</option>
                      <option value="admin">Administrator</option>
                    </select>
                  </div>
                </>
              )}
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  {userModalType === 'password' ? 'New Password' : 'Password'}
                </label>
                <div className="relative">
                  <input
                    type={showPasswords['modal'] ? 'text' : 'password'}
                    className="w-full px-3 py-2 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    placeholder="Enter secure password"
                  />
                  <button
                    type="button"
                    onClick={() => togglePasswordVisibility('modal')}
                    className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
                  >
                    {showPasswords['modal'] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              
              {userModalType !== 'password' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                  <input
                    type="password"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    placeholder="Confirm password"
                  />
                </div>
              )}
            </div>
            
            {userModalType === 'password' && (
              <div className="mt-4 p-4 bg-amber-50 rounded-lg">
                <p className="text-sm text-amber-700">
                  <strong>Security Note:</strong> The user will be required to change this password on their next login.
                </p>
              </div>
            )}
            
            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowUserModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  // Handle save logic here
                  setShowUserModal(false);
                }}
                className="flex-1 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors"
              >
                {userModalType === 'add' ? 'Create User' : 
                 userModalType === 'edit' ? 'Save Changes' : 'Reset Password'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;