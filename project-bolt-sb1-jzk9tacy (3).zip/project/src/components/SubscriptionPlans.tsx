import React, { useState } from 'react';
import { Check, Star, ArrowRight, CreditCard, Shield, Headphones, Clock } from 'lucide-react';

interface SubscriptionPlansProps {
  onBack: () => void;
}

const SubscriptionPlans: React.FC<SubscriptionPlansProps> = ({ onBack }) => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'annual'>('monthly');

  const plans = [
    {
      id: 'basic',
      name: 'Basic',
      description: 'Perfect for small businesses just getting started',
      monthlyPrice: 99,
      annualPrice: 990,
      originalMonthlyPrice: 129,
      originalAnnualPrice: 1290,
      popular: false,
      features: [
        'Monthly Bookkeeping (up to 50 transactions)',
        'Basic Financial Statements',
        'Personal Tax Return Filing',
        'GST/HST Return (Quarterly)',
        'Email Support (Business Hours)',
        'Basic Tax Planning Consultation',
        'Document Storage (5GB)',
        'Mobile App Access'
      ],
      limitations: [
        'Limited to 50 transactions per month',
        'Basic reporting only',
        'Email support only'
      ],
      clientCount: 45,
      savings: billingCycle === 'annual' ? 300 : 30
    },
    {
      id: 'professional',
      name: 'Professional',
      description: 'Ideal for growing businesses with regular financial needs',
      monthlyPrice: 199,
      annualPrice: 1990,
      originalMonthlyPrice: 249,
      originalAnnualPrice: 2490,
      popular: true,
      features: [
        'Weekly Bookkeeping (up to 200 transactions)',
        'Comprehensive Financial Statements',
        'Personal & Corporate Tax Filing',
        'Monthly GST/HST Returns',
        'Payroll Services (up to 10 employees)',
        'Priority Phone & Email Support',
        'Quarterly Business Review',
        'Advanced Tax Planning',
        'Document Storage (25GB)',
        'Financial Dashboard Access',
        'Cash Flow Forecasting',
        'Expense Management Tools'
      ],
      limitations: [
        'Limited to 200 transactions per month',
        'Up to 10 employees for payroll'
      ],
      clientCount: 78,
      savings: billingCycle === 'annual' ? 500 : 50
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      description: 'Complete solution for established businesses',
      monthlyPrice: 399,
      annualPrice: 3990,
      originalMonthlyPrice: 499,
      originalAnnualPrice: 4990,
      popular: false,
      features: [
        'Daily Bookkeeping (Unlimited transactions)',
        'Full Financial Statement Package',
        'Complete Tax Services (All types)',
        'Monthly GST/HST & Payroll Remittances',
        'Unlimited Payroll Services',
        'Dedicated Account Manager',
        '24/7 Priority Support',
        'Monthly Strategy Sessions',
        'Advanced Tax Optimization',
        'Unlimited Document Storage',
        'Custom Financial Reporting',
        'Business Intelligence Dashboard',
        'Multi-location Support',
        'API Integration Support',
        'Compliance Monitoring',
        'Audit Preparation Assistance'
      ],
      limitations: [],
      clientCount: 33,
      savings: billingCycle === 'annual' ? 1000 : 100
    }
  ];

  const addOns = [
    { name: 'Additional Employee (Payroll)', price: 15, unit: 'per employee/month' },
    { name: 'Extra Transaction Block (100)', price: 25, unit: 'per month' },
    { name: 'Bookkeeping Software Setup', price: 150, unit: 'one-time' },
    { name: 'Financial Consultation (1 hour)', price: 120, unit: 'per session' },
    { name: 'Audit Preparation', price: 500, unit: 'per audit' },
    { name: 'Business Registration Service', price: 300, unit: 'one-time' }
  ];

  const testimonials = [
    {
      name: 'Sarah Chen',
      company: 'Tech Startup Inc.',
      plan: 'Professional',
      text: 'Madadi TFAS has been incredible. Their professional plan gives us everything we need to focus on growing our business.',
      rating: 5
    },
    {
      name: 'Mike Rodriguez',
      company: 'Rodriguez Construction',
      plan: 'Enterprise',
      text: 'The enterprise plan with dedicated support has saved us countless hours. Best investment we\'ve made.',
      rating: 5
    },
    {
      name: 'Lisa Thompson',
      company: 'Boutique Consulting',
      plan: 'Basic',
      text: 'Perfect for our small consulting firm. Great value and excellent service quality.',
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-amber-600 hover:text-amber-700 transition-colors"
              >
                ← Back to Website
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Subscription Plans</h1>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Choose Your <span className="text-amber-600">Perfect Plan</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Professional accounting services tailored to your business size and needs. 
            All plans include expert support and Canadian tax compliance.
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center space-x-4 mb-8">
            <span className={`${billingCycle === 'monthly' ? 'text-gray-900' : 'text-gray-500'}`}>Monthly</span>
            <button
              onClick={() => setBillingCycle(billingCycle === 'monthly' ? 'annual' : 'monthly')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                billingCycle === 'annual' ? 'bg-amber-600' : 'bg-gray-300'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  billingCycle === 'annual' ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
            <span className={`${billingCycle === 'annual' ? 'text-gray-900' : 'text-gray-500'}`}>
              Annual
              <span className="ml-1 bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                Save up to 20%
              </span>
            </span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan) => (
            <div
              key={plan.id}
              className={`relative rounded-2xl shadow-xl overflow-hidden transition-all hover:shadow-2xl ${
                plan.popular 
                  ? 'bg-gradient-to-br from-amber-50 to-orange-50 ring-2 ring-amber-400 scale-105 transform' 
                  : 'bg-white hover:scale-102'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-amber-500 to-orange-500 text-white text-center py-3 text-sm font-bold">
                  <div className="flex items-center justify-center space-x-2">
                    <Star className="w-4 h-4" />
                    <span>Most Popular Choice</span>
                    <Star className="w-4 h-4" />
                  </div>
                </div>
              )}

              <div className={`p-8 ${plan.popular ? 'pt-16' : 'pt-8'}`}>
                <div className="text-center mb-8">
                  <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
                    plan.popular 
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500' 
                      : plan.id === 'basic' 
                        ? 'bg-gradient-to-r from-blue-500 to-blue-600'
                        : 'bg-gradient-to-r from-purple-500 to-purple-600'
                  }`}>
                    <span className="text-2xl font-bold text-white">
                      {plan.id === 'basic' ? 'B' : plan.id === 'professional' ? 'P' : 'E'}
                    </span>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-6">{plan.description}</p>
                  
                  <div className="mb-6">
                    <div className="flex items-center justify-center space-x-2 mb-2">
                      <span className={`text-5xl font-bold ${
                        plan.popular ? 'text-amber-600' : 'text-gray-900'
                      }`}>
                        ${billingCycle === 'monthly' ? plan.monthlyPrice : Math.round(plan.annualPrice / 12)}
                      </span>
                      <div className="text-left">
                        <div className="text-gray-600 text-lg">/month</div>
                        {billingCycle === 'annual' && (
                          <div className="text-sm text-gray-500">billed annually</div>
                        )}
                      </div>
                    </div>
                    
                    {billingCycle === 'annual' && (
                      <div className="text-center">
                        <span className="text-xl text-gray-500 line-through">
                          ${billingCycle === 'monthly' ? plan.originalMonthlyPrice : plan.originalAnnualPrice}
                        </span>
                        <span className="ml-3 bg-gradient-to-r from-emerald-500 to-teal-500 text-white px-3 py-1 rounded-full text-sm font-bold">
                          Save ${plan.savings}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className={`text-sm mb-6 px-4 py-2 rounded-full ${
                    plan.popular 
                      ? 'bg-amber-100 text-amber-800' 
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    {plan.clientCount} businesses trust this plan
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  <h5 className="font-semibold text-gray-900 text-center mb-4">Everything included:</h5>
                  <ul className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center mt-0.5 flex-shrink-0 ${
                          plan.popular 
                            ? 'bg-amber-100' 
                            : 'bg-gray-100'
                        }`}>
                          <Check className={`w-3 h-3 ${
                            plan.popular ? 'text-amber-600' : 'text-gray-600'
                          }`} />
                        </div>
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {plan.limitations.length > 0 && (
                  <div className="mb-6 p-4 bg-gray-50 rounded-xl">
                    <h5 className="text-sm font-medium text-gray-900 mb-2">Plan Limitations:</h5>
                    <ul className="space-y-1">
                      {plan.limitations.map((limitation, index) => (
                        <li key={index} className="text-xs text-gray-600 flex items-center space-x-2">
                          <div className="w-1 h-1 bg-gray-400 rounded-full"></div>
                          <span>{limitation}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <button
                  className={`w-full py-4 rounded-xl font-bold text-lg transition-all transform hover:scale-105 shadow-lg ${
                    plan.popular
                      ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:from-amber-600 hover:to-orange-600 shadow-amber-200'
                      : 'bg-gradient-to-r from-gray-800 to-gray-900 text-white hover:from-gray-700 hover:to-gray-800'
                  }`}
                >
                  Get Started Today
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Add-ons Section */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Optional Add-ons</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {addOns.map((addon, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-2">{addon.name}</h4>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-amber-600">${addon.price}</span>
                  <span className="text-sm text-gray-600">{addon.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">What Our Clients Say</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4">"{testimonial.text}"</p>
                <div>
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.company}</div>
                  <div className="text-xs text-amber-600 font-medium">{testimonial.plan} Plan</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Features Comparison */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">Plan Comparison</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-4">Features</th>
                  <th className="text-center py-4 px-4">Basic</th>
                  <th className="text-center py-4 px-4">Professional</th>
                  <th className="text-center py-4 px-4">Enterprise</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="py-4 px-4 font-medium">Monthly Transactions</td>
                  <td className="py-4 px-4 text-center">50</td>
                  <td className="py-4 px-4 text-center">200</td>
                  <td className="py-4 px-4 text-center">Unlimited</td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-medium">Payroll Employees</td>
                  <td className="py-4 px-4 text-center">-</td>
                  <td className="py-4 px-4 text-center">10</td>
                  <td className="py-4 px-4 text-center">Unlimited</td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-medium">Support</td>
                  <td className="py-4 px-4 text-center">Email</td>
                  <td className="py-4 px-4 text-center">Phone & Email</td>
                  <td className="py-4 px-4 text-center">24/7 Priority</td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-medium">Account Manager</td>
                  <td className="py-4 px-4 text-center">-</td>
                  <td className="py-4 px-4 text-center">-</td>
                  <td className="py-4 px-4 text-center">✓</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 rounded-2xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">Ready to Get Started?</h3>
          <p className="text-lg mb-6 opacity-90">
            Join over 150 businesses in Calgary who trust Madadi TFAS for their accounting needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-amber-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
              Schedule Free Consultation
            </button>
            <button className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-amber-600 transition-colors">
              Contact Sales
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPlans;