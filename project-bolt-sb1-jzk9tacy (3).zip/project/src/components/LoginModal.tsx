import React, { useState } from 'react';
import { X, User, Lock, Mail, Shield, Users, UserCheck } from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLogin: (role?: 'client' | 'admin' | 'employee') => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ isOpen, onClose, onLogin }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [loginType, setLoginType] = useState<'client' | 'admin' | 'employee'>('client');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    companyName: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(loginType);
    onClose();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (!isOpen) return null;

  const getLoginTypeInfo = () => {
    switch (loginType) {
      case 'admin':
        return {
          title: 'Admin Login',
          icon: Shield,
          description: 'Access admin panel to manage clients, employees, and website content'
        };
      case 'employee':
        return {
          title: 'Employee Login',
          icon: UserCheck,
          description: 'Access employee dashboard to manage assigned clients and tasks'
        };
      default:
        return {
          title: 'Client Login',
          icon: User,
          description: 'Access your client dashboard to view documents, deadlines, and payments'
        };
    }
  };

  const loginInfo = getLoginTypeInfo();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            {isSignUp ? 'Create Account' : loginInfo.title}
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {!isSignUp && (
          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-3">
              <loginInfo.icon className="w-5 h-5 text-amber-600" />
              <span className="text-sm text-gray-600">{loginInfo.description}</span>
            </div>
            
            <div className="flex space-x-2">
              <button
                onClick={() => setLoginType('client')}
                className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                  loginType === 'client' 
                    ? 'bg-amber-100 text-amber-800 border border-amber-300' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <User className="w-4 h-4 inline mr-1" />
                Client
              </button>
              <button
                onClick={() => setLoginType('employee')}
                className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                  loginType === 'employee' 
                    ? 'bg-amber-100 text-amber-800 border border-amber-300' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <UserCheck className="w-4 h-4 inline mr-1" />
                Employee
              </button>
              <button
                onClick={() => setLoginType('admin')}
                className={`flex-1 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
                  loginType === 'admin' 
                    ? 'bg-amber-100 text-amber-800 border border-amber-300' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Shield className="w-4 h-4 inline mr-1" />
                Admin
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Company Name
              </label>
              <div className="relative">
                <Users className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  placeholder="Your Company Name"
                  required
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Email Address
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder={
                  loginType === 'admin' ? 'admin@madadi-tfas.com' :
                  loginType === 'employee' ? 'employee@madadi-tfas.com' :
                  'your@email.com'
                }
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Password
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          {isSignUp && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Confirm Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  name="confirmPassword"
                  value={formData.confirmPassword}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-amber-600 text-white py-3 rounded-lg font-semibold hover:bg-amber-700 transition-colors"
          >
            {isSignUp ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        {loginType === 'client' && (
          <div className="mt-6 text-center">
            <button
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-amber-600 hover:text-amber-700 font-medium"
            >
              {isSignUp ? 'Already have an account? Sign in' : 'Need an account? Sign up'}
            </button>
          </div>
        )}

        {isSignUp && loginType === 'client' && (
          <div className="mt-4 p-4 bg-amber-50 rounded-lg">
            <p className="text-sm text-amber-700">
              <strong>New Client Benefits:</strong> Automatic tax deadline tracking, 
              secure document storage, seamless payment processing, and access to our software store.
            </p>
          </div>
        )}

        {!isSignUp && loginType !== 'client' && (
          <div className="mt-4 p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-blue-700">
              <strong>Demo Access:</strong> Use any email and password to access the {loginType} panel.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoginModal;