import React from 'react';
import { Star, Gift, Clock, ArrowRight } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface PromotionalOfferProps {
  onPlans: () => void;
}

const PromotionalOffer: React.FC<PromotionalOfferProps> = ({ onPlans }) => {
  const { t } = useLanguage();

  return (
    <section className="py-20 bg-gradient-to-br from-coffee-900 via-coffee-800 to-black relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='4'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }}></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-12">
          <div className="inline-flex items-center space-x-2 bg-caramel-500/20 text-caramel-300 px-4 py-2 rounded-full mb-6 border border-caramel-400/30">
            <Gift className="w-5 h-5" />
            <span className="font-semibold">🎉 Limited Time Offer!</span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Save Big on Professional 
            <span className="bg-gradient-to-r from-caramel-400 to-nescafe-400 bg-clip-text text-transparent"> Accounting Services</span>
          </h2>
          
          <p className="text-xl text-caramel-200 mb-8 max-w-3xl mx-auto">
            Save up to <span className="text-3xl font-bold text-caramel-400">20%</span> on annual subscriptions + 
            <span className="font-bold text-caramel-400"> FREE</span> software setup worth $300
          </p>
        </div>

        {/* Offer Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <div className="bg-white/10 backdrop-blur-sm border border-caramel-300/30 rounded-2xl p-6 hover:bg-white/15 transition-all transform hover:scale-105 shadow-xl">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Basic Plan</h3>
              <div className="space-y-2">
                <div className="text-caramel-300 line-through text-lg">$99/month</div>
                <div className="text-3xl font-bold text-caramel-400">$79/month</div>
                <div className="text-sm text-caramel-200">Save $240/year</div>
              </div>
            </div>
          </div>

          <div className="bg-white/15 backdrop-blur-sm border-2 border-caramel-400/50 rounded-2xl p-6 hover:bg-white/20 transition-all transform hover:scale-105 relative shadow-xl">
            <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
              <span className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-1 rounded-full text-sm font-bold shadow-lg">
                Most Popular
              </span>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Professional Plan</h3>
              <div className="space-y-2">
                <div className="text-caramel-300 line-through text-lg">$199/month</div>
                <div className="text-3xl font-bold text-caramel-400">$159/month</div>
                <div className="text-sm text-caramel-200">Save $480/year</div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm border border-caramel-300/30 rounded-2xl p-6 hover:bg-white/15 transition-all transform hover:scale-105 shadow-xl">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                <Star className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Enterprise Plan</h3>
              <div className="space-y-2">
                <div className="text-caramel-300 line-through text-lg">$399/month</div>
                <div className="text-3xl font-bold text-caramel-400">$319/month</div>
                <div className="text-sm text-caramel-200">Save $960/year</div>
              </div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 text-caramel-300 mb-6">
            <Clock className="w-5 h-5" />
            <span className="font-medium">*Offer valid until March 31, 2024. New clients only.</span>
          </div>
          
          <button 
            onClick={onPlans}
            className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-8 py-4 rounded-xl font-bold text-lg hover:from-caramel-600 hover:to-nescafe-600 transition-all transform hover:scale-105 shadow-2xl flex items-center space-x-2 mx-auto"
          >
            <span>Claim Your Discount Now</span>
            <ArrowRight className="w-5 h-5" />
          </button>
          
          <p className="text-caramel-300 text-sm mt-4">
            No setup fees • Cancel anytime • 30-day money-back guarantee
          </p>
        </div>
      </div>
    </section>
  );
};

export default PromotionalOffer;