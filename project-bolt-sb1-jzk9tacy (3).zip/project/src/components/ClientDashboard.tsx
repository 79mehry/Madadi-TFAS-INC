import React, { useState } from 'react';
import { 
  Calendar, 
  FileText, 
  DollarSign, 
  Bell, 
  Upload, 
  Download,
  AlertCircle,
  CheckCircle,
  Clock,
  User,
  Settings,
  CreditCard,
  Brain,
  TrendingUp,
  BarChart3
} from 'lucide-react';
import SmartDashboard from './SmartDashboard';
import AutomatedFinancialManager from './AutomatedFinancialManager';
import InvoiceManager from './InvoiceManager';
import ExpenseTracker from './ExpenseTracker';
import TaxFilingAssistant from './TaxFilingAssistant';
import SubscriptionTracker from './SubscriptionTracker';

interface ClientDashboardProps {
  onBack: () => void;
}

const ClientDashboard: React.FC<ClientDashboardProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [currentView, setCurrentView] = useState<'dashboard' | 'smart' | 'automation' | 'invoices' | 'expenses' | 'tax' | 'subscriptions'>('dashboard');

  if (currentView === 'smart') {
    return <SmartDashboard onBack={() => setCurrentView('dashboard')} />;
  }

  if (currentView === 'automation') {
    return <AutomatedFinancialManager onBack={() => setCurrentView('dashboard')} />;
  }

  if (currentView === 'invoices') {
    return <InvoiceManager onBack={() => setCurrentView('dashboard')} />;
  }

  if (currentView === 'expenses') {
    return <ExpenseTracker onBack={() => setCurrentView('dashboard')} />;
  }

  if (currentView === 'tax') {
    return <TaxFilingAssistant onBack={() => setCurrentView('dashboard')} />;
  }

  if (currentView === 'subscriptions') {
    return <SubscriptionTracker onBack={() => setCurrentView('dashboard')} />;
  }

  const taxDeadlines = [
    { type: 'Personal Tax Return', date: '2024-04-30', status: 'pending', daysLeft: 45 },
    { type: 'GST/HST Return', date: '2024-03-31', status: 'completed', daysLeft: 0 },
    { type: 'Payroll Remittance', date: '2024-02-15', status: 'overdue', daysLeft: -5 },
    { type: 'Corporate Tax Return', date: '2024-06-15', status: 'pending', daysLeft: 120 }
  ];

  const documents = [
    { name: 'T4 Slip 2023', type: 'Tax Document', uploadDate: '2024-01-15', size: '245 KB' },
    { name: 'Receipts January', type: 'Receipts', uploadDate: '2024-01-28', size: '1.2 MB' },
    { name: 'Bank Statement', type: 'Financial', uploadDate: '2024-01-20', size: '890 KB' },
    { name: 'Invoice Template', type: 'Business', uploadDate: '2024-01-10', size: '156 KB' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      case 'overdue': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'overdue': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-amber-600 hover:text-amber-700 transition-colors"
              >
                ← Back to Website
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Client Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="w-6 h-6 text-gray-600" />
                <span className="absolute -top-2 -right-2 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">3</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-amber-100 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-amber-600" />
                </div>
                <span className="text-gray-700">John Doe</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Account Balance</p>
                <p className="text-2xl font-bold text-gray-900">$1,248.50</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending Deadlines</p>
                <p className="text-2xl font-bold text-gray-900">2</p>
              </div>
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-yellow-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Documents</p>
                <p className="text-2xl font-bold text-gray-900">12</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Next Payment</p>
                <p className="text-2xl font-bold text-gray-900">Mar 15</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview' },
                { id: 'smart', label: 'Smart Dashboard' },
                { id: 'automation', label: 'AI Automation' },
                { id: 'invoices', label: 'Invoices' },
                { id: 'expenses', label: 'Expenses' },
                { id: 'tax', label: 'Tax Filing' },
                { id: 'subscriptions', label: 'Subscriptions' },
                { id: 'deadlines', label: 'Deadlines' },
                { id: 'documents', label: 'Documents' },
                { id: 'payments', label: 'Payments' },
                { id: 'settings', label: 'Settings' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (tab.id === 'smart') {
                      setCurrentView('smart');
                    } else if (tab.id === 'automation') {
                      setCurrentView('automation');
                    } else if (tab.id === 'invoices') {
                      setCurrentView('invoices');
                    } else if (tab.id === 'expenses') {
                      setCurrentView('expenses');
                    } else if (tab.id === 'tax') {
                      setCurrentView('tax');
                    } else if (tab.id === 'subscriptions') {
                      setCurrentView('subscriptions');
                    } else {
                      setActiveTab(tab.id);
                    }
                  }}
                  className={`py-4 px-1 font-medium text-sm capitalize ${
                    activeTab === tab.id
                      ? 'text-amber-600 border-b-2 border-amber-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="text-gray-700">GST/HST Return filed successfully</span>
                      <span className="text-sm text-gray-500 ml-auto">2 days ago</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <Upload className="w-5 h-5 text-blue-600" />
                      <span className="text-gray-700">New receipts uploaded</span>
                      <span className="text-sm text-gray-500 ml-auto">5 days ago</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <AlertCircle className="w-5 h-5 text-red-600" />
                      <span className="text-gray-700">Payment reminder sent</span>
                      <span className="text-sm text-gray-500 ml-auto">1 week ago</span>
                    </div>
                  </div>

                {/* Smart Features Preview */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div 
                    onClick={() => setCurrentView('smart')}
                    className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all"
                  >
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <BarChart3 className="w-5 h-5 text-blue-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">Smart Dashboard</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Advanced analytics, multi-currency support, and intelligent financial insights.
                    </p>
                    <div className="flex items-center text-blue-600 font-medium">
                      <span>Explore Smart Features</span>
                      <TrendingUp className="w-4 h-4 ml-2" />
                    </div>
                  </div>
                </div>
                  <div 
                    onClick={() => setCurrentView('automation')}
                    className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all"
                  >
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Brain className="w-5 h-5 text-green-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">AI Automation</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Automated transaction categorization, smart file processing, and AI-powered insights.
                    </p>
                    <div className="flex items-center text-green-600 font-medium">
                      <span>Activate AI Features</span>
                      <Brain className="w-4 h-4 ml-2" />
                    </div>
                  </div>
                  
                  <div 
                    onClick={() => setCurrentView('invoices')}
                    className="bg-gradient-to-r from-purple-50 to-violet-50 rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all"
                  >
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-purple-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">Invoice Manager</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Create, send, and track invoices. Automated payment reminders and professional templates.
                    </p>
                    <div className="flex items-center text-purple-600 font-medium">
                      <span>Manage Invoices</span>
                      <FileText className="w-4 h-4 ml-2" />
                    </div>
                  </div>
                  
                  <div 
                    onClick={() => setCurrentView('expenses')}
                    className="bg-gradient-to-r from-red-50 to-pink-50 rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all"
                  >
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                        <DollarSign className="w-5 h-5 text-red-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">Expense Tracker</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Scan receipts with AI, track expenses, and categorize automatically for tax purposes.
                    </p>
                    <div className="flex items-center text-red-600 font-medium">
                      <span>Track Expenses</span>
                      <DollarSign className="w-4 h-4 ml-2" />
                    </div>
                  </div>
                  
                  <div 
                    onClick={() => setCurrentView('tax')}
                    className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all"
                  >
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-indigo-100 rounded-lg flex items-center justify-center">
                        <FileText className="w-5 h-5 text-indigo-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">Tax Filing Assistant</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Step-by-step tax preparation, deduction tracking, and CRA compliance assistance.
                    </p>
                    <div className="flex items-center text-indigo-600 font-medium">
                      <span>File Taxes</span>
                      <FileText className="w-4 h-4 ml-2" />
                    </div>
                  </div>
                  
                  <div 
                    onClick={() => setCurrentView('subscriptions')}
                    className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-xl p-6 cursor-pointer hover:shadow-lg transition-all"
                  >
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
                        <CreditCard className="w-5 h-5 text-teal-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">Subscription Tracker</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Track recurring payments, get renewal alerts, and optimize subscription costs.
                    </p>
                    <div className="flex items-center text-teal-600 font-medium">
                      <span>Manage Subscriptions</span>
                      <CreditCard className="w-4 h-4 ml-2" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'deadlines' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">Tax Deadlines</h3>
                  <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                    Add Deadline
                  </button>
                </div>
                <div className="space-y-4">
                  {taxDeadlines.map((deadline, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900">{deadline.type}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(deadline.status)}`}>
                          {getStatusIcon(deadline.status)}
                          <span>{deadline.status}</span>
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>Due: {deadline.date}</span>
                        <span>
                          {deadline.daysLeft > 0 ? `${deadline.daysLeft} days left` : 
                           deadline.daysLeft < 0 ? `${Math.abs(deadline.daysLeft)} days overdue` : 'Due today'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'documents' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">My Documents</h3>
                  <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2">
                    <Upload className="w-4 h-4" />
                    <span>Upload Document</span>
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {documents.map((doc, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-amber-300 transition-colors">
                      <div className="flex items-center justify-between mb-2">
                        <FileText className="w-8 h-8 text-gray-400" />
                        <button className="text-amber-600 hover:text-amber-700">
                          <Download className="w-4 h-4" />
                        </button>
                      </div>
                      <h4 className="font-medium text-gray-900 mb-1">{doc.name}</h4>
                      <p className="text-sm text-gray-600 mb-2">{doc.type}</p>
                      <div className="text-xs text-gray-500 space-y-1">
                        <p>Uploaded: {doc.uploadDate}</p>
                        <p>Size: {doc.size}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'payments' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">Payment History</h3>
                  <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                    Add Funds
                  </button>
                </div>
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <h4 className="font-medium text-amber-800 mb-2">Automatic Payment Setup</h4>
                  <p className="text-sm text-amber-700 mb-3">
                    Your account is set up for automatic tax payments to CRA when deadlines approach.
                  </p>
                  <button className="text-amber-600 hover:text-amber-700 text-sm font-medium">
                    Manage Payment Settings →
                  </button>
                </div>
                <div className="space-y-4">
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-gray-900">GST/HST Payment</span>
                      <span className="text-green-600 font-medium">$450.00</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <p>March 31, 2024 • Paid to CRA</p>
                    </div>
                  </div>
                  <div className="border border-gray-200 rounded-lg p-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-medium text-gray-900">Service Fee</span>
                      <span className="text-gray-600 font-medium">$85.00</span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <p>March 15, 2024 • Bookkeeping Service</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Account Settings</h3>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Notification Preferences</h4>
                    <div className="space-y-3">
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" defaultChecked />
                        <span className="text-gray-700">Email notifications for upcoming deadlines</span>
                      </label>
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" defaultChecked />
                        <span className="text-gray-700">SMS alerts for payment confirmations</span>
                      </label>
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" />
                        <span className="text-gray-700">Weekly financial summary reports</span>
                      </label>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Security</h4>
                    <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors">
                      Change Password
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboard;