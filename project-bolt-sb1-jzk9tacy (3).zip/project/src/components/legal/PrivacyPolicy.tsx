import React from 'react';
import { Shield, Lock, Eye, FileText, Phone, Mail } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const PrivacyPolicy: React.FC = () => {
  const { t, language } = useLanguage();
  const isRTL = language === 'fa';

  return (
    <div className={`min-h-screen bg-gray-50 ${isRTL ? 'rtl' : 'ltr'}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-coffee-900">{t('legal.privacy.title')}</h1>
              <p className="text-coffee-600">{t('legal.privacy.subtitle')}</p>
            </div>
          </div>

          <div className="prose max-w-none">
            <div className="mb-8 p-6 bg-caramel-50 rounded-lg border border-caramel-200">
              <h2 className="text-xl font-semibold text-coffee-900 mb-4">{t('legal.privacy.overview.title')}</h2>
              <p className="text-coffee-700">{t('legal.privacy.overview.content')}</p>
            </div>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4 flex items-center">
                <FileText className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.privacy.collection.title')}
              </h2>
              <div className="space-y-4">
                <p className="text-coffee-700">{t('legal.privacy.collection.intro')}</p>
                <ul className="list-disc list-inside space-y-2 text-coffee-700 ml-6">
                  <li>{t('legal.privacy.collection.personal')}</li>
                  <li>{t('legal.privacy.collection.financial')}</li>
                  <li>{t('legal.privacy.collection.business')}</li>
                  <li>{t('legal.privacy.collection.technical')}</li>
                  <li>{t('legal.privacy.collection.communication')}</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4 flex items-center">
                <Eye className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.privacy.usage.title')}
              </h2>
              <div className="space-y-4">
                <p className="text-coffee-700">{t('legal.privacy.usage.intro')}</p>
                <ul className="list-disc list-inside space-y-2 text-coffee-700 ml-6">
                  <li>{t('legal.privacy.usage.services')}</li>
                  <li>{t('legal.privacy.usage.compliance')}</li>
                  <li>{t('legal.privacy.usage.communication')}</li>
                  <li>{t('legal.privacy.usage.improvement')}</li>
                  <li>{t('legal.privacy.usage.legal')}</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4 flex items-center">
                <Lock className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.privacy.protection.title')}
              </h2>
              <div className="space-y-4">
                <p className="text-coffee-700">{t('legal.privacy.protection.intro')}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-900">{t('legal.privacy.protection.technical')}</h4>
                    <p className="text-blue-700 text-sm mt-2">{t('legal.privacy.protection.technicalDesc')}</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-900">{t('legal.privacy.protection.administrative')}</h4>
                    <p className="text-green-700 text-sm mt-2">{t('legal.privacy.protection.administrativeDesc')}</p>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.privacy.thirdParty.title')}</h2>
              <div className="space-y-4">
                <p className="text-coffee-700">{t('legal.privacy.thirdParty.intro')}</p>
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                  <h4 className="font-semibold text-yellow-900 mb-2">{t('legal.privacy.thirdParty.services')}</h4>
                  <ul className="list-disc list-inside space-y-1 text-yellow-800 text-sm">
                    <li><strong>Stripe:</strong> {t('legal.privacy.thirdParty.stripe')}</li>
                    <li><strong>PayPal:</strong> {t('legal.privacy.thirdParty.paypal')}</li>
                    <li><strong>Google Analytics:</strong> {t('legal.privacy.thirdParty.analytics')}</li>
                    <li><strong>Cloud Storage:</strong> {t('legal.privacy.thirdParty.storage')}</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.privacy.rights.title')}</h2>
              <div className="space-y-4">
                <p className="text-coffee-700">{t('legal.privacy.rights.intro')}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-caramel-600 rounded-full"></div>
                      <span className="text-coffee-700">{t('legal.privacy.rights.access')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-caramel-600 rounded-full"></div>
                      <span className="text-coffee-700">{t('legal.privacy.rights.correction')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-caramel-600 rounded-full"></div>
                      <span className="text-coffee-700">{t('legal.privacy.rights.deletion')}</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-caramel-600 rounded-full"></div>
                      <span className="text-coffee-700">{t('legal.privacy.rights.portability')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-caramel-600 rounded-full"></div>
                      <span className="text-coffee-700">{t('legal.privacy.rights.withdrawal')}</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-caramel-600 rounded-full"></div>
                      <span className="text-coffee-700">{t('legal.privacy.rights.complaint')}</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.privacy.contact.title')}</h2>
              <div className="bg-caramel-50 p-6 rounded-lg border border-caramel-200">
                <p className="text-coffee-700 mb-4">{t('legal.privacy.contact.intro')}</p>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-caramel-600" />
                    <span className="text-coffee-700">privacy@madadi-tfas.com</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Phone className="w-5 h-5 text-caramel-600" />
                    <span className="text-coffee-700">+1 (403) 555-0123</span>
                  </div>
                </div>
              </div>
            </section>

            <div className="text-sm text-coffee-500 border-t pt-6">
              <p>{t('legal.privacy.lastUpdated')}: {new Date().toLocaleDateString()}</p>
              <p className="mt-2">{t('legal.privacy.pipedaCompliance')}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;