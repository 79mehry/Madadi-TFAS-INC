import React, { useState } from 'react';
import { Cookie, Settings, Check, X, Info } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const CookiePolicy: React.FC = () => {
  const { t, language } = useLanguage();
  const isRTL = language === 'fa';
  const [cookieSettings, setCookieSettings] = useState({
    essential: true,
    analytics: false,
    marketing: false,
    preferences: false
  });

  const handleCookieToggle = (type: keyof typeof cookieSettings) => {
    if (type === 'essential') return; // Essential cookies cannot be disabled
    setCookieSettings(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };

  const saveCookieSettings = () => {
    localStorage.setItem('cookieSettings', JSON.stringify(cookieSettings));
    alert(t('legal.cookies.saved'));
  };

  return (
    <div className={`min-h-screen bg-gray-50 ${isRTL ? 'rtl' : 'ltr'}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-lg flex items-center justify-center">
              <Cookie className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-coffee-900">{t('legal.cookies.title')}</h1>
              <p className="text-coffee-600">{t('legal.cookies.subtitle')}</p>
            </div>
          </div>

          <div className="prose max-w-none">
            <div className="mb-8 p-6 bg-caramel-50 rounded-lg border border-caramel-200">
              <h2 className="text-xl font-semibold text-coffee-900 mb-4">{t('legal.cookies.what.title')}</h2>
              <p className="text-coffee-700">{t('legal.cookies.what.content')}</p>
            </div>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6">{t('legal.cookies.types.title')}</h2>
              
              <div className="space-y-6">
                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                        <Check className="w-5 h-5 text-green-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-coffee-900">{t('legal.cookies.essential.title')}</h3>
                        <p className="text-sm text-coffee-600">{t('legal.cookies.essential.required')}</p>
                      </div>
                    </div>
                    <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      {t('legal.cookies.always')}
                    </div>
                  </div>
                  <p className="text-coffee-700 mb-3">{t('legal.cookies.essential.description')}</p>
                  <ul className="list-disc list-inside text-coffee-600 text-sm space-y-1">
                    <li>{t('legal.cookies.essential.session')}</li>
                    <li>{t('legal.cookies.essential.security')}</li>
                    <li>{t('legal.cookies.essential.preferences')}</li>
                  </ul>
                </div>

                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Info className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-coffee-900">{t('legal.cookies.analytics.title')}</h3>
                        <p className="text-sm text-coffee-600">{t('legal.cookies.analytics.optional')}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCookieToggle('analytics')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        cookieSettings.analytics ? 'bg-caramel-600' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          cookieSettings.analytics ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <p className="text-coffee-700 mb-3">{t('legal.cookies.analytics.description')}</p>
                  <ul className="list-disc list-inside text-coffee-600 text-sm space-y-1">
                    <li>{t('legal.cookies.analytics.usage')}</li>
                    <li>{t('legal.cookies.analytics.performance')}</li>
                    <li>{t('legal.cookies.analytics.google')}</li>
                  </ul>
                </div>

                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                        <Settings className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-coffee-900">{t('legal.cookies.preferences.title')}</h3>
                        <p className="text-sm text-coffee-600">{t('legal.cookies.preferences.optional')}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCookieToggle('preferences')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        cookieSettings.preferences ? 'bg-caramel-600' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          cookieSettings.preferences ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <p className="text-coffee-700 mb-3">{t('legal.cookies.preferences.description')}</p>
                  <ul className="list-disc list-inside text-coffee-600 text-sm space-y-1">
                    <li>{t('legal.cookies.preferences.language')}</li>
                    <li>{t('legal.cookies.preferences.theme')}</li>
                    <li>{t('legal.cookies.preferences.dashboard')}</li>
                  </ul>
                </div>

                <div className="border border-gray-200 rounded-lg p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                        <X className="w-5 h-5 text-orange-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-coffee-900">{t('legal.cookies.marketing.title')}</h3>
                        <p className="text-sm text-coffee-600">{t('legal.cookies.marketing.optional')}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleCookieToggle('marketing')}
                      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                        cookieSettings.marketing ? 'bg-caramel-600' : 'bg-gray-300'
                      }`}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                          cookieSettings.marketing ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  </div>
                  <p className="text-coffee-700 mb-3">{t('legal.cookies.marketing.description')}</p>
                  <ul className="list-disc list-inside text-coffee-600 text-sm space-y-1">
                    <li>{t('legal.cookies.marketing.advertising')}</li>
                    <li>{t('legal.cookies.marketing.social')}</li>
                    <li>{t('legal.cookies.marketing.tracking')}</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.cookies.thirdParty.title')}</h2>
              <div className="bg-yellow-50 p-6 rounded-lg border border-yellow-200">
                <p className="text-yellow-800 mb-4">{t('legal.cookies.thirdParty.description')}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-yellow-900 mb-2">{t('legal.cookies.thirdParty.services')}</h4>
                    <ul className="list-disc list-inside text-yellow-700 text-sm space-y-1">
                      <li>Google Analytics</li>
                      <li>Stripe Payments</li>
                      <li>PayPal</li>
                      <li>Intercom Chat</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-yellow-900 mb-2">{t('legal.cookies.thirdParty.purposes')}</h4>
                    <ul className="list-disc list-inside text-yellow-700 text-sm space-y-1">
                      <li>{t('legal.cookies.thirdParty.analytics')}</li>
                      <li>{t('legal.cookies.thirdParty.payments')}</li>
                      <li>{t('legal.cookies.thirdParty.support')}</li>
                      <li>{t('legal.cookies.thirdParty.security')}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.cookies.manage.title')}</h2>
              <div className="bg-caramel-50 p-6 rounded-lg border border-caramel-200">
                <p className="text-coffee-700 mb-4">{t('legal.cookies.manage.description')}</p>
                <div className="flex space-x-4">
                  <button
                    onClick={saveCookieSettings}
                    className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-6 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors"
                  >
                    {t('legal.cookies.save')}
                  </button>
                  <button
                    onClick={() => setCookieSettings({ essential: true, analytics: false, marketing: false, preferences: false })}
                    className="border border-gray-300 text-coffee-700 px-6 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    {t('legal.cookies.reject')}
                  </button>
                </div>
              </div>
            </section>

            <div className="text-sm text-coffee-500 border-t pt-6">
              <p>{t('legal.cookies.lastUpdated')}: {new Date().toLocaleDateString()}</p>
              <p className="mt-2">{t('legal.cookies.contact')}: privacy@madadi-tfas.com</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicy;