import React, { useState, useRef } from 'react';
import { 
  Camera, 
  Upload, 
  Search, 
  Filter, 
  Plus, 
  Edit, 
  Trash2,
  Calendar,
  DollarSign,
  Tag,
  Receipt,
  Scan,
  CheckCircle,
  Clock,
  AlertCircle,
  Download,
  BarChart3,
  PieChart,
  TrendingUp
} from 'lucide-react';

interface Expense {
  id: string;
  description: string;
  amount: number;
  currency: string;
  category: string;
  date: string;
  receiptUrl?: string;
  paymentMethod: string;
  vendor: string;
  taxDeductible: boolean;
  status: 'pending' | 'approved' | 'rejected';
  tags: string[];
  notes?: string;
}

interface ExpenseTrackerProps {
  onBack: () => void;
}

const ExpenseTracker: React.FC<ExpenseTrackerProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('expenses');
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [selectedExpense, setSelectedExpense] = useState<Expense | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const [expenses, setExpenses] = useState<Expense[]>([
    {
      id: '1',
      description: 'Office Supplies - Staples',
      amount: 156.78,
      currency: 'CAD',
      category: 'Office Supplies',
      date: '2024-01-15',
      receiptUrl: '/receipt1.jpg',
      paymentMethod: 'Credit Card',
      vendor: 'Staples',
      taxDeductible: true,
      status: 'approved',
      tags: ['office', 'supplies', 'business'],
      notes: 'Monthly office supply purchase'
    },
    {
      id: '2',
      description: 'Business Lunch - Client Meeting',
      amount: 89.50,
      currency: 'CAD',
      category: 'Meals & Entertainment',
      date: '2024-01-14',
      receiptUrl: '/receipt2.jpg',
      paymentMethod: 'Credit Card',
      vendor: 'Restaurant ABC',
      taxDeductible: true,
      status: 'pending',
      tags: ['meals', 'client', 'business'],
      notes: 'Meeting with potential client'
    },
    {
      id: '3',
      description: 'Software Subscription - Adobe',
      amount: 52.99,
      currency: 'CAD',
      category: 'Software',
      date: '2024-01-13',
      paymentMethod: 'Credit Card',
      vendor: 'Adobe',
      taxDeductible: true,
      status: 'approved',
      tags: ['software', 'subscription', 'recurring']
    }
  ]);

  const categories = [
    'Office Supplies', 'Software', 'Meals & Entertainment', 'Travel', 
    'Marketing', 'Professional Services', 'Utilities', 'Equipment', 'Other'
  ];

  const paymentMethods = ['Credit Card', 'Debit Card', 'Cash', 'Bank Transfer', 'Check'];

  const handleReceiptScan = async (file: File) => {
    setIsScanning(true);
    
    // Simulate OCR processing
    setTimeout(() => {
      const mockData = {
        vendor: 'Auto-detected Vendor',
        amount: Math.floor(Math.random() * 200) + 10,
        date: new Date().toISOString().split('T')[0],
        category: categories[Math.floor(Math.random() * categories.length)]
      };
      
      setSelectedExpense({
        id: '',
        description: `Purchase from ${mockData.vendor}`,
        amount: mockData.amount,
        currency: 'CAD',
        category: mockData.category,
        date: mockData.date,
        receiptUrl: URL.createObjectURL(file),
        paymentMethod: 'Credit Card',
        vendor: mockData.vendor,
        taxDeductible: true,
        status: 'pending',
        tags: [],
        notes: 'Auto-scanned from receipt'
      });
      
      setIsScanning(false);
      setShowExpenseModal(true);
    }, 2000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleReceiptScan(file);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return <CheckCircle className="w-4 h-4" />;
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'rejected': return <AlertCircle className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const ExpenseForm = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            <input
              type="text"
              defaultValue={selectedExpense?.description}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              placeholder="Expense description"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Amount</label>
              <input
                type="number"
                step="0.01"
                defaultValue={selectedExpense?.amount}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                placeholder="0.00"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
              <select
                defaultValue={selectedExpense?.currency || 'CAD'}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              >
                <option value="CAD">CAD</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
              </select>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
            <select
              defaultValue={selectedExpense?.category}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              <option value="">Select category</option>
              {categories.map(category => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
            <input
              type="date"
              defaultValue={selectedExpense?.date}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Vendor</label>
            <input
              type="text"
              defaultValue={selectedExpense?.vendor}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              placeholder="Vendor name"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
            <select
              defaultValue={selectedExpense?.paymentMethod}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
            >
              {paymentMethods.map(method => (
                <option key={method} value={method}>{method}</option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Tags</label>
            <input
              type="text"
              defaultValue={selectedExpense?.tags?.join(', ')}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              placeholder="business, office, supplies (comma separated)"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <input
              type="checkbox"
              id="taxDeductible"
              defaultChecked={selectedExpense?.taxDeductible}
              className="rounded text-amber-600 focus:ring-amber-500"
            />
            <label htmlFor="taxDeductible" className="text-sm font-medium text-gray-700">
              Tax Deductible
            </label>
          </div>
        </div>
      </div>

      {/* Receipt Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Receipt</label>
        {selectedExpense?.receiptUrl ? (
          <div className="flex items-center space-x-4">
            <img
              src={selectedExpense.receiptUrl}
              alt="Receipt"
              className="w-20 h-20 object-cover rounded-lg border"
            />
            <div className="flex space-x-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2"
              >
                <Upload className="w-4 h-4" />
                <span>Replace</span>
              </button>
              <button
                onClick={() => cameraInputRef.current?.click()}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
              >
                <Camera className="w-4 h-4" />
                <span>Camera</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
            <Receipt className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h4 className="text-lg font-medium text-gray-900 mb-2">Upload Receipt</h4>
            <p className="text-gray-600 mb-4">Take a photo or upload an image of your receipt</p>
            <div className="flex justify-center space-x-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2"
              >
                <Upload className="w-4 h-4" />
                <span>Upload File</span>
              </button>
              <button
                onClick={() => cameraInputRef.current?.click()}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
              >
                <Camera className="w-4 h-4" />
                <span>Take Photo</span>
              </button>
            </div>
          </div>
        )}
        
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="hidden"
        />
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleFileUpload}
          className="hidden"
        />
      </div>

      {/* Notes */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Notes</label>
        <textarea
          defaultValue={selectedExpense?.notes}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          placeholder="Additional notes about this expense..."
        />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-caramel-50 to-nescafe-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-caramel-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-caramel-600 hover:text-caramel-700 transition-colors font-medium"
              >
                ← Back to Dashboard
              </button>
              <h1 className="text-2xl font-bold text-coffee-900">Expense Tracker</h1>
            </div>
            <div className="flex space-x-3">
              <button
                onClick={() => cameraInputRef.current?.click()}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2 shadow-md"
              >
                <Scan className="w-4 h-4" />
                <span>Scan Receipt</span>
              </button>
              <button
                onClick={() => {
                  setSelectedExpense(null);
                  setShowExpenseModal(true);
                }}
                className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors flex items-center space-x-2 shadow-md"
              >
                <Plus className="w-4 h-4" />
                <span>Add Expense</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Expenses</p>
                <p className="text-2xl font-bold text-gray-900">
                  ${expenses.reduce((sum, exp) => sum + exp.amount, 0).toFixed(2)}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-red-600" />
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tax Deductible</p>
                <p className="text-2xl font-bold text-green-600">
                  ${expenses.filter(exp => exp.taxDeductible).reduce((sum, exp) => sum + exp.amount, 0).toFixed(2)}
                </p>
              </div>
              <Receipt className="w-8 h-8 text-green-600" />
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">This Month</p>
                <p className="text-2xl font-bold text-blue-600">
                  ${expenses.filter(exp => exp.date.startsWith('2024-01')).reduce((sum, exp) => sum + exp.amount, 0).toFixed(2)}
                </p>
              </div>
              <Calendar className="w-8 h-8 text-blue-600" />
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {expenses.filter(exp => exp.status === 'pending').length}
                </p>
              </div>
              <Clock className="w-8 h-8 text-yellow-600" />
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-gray-900">All Expenses</h3>
              <div className="flex space-x-3">
                <div className="relative">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search expenses..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
                <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <Filter className="w-4 h-4" />
                  <span>Filter</span>
                </button>
                <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <Download className="w-4 h-4" />
                  <span>Export</span>
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Expense</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Receipt</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {expenses.map((expense) => (
                    <tr key={expense.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">{expense.description}</div>
                        <div className="text-sm text-gray-500">{expense.vendor}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs">
                          {expense.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="font-medium text-gray-900">${expense.amount.toFixed(2)}</div>
                        <div className="text-sm text-gray-500">{expense.currency}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{expense.date}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(expense.status)}`}>
                          {getStatusIcon(expense.status)}
                          <span className="capitalize">{expense.status}</span>
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {expense.receiptUrl ? (
                          <img src={expense.receiptUrl} alt="Receipt" className="w-8 h-8 object-cover rounded" />
                        ) : (
                          <span className="text-gray-400">No receipt</span>
                        )}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => {
                              setSelectedExpense(expense);
                              setShowExpenseModal(true);
                            }}
                            className="text-amber-600 hover:text-amber-900"
                          >
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="text-red-600 hover:text-red-900">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Scanning Modal */}
      {isScanning && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4 text-center">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-amber-600 mx-auto mb-4"></div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Scanning Receipt...</h3>
            <p className="text-gray-600">Using AI to extract expense information</p>
          </div>
        </div>
      )}

      {/* Expense Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-4xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900">
                {selectedExpense?.id ? 'Edit Expense' : 'Add New Expense'}
              </h3>
              <button
                onClick={() => setShowExpenseModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            
            <ExpenseForm />
            
            <div className="flex justify-end space-x-4 mt-8">
              <button
                onClick={() => setShowExpenseModal(false)}
                className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button className="px-6 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700">
                {selectedExpense?.id ? 'Update Expense' : 'Add Expense'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpenseTracker;