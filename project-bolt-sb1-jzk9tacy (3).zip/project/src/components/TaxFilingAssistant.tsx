import React, { useState } from 'react';
import { 
  FileText, 
  Calculator, 
  Upload, 
  Download, 
  CheckCircle, 
  AlertCircle,
  Calendar,
  DollarSign,
  User,
  Building,
  Receipt,
  TrendingUp,
  Shield,
  Clock,
  Plus,
  Edit,
  Trash2,
  Search
} from 'lucide-react';

interface TaxFilingAssistantProps {
  onBack: () => void;
}

interface TaxDeduction {
  id: string;
  category: string;
  description: string;
  amount: number;
  supportingDocuments: string[];
  isVerified: boolean;
}

interface TaxFiling {
  id: string;
  taxYear: number;
  filingType: 'personal' | 'corporate' | 'gst' | 'payroll';
  status: 'draft' | 'review' | 'filed' | 'accepted';
  dueDate: string;
  estimatedRefund?: number;
  estimatedOwing?: number;
  deductions: TaxDeduction[];
  progress: number;
}

const TaxFilingAssistant: React.FC<TaxFilingAssistantProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedFiling, setSelectedFiling] = useState<TaxFiling | null>(null);
  const [showDeductionModal, setShowDeductionModal] = useState(false);

  const taxFilings: TaxFiling[] = [
    {
      id: '1',
      taxYear: 2024,
      filingType: 'personal',
      status: 'draft',
      dueDate: '2024-04-30',
      estimatedRefund: 1250.00,
      progress: 65,
      deductions: [
        {
          id: '1',
          category: 'Home Office',
          description: 'Home office expenses for 2024',
          amount: 2400.00,
          supportingDocuments: ['home-office-receipts.pdf'],
          isVerified: true
        },
        {
          id: '2',
          category: 'Professional Development',
          description: 'Accounting courses and certifications',
          amount: 850.00,
          supportingDocuments: ['course-receipts.pdf'],
          isVerified: true
        }
      ]
    },
    {
      id: '2',
      taxYear: 2024,
      filingType: 'corporate',
      status: 'review',
      dueDate: '2024-06-15',
      estimatedOwing: 3200.00,
      progress: 90,
      deductions: [
        {
          id: '3',
          category: 'Business Expenses',
          description: 'Office supplies and equipment',
          amount: 5600.00,
          supportingDocuments: ['business-expenses.pdf'],
          isVerified: true
        }
      ]
    },
    {
      id: '3',
      taxYear: 2024,
      filingType: 'gst',
      status: 'filed',
      dueDate: '2024-01-31',
      estimatedRefund: 450.00,
      progress: 100,
      deductions: []
    }
  ];

  const taxDeductionCategories = [
    {
      category: 'Home Office',
      maxAmount: 5000,
      description: 'Expenses for workspace used exclusively for business',
      commonExpenses: ['Rent/Mortgage Interest', 'Utilities', 'Internet', 'Office Supplies']
    },
    {
      category: 'Vehicle Expenses',
      maxAmount: 15000,
      description: 'Business use of personal vehicle',
      commonExpenses: ['Fuel', 'Insurance', 'Maintenance', 'Parking']
    },
    {
      category: 'Professional Development',
      maxAmount: 3000,
      description: 'Courses, certifications, and training',
      commonExpenses: ['Course Fees', 'Books', 'Conference Tickets', 'Travel']
    },
    {
      category: 'Business Meals',
      maxAmount: 2000,
      description: '50% of business meal expenses',
      commonExpenses: ['Client Meals', 'Business Lunches', 'Conference Meals']
    },
    {
      category: 'Professional Services',
      maxAmount: 10000,
      description: 'Legal, accounting, and consulting fees',
      commonExpenses: ['Legal Fees', 'Accounting Fees', 'Consulting', 'Professional Memberships']
    }
  ];

  const taxTips = [
    {
      title: 'Maximize Your RRSP Contribution',
      description: 'You can contribute up to 18% of your previous year\'s income to reduce taxable income.',
      potentialSavings: 1200,
      deadline: '2024-03-01'
    },
    {
      title: 'Claim Home Office Expenses',
      description: 'If you work from home, you may be able to claim a portion of your home expenses.',
      potentialSavings: 800,
      deadline: '2024-04-30'
    },
    {
      title: 'Track Medical Expenses',
      description: 'Medical expenses over 3% of your income or $2,635 (whichever is less) are deductible.',
      potentialSavings: 450,
      deadline: '2024-04-30'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'filed': return 'bg-green-100 text-green-800';
      case 'review': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-yellow-100 text-yellow-800';
      case 'accepted': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'filed': return <CheckCircle className="w-4 h-4" />;
      case 'review': return <Clock className="w-4 h-4" />;
      case 'draft': return <Edit className="w-4 h-4" />;
      case 'accepted': return <CheckCircle className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const calculateTotalDeductions = (deductions: TaxDeduction[]) => {
    return deductions.reduce((sum, deduction) => sum + deduction.amount, 0);
  };

  const estimateTaxSavings = (deductions: number, taxRate: number = 0.25) => {
    return deductions * taxRate;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-caramel-50 to-nescafe-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-caramel-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-caramel-600 hover:text-caramel-700 transition-colors font-medium"
              >
                ← Back to Dashboard
              </button>
              <h1 className="text-2xl font-bold text-coffee-900">Tax Filing Assistant</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-green-100 text-green-800 px-3 py-1 rounded-full border border-green-200">
                <Shield className="w-4 h-4" />
                <span className="text-sm font-medium">CRA Compliant</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-caramel-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tax Filings</p>
                <p className="text-2xl font-bold text-blue-600">{taxFilings.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Estimated Refund</p>
                <p className="text-2xl font-bold text-green-600">
                  ${taxFilings.reduce((sum, filing) => sum + (filing.estimatedRefund || 0), 0).toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Deductions</p>
                <p className="text-2xl font-bold text-purple-600">
                  ${taxFilings.reduce((sum, filing) => sum + calculateTotalDeductions(filing.deductions), 0).toLocaleString()}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Receipt className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Days to Deadline</p>
                <p className="text-2xl font-bold text-red-600">
                  {Math.ceil((new Date('2024-04-30').getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))}
                </p>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <Calendar className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview', icon: FileText },
                { id: 'filings', label: 'Tax Filings', icon: Calculator },
                { id: 'deductions', label: 'Deductions', icon: Receipt },
                { id: 'tips', label: 'Tax Tips', icon: TrendingUp },
                { id: 'documents', label: 'Documents', icon: Upload }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.id
                      ? 'text-caramel-600 border-b-2 border-caramel-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Tax Filing Progress */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">2024 Tax Filing Progress</h3>
                    <div className="space-y-4">
                      {taxFilings.map((filing) => (
                        <div key={filing.id} className="bg-white rounded-lg p-4 border border-caramel-100">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <span className="font-medium text-coffee-900 capitalize">{filing.filingType} Tax</span>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(filing.status)}`}>
                                {getStatusIcon(filing.status)}
                                <span>{filing.status}</span>
                              </span>
                            </div>
                            <span className="text-sm text-coffee-600">Due: {filing.dueDate}</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                            <div 
                              className="bg-caramel-600 h-2 rounded-full transition-all duration-300" 
                              style={{ width: `${filing.progress}%` }}
                            ></div>
                          </div>
                          <div className="flex justify-between text-sm text-coffee-600">
                            <span>{filing.progress}% complete</span>
                            {filing.estimatedRefund && (
                              <span className="text-green-600 font-medium">
                                Estimated refund: ${filing.estimatedRefund.toLocaleString()}
                              </span>
                            )}
                            {filing.estimatedOwing && (
                              <span className="text-red-600 font-medium">
                                Estimated owing: ${filing.estimatedOwing.toLocaleString()}
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                      <button className="w-full bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-caramel-100 rounded-lg flex items-center justify-center">
                            <Plus className="w-5 h-5 text-caramel-600" />
                          </div>
                          <div>
                            <p className="font-medium text-coffee-900">Start New Tax Filing</p>
                            <p className="text-sm text-coffee-600">Begin your 2024 tax return</p>
                          </div>
                        </div>
                      </button>
                      
                      <button className="w-full bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Upload className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <p className="font-medium text-coffee-900">Upload Tax Documents</p>
                            <p className="text-sm text-coffee-600">T4, T5, receipts, and more</p>
                          </div>
                        </div>
                      </button>
                      
                      <button className="w-full bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                            <Calculator className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <p className="font-medium text-coffee-900">Tax Calculator</p>
                            <p className="text-sm text-coffee-600">Estimate your refund or owing</p>
                          </div>
                        </div>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Upcoming Deadlines */}
                <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                  <h3 className="text-lg font-semibold text-coffee-900 mb-4">Upcoming Tax Deadlines</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white rounded-lg p-4 border border-caramel-100">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                          <User className="w-5 h-5 text-red-600" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">Personal Tax Return</p>
                          <p className="text-sm text-coffee-600">April 30, 2024</p>
                          <p className="text-xs text-red-600">89 days remaining</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-white rounded-lg p-4 border border-caramel-100">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Building className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">Corporate Tax Return</p>
                          <p className="text-sm text-coffee-600">June 15, 2024</p>
                          <p className="text-xs text-blue-600">135 days remaining</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-white rounded-lg p-4 border border-caramel-100">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                          <Receipt className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">GST/HST Return</p>
                          <p className="text-sm text-coffee-600">January 31, 2024</p>
                          <p className="text-xs text-green-600">Filed ✓</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'deductions' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Tax Deductions</h3>
                  <button 
                    onClick={() => setShowDeductionModal(true)}
                    className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors flex items-center space-x-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Deduction</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {taxDeductionCategories.map((category, index) => (
                    <div key={index} className="bg-white border border-gray-200 rounded-xl p-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="font-semibold text-coffee-900">{category.category}</h4>
                          <p className="text-sm text-coffee-600 mt-1">{category.description}</p>
                        </div>
                        <span className="text-sm text-gray-500">Max: ${category.maxAmount.toLocaleString()}</span>
                      </div>
                      
                      <div className="mb-4">
                        <h5 className="text-sm font-medium text-coffee-900 mb-2">Common Expenses:</h5>
                        <div className="flex flex-wrap gap-2">
                          {category.commonExpenses.map((expense, expenseIndex) => (
                            <span key={expenseIndex} className="bg-caramel-100 text-caramel-700 px-2 py-1 rounded text-xs">
                              {expense}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-coffee-600">Potential savings: ${estimateTaxSavings(category.maxAmount).toLocaleString()}</span>
                        <button className="text-caramel-600 hover:text-caramel-700 font-medium text-sm">
                          Add Expenses →
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'tips' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-coffee-900">Tax Optimization Tips</h3>
                
                <div className="space-y-4">
                  {taxTips.map((tip, index) => (
                    <div key={index} className="bg-white border border-gray-200 rounded-xl p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-coffee-900 mb-2">{tip.title}</h4>
                          <p className="text-coffee-600 mb-3">{tip.description}</p>
                          <div className="flex items-center space-x-4 text-sm">
                            <span className="flex items-center space-x-1 text-green-600">
                              <DollarSign className="w-4 h-4" />
                              <span>Potential savings: ${tip.potentialSavings}</span>
                            </span>
                            <span className="flex items-center space-x-1 text-coffee-600">
                              <Calendar className="w-4 h-4" />
                              <span>Deadline: {tip.deadline}</span>
                            </span>
                          </div>
                        </div>
                        <button className="bg-caramel-600 text-white px-4 py-2 rounded-lg hover:bg-caramel-700 transition-colors">
                          Learn More
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-blue-800">Professional Tax Advice</h4>
                      <p className="text-blue-700 mt-1">
                        These tips are general guidelines. For personalized tax advice specific to your situation, 
                        consider consulting with our certified tax professionals. We can help you maximize your deductions 
                        and ensure full compliance with CRA regulations.
                      </p>
                      <button className="mt-3 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        Schedule Tax Consultation
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Deduction Modal */}
      {showDeductionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
            <h3 className="text-2xl font-bold text-coffee-900 mb-6">Add Tax Deduction</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-coffee-700 mb-2">Category</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500">
                  <option value="">Select category</option>
                  {taxDeductionCategories.map((category, index) => (
                    <option key={index} value={category.category}>{category.category}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-coffee-700 mb-2">Description</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
                  placeholder="Describe the expense"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-coffee-700 mb-2">Amount</label>
                <input
                  type="number"
                  step="0.01"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
                  placeholder="0.00"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-coffee-700 mb-2">Supporting Documents</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                  <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Upload receipts or documents</p>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowDeductionModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  // Handle save logic here
                  setShowDeductionModal(false);
                }}
                className="flex-1 bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors"
              >
                Add Deduction
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaxFilingAssistant;