import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  TrendingUp,
  Tag,
  Zap,
  Settings,
  Download,
  Filter,
  Search,
  Plus,
  Edit,
  Trash2,
  BarChart3
} from 'lucide-react';
import { Transaction, SmartCategory } from '../types';

interface AutomatedFinancialManagerProps {
  onBack: () => void;
}

const AutomatedFinancialManager: React.FC<AutomatedFinancialManagerProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('automation');
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  // Smart categorization rules
  const smartCategories: SmartCategory[] = [
    {
      id: '1',
      name: 'Office Supplies',
      keywords: ['staples', 'office depot', 'paper', 'pens', 'supplies'],
      type: 'expense',
      taxDeductible: true,
      businessExpense: true
    },
    {
      id: '2',
      name: 'Software Subscriptions',
      keywords: ['adobe', 'microsoft', 'quickbooks', 'subscription', 'saas'],
      type: 'expense',
      taxDeductible: true,
      businessExpense: true
    },
    {
      id: '3',
      name: 'Professional Services',
      keywords: ['consulting', 'legal', 'accounting', 'professional'],
      type: 'income',
      taxDeductible: false,
      businessExpense: false
    },
    {
      id: '4',
      name: 'Travel & Transportation',
      keywords: ['uber', 'taxi', 'flight', 'hotel', 'gas', 'parking'],
      type: 'expense',
      taxDeductible: true,
      businessExpense: true
    },
    {
      id: '5',
      name: 'Marketing & Advertising',
      keywords: ['google ads', 'facebook', 'marketing', 'advertising', 'promotion'],
      type: 'expense',
      taxDeductible: true,
      businessExpense: true
    }
  ];

  // Mock processed transactions
  const processedTransactions: Transaction[] = [
    {
      id: '1',
      date: '2024-01-15',
      description: 'STAPLES OFFICE SUPPLIES',
      amount: -156.78,
      currency: 'CAD',
      category: 'Office Supplies',
      type: 'expense',
      status: 'completed',
      tags: ['tax-deductible', 'business-expense'],
      clientId: 'client1'
    },
    {
      id: '2',
      date: '2024-01-14',
      description: 'ADOBE CREATIVE CLOUD',
      amount: -52.99,
      currency: 'CAD',
      category: 'Software Subscriptions',
      type: 'expense',
      status: 'completed',
      isRecurring: true,
      tags: ['tax-deductible', 'recurring'],
      clientId: 'client1'
    },
    {
      id: '3',
      date: '2024-01-13',
      description: 'CLIENT PAYMENT - ABC CORP',
      amount: 2500.00,
      currency: 'CAD',
      category: 'Professional Services',
      type: 'income',
      status: 'completed',
      tags: ['business-income'],
      clientId: 'client1'
    }
  ];

  const automationStats = {
    totalProcessed: 1247,
    accuracyRate: 94.5,
    timeSaved: 23.5,
    categorizedToday: 15
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      processFile(file);
    }
  };

  const processFile = async (file: File) => {
    setIsProcessing(true);
    // Simulate AI processing
    setTimeout(() => {
      setIsProcessing(false);
      alert(`Successfully processed ${file.name}! Found 23 transactions, categorized 21 automatically.`);
    }, 3000);
  };

  const handleBulkCategorize = async () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      alert('Bulk categorization complete! Processed 156 uncategorized transactions.');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-caramel-50 to-nescafe-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-caramel-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-caramel-600 hover:text-caramel-700 transition-colors font-medium"
              >
                ← Back to Dashboard
              </button>
              <h1 className="text-2xl font-bold text-coffee-900">Automated Financial Manager</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-green-100 text-green-800 px-3 py-1 rounded-full border border-green-200">
                <Brain className="w-4 h-4" />
                <span className="text-sm font-medium">AI Active</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-caramel-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Transactions Processed</p>
                <p className="text-2xl font-bold text-blue-600">{automationStats.totalProcessed.toLocaleString()}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">AI Accuracy Rate</p>
                <p className="text-2xl font-bold text-green-600">{automationStats.accuracyRate}%</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Brain className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Hours Saved</p>
                <p className="text-2xl font-bold text-purple-600">{automationStats.timeSaved}h</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Categorized Today</p>
                <p className="text-2xl font-bold text-amber-600">{automationStats.categorizedToday}</p>
              </div>
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                <Tag className="w-6 h-6 text-amber-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'automation', label: 'Smart Automation', icon: Brain },
                { id: 'upload', label: 'File Upload', icon: Upload },
                { id: 'categories', label: 'Smart Categories', icon: Tag },
                { id: 'processed', label: 'Processed Transactions', icon: CheckCircle },
                { id: 'settings', label: 'AI Settings', icon: Settings }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.id
                      ? 'text-amber-600 border-b-2 border-amber-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'automation' && (
              <div className="space-y-6">
                <div className="text-center">
                  <Brain className="w-16 h-16 text-amber-600 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">AI-Powered Financial Automation</h3>
                  <p className="text-gray-600 max-w-2xl mx-auto">
                    Our advanced AI automatically categorizes your transactions, identifies patterns, 
                    and learns from your preferences to save you hours of manual work.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Zap className="w-5 h-5 text-blue-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">Auto-Categorization</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Automatically categorize transactions based on merchant names, amounts, and patterns.
                    </p>
                    <button 
                      onClick={handleBulkCategorize}
                      disabled={isProcessing}
                      className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                    >
                      {isProcessing ? 'Processing...' : 'Run Bulk Categorization'}
                    </button>
                  </div>

                  <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      </div>
                      <h4 className="text-lg font-semibold text-gray-900">Pattern Recognition</h4>
                    </div>
                    <p className="text-gray-600 mb-4">
                      Identify recurring transactions, seasonal patterns, and spending trends automatically.
                    </p>
                    <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors">
                      Analyze Patterns
                    </button>
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-amber-800">AI Learning System</h4>
                      <p className="text-amber-700 mt-1">
                        The AI continuously learns from your corrections and preferences. The more you use it, 
                        the more accurate it becomes at categorizing your specific business transactions.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'upload' && (
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload Financial Documents</h3>
                  <p className="text-gray-600">
                    Upload bank statements, receipts, or CSV files. Our AI will automatically extract and categorize transactions.
                  </p>
                </div>

                <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-amber-400 transition-colors">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-medium text-gray-900 mb-2">Drop files here or click to upload</h4>
                  <p className="text-gray-600 mb-4">Supports: PDF, CSV, XLS, XLSX, QIF, OFX</p>
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    accept=".pdf,.csv,.xls,.xlsx,.qif,.ofx"
                    className="hidden"
                    id="file-upload"
                  />
                  <label
                    htmlFor="file-upload"
                    className="bg-amber-600 text-white px-6 py-2 rounded-lg hover:bg-amber-700 transition-colors cursor-pointer inline-block"
                  >
                    Choose Files
                  </label>
                </div>

                {uploadedFile && (
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                    <div className="flex items-center space-x-3">
                      <FileText className="w-5 h-5 text-blue-600" />
                      <div className="flex-1">
                        <p className="font-medium text-blue-900">{uploadedFile.name}</p>
                        <p className="text-sm text-blue-700">
                          {isProcessing ? 'Processing with AI...' : 'Ready to process'}
                        </p>
                      </div>
                      {isProcessing && (
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                      )}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Brain className="w-6 h-6 text-green-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">AI Processing</h4>
                    <p className="text-sm text-gray-600">Advanced OCR and NLP extract transaction data</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <Tag className="w-6 h-6 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">Auto-Categorization</h4>
                    <p className="text-sm text-gray-600">Transactions are automatically categorized</p>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
                      <CheckCircle className="w-6 h-6 text-purple-600" />
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">Review & Approve</h4>
                    <p className="text-sm text-gray-600">Quick review and approval process</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'categories' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">Smart Categories</h3>
                  <button className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2">
                    <Plus className="w-4 h-4" />
                    <span>Add Category</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {smartCategories.map((category) => (
                    <div key={category.id} className="bg-gray-50 rounded-xl p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h4 className="font-semibold text-gray-900">{category.name}</h4>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              category.type === 'income' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                            }`}>
                              {category.type}
                            </span>
                            {category.taxDeductible && (
                              <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                                Tax Deductible
                              </span>
                            )}
                          </div>
                          <div className="mb-3">
                            <p className="text-sm text-gray-600 mb-2">Keywords:</p>
                            <div className="flex flex-wrap gap-2">
                              {category.keywords.map((keyword, index) => (
                                <span key={index} className="bg-white px-2 py-1 rounded text-xs text-gray-700 border">
                                  {keyword}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button className="text-amber-600 hover:text-amber-700 p-2">
                            <Edit className="w-4 h-4" />
                          </button>
                          <button className="text-red-600 hover:text-red-700 p-2">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'processed' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-gray-900">Processed Transactions</h3>
                  <div className="flex space-x-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search transactions..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                      />
                    </div>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Filter className="w-4 h-4" />
                      <span>Filter</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Download className="w-4 h-4" />
                      <span>Export</span>
                    </button>
                  </div>
                </div>

                <div className="space-y-3">
                  {processedTransactions.map((transaction) => (
                    <div key={transaction.id} className="bg-white border border-gray-200 rounded-xl p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                          }`}>
                            {transaction.type === 'income' ? 
                              <TrendingUp className="w-5 h-5 text-green-600" /> :
                              <TrendingUp className="w-5 h-5 text-red-600 transform rotate-180" />
                            }
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{transaction.description}</p>
                            <div className="flex items-center space-x-2 mt-1">
                              <span className="text-sm text-gray-600">{transaction.category}</span>
                              <span className="text-sm text-gray-400">•</span>
                              <span className="text-sm text-gray-600">{transaction.date}</span>
                              {transaction.isRecurring && (
                                <>
                                  <span className="text-sm text-gray-400">•</span>
                                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                                    Recurring
                                  </span>
                                </>
                              )}
                            </div>
                            {transaction.tags && (
                              <div className="flex space-x-1 mt-2">
                                {transaction.tags.map((tag, index) => (
                                  <span key={index} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-semibold text-lg ${
                            transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {transaction.type === 'income' ? '+' : ''}
                            ${Math.abs(transaction.amount).toLocaleString('en-CA', { minimumFractionDigits: 2 })}
                          </p>
                          <p className="text-sm text-gray-500">{transaction.currency}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">AI Automation Settings</h3>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-gray-50 rounded-xl p-6">
                    <h4 className="font-semibold text-gray-900 mb-4">Categorization Settings</h4>
                    <div className="space-y-4">
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" defaultChecked />
                        <span className="text-gray-700">Auto-categorize new transactions</span>
                      </label>
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" defaultChecked />
                        <span className="text-gray-700">Learn from manual corrections</span>
                      </label>
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" />
                        <span className="text-gray-700">Require approval for new categories</span>
                      </label>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Confidence Threshold
                        </label>
                        <input
                          type="range"
                          min="50"
                          max="100"
                          defaultValue="85"
                          className="w-full"
                        />
                        <div className="flex justify-between text-xs text-gray-500 mt-1">
                          <span>50% (More automated)</span>
                          <span>100% (More accurate)</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-6">
                    <h4 className="font-semibold text-gray-900 mb-4">Processing Settings</h4>
                    <div className="space-y-4">
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" defaultChecked />
                        <span className="text-gray-700">Process uploaded files automatically</span>
                      </label>
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" defaultChecked />
                        <span className="text-gray-700">Detect recurring transactions</span>
                      </label>
                      <label className="flex items-center space-x-3">
                        <input type="checkbox" className="rounded text-amber-600" />
                        <span className="text-gray-700">Auto-tag tax deductible expenses</span>
                      </label>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Processing Schedule
                        </label>
                        <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500">
                          <option>Real-time</option>
                          <option>Hourly</option>
                          <option>Daily</option>
                          <option>Weekly</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                  <div className="flex items-start space-x-3">
                    <Brain className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-blue-800">AI Performance</h4>
                      <p className="text-blue-700 mt-1">
                        Current accuracy: 94.5% • Processed 1,247 transactions • Learning from 156 corrections
                      </p>
                      <button className="mt-3 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
                        Retrain AI Model
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AutomatedFinancialManager;