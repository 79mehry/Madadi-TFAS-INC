import React, { useState } from 'react';
import { MessageSquare, Send, Bot, User, X, Minimize2, Maximize2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
}

const AIAssistant: React.FC = () => {
  const { t } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'ai',
      content: 'Hello! I\'m your AI accounting assistant specialized in Calgary tax laws and CRA regulations. How can I help you today?',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Calgary-specific accounting knowledge base
  const getAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    // GST/HST Questions
    if (message.includes('gst') || message.includes('hst')) {
      return `**GST/HST Filing Deadlines for 2024:**
      
• **Monthly filers**: Last day of the month following the reporting period
• **Quarterly filers**: 
  - Q1 (Jan-Mar): April 30, 2024
  - Q2 (Apr-Jun): July 31, 2024
  - Q3 (Jul-Sep): October 31, 2024
  - Q4 (Oct-Dec): January 31, 2025
• **Annual filers**: December 31, 2024

**Current GST/HST Rate in Alberta**: 5% (GST only, no provincial sales tax)

**Registration threshold**: $30,000 in taxable supplies over 4 consecutive quarters.`;
    }
    
    // Corporate Registration
    if (message.includes('register') || message.includes('corporation') || message.includes('incorporate')) {
      return `**Incorporating in Alberta - Step by Step:**

1. **Choose Business Structure**:
   - Alberta Corporation
   - Federal Corporation
   - Partnership
   - Sole Proprietorship

2. **Required Documents**:
   - Articles of Incorporation
   - Notice of Address
   - Notice of Directors

3. **Costs** (2024):
   - Alberta Corporation: $275
   - Federal Corporation: $200
   - Name reservation: $30

4. **Timeline**: 1-3 business days online

5. **Post-Incorporation**:
   - Get Business Number from CRA
   - Register for GST/HST (if applicable)
   - Open business bank account
   - Get business licenses

**Need help?** We can handle the entire process for you!`;
    }
    
    // Tax Deductions
    if (message.includes('deduct') || message.includes('expense') || message.includes('write off')) {
      return `**Common Business Tax Deductions in Canada:**

**Office Expenses**:
• Rent, utilities, phone, internet
• Office supplies and equipment
• Software subscriptions

**Vehicle Expenses**:
• Business use portion of vehicle costs
• Fuel, maintenance, insurance
• Parking and tolls

**Professional Services**:
• Legal and accounting fees
• Consulting and professional development
• Business insurance

**Marketing & Advertising**:
• Website development and maintenance
• Advertising costs
• Business cards and promotional materials

**Travel & Meals**:
• Business travel expenses
• 50% of business meal costs
• Accommodation for business trips

**Important**: Keep detailed records and receipts for all expenses!`;
    }
    
    // Payroll
    if (message.includes('payroll') || message.includes('remittance') || message.includes('employee')) {
      return `**Payroll Remittance Requirements in Canada:**

**Remittance Frequency**:
• **Small remitters** (<$3,000 monthly): Quarterly
• **Regular remitters** ($3,000-$25,000 monthly): Monthly by 15th
• **Accelerated remitters** (>$25,000 monthly): Twice monthly

**What to Remit**:
• Income tax deductions
• CPP contributions (employee + employer)
• EI premiums (employee + employer)

**2024 Rates**:
• **CPP**: 5.95% (employee) + 5.95% (employer)
• **EI**: 1.63% (employee) + 2.282% (employer)
• **Maximum CPP**: $3,754.45
• **Maximum EI**: $1,002.45

**Deadlines**: 15th of the month following the pay period

**Penalties**: 3-20% of amount due, plus daily compound interest`;
    }
    
    // Tax Deadlines
    if (message.includes('deadline') || message.includes('due date') || message.includes('filing')) {
      return `**Important Tax Deadlines for 2024:**

**Personal Tax Returns**:
• **Filing deadline**: April 30, 2024
• **Payment deadline**: April 30, 2024
• **Self-employed**: June 15, 2024 (filing), April 30, 2024 (payment)

**Corporate Tax Returns**:
• **Filing**: 6 months after fiscal year-end
• **Payment**: 2-3 months after fiscal year-end (depending on income)

**Quarterly Instalments**:
• March 15, June 15, September 15, December 15

**GST/HST Returns**:
• See previous GST/HST response for specific dates

**Payroll Remittances**:
• 15th of following month (regular remitters)

**RRSP Contributions**:
• March 1, 2024 (for 2023 tax year)`;
    }
    
    // Business Expenses
    if (message.includes('home office') || message.includes('work from home')) {
      return `**Home Office Deduction in Canada:**

**Two Methods**:

1. **Detailed Method**:
   • Calculate business use percentage of home
   • Deduct: utilities, rent/mortgage interest, property taxes, insurance, maintenance
   • Keep detailed records

2. **Simplified Method** (temporary COVID-19 measure extended):
   • $2 per day worked from home
   • Maximum $500 per year
   • No receipts required

**Eligibility**:
• Home office is principal place of business, OR
• Used exclusively for business and regularly for meeting clients

**2024 Update**: CRA has made the simplified method permanent for eligible employees.

**Business owners**: Can use detailed method for better deductions with proper documentation.`;
    }
    
    // Default response
    return `I specialize in Calgary accounting, tax laws, and CRA regulations. I can help you with:

• **Tax deadlines and filing requirements**
• **GST/HST registration and filing**
• **Business registration in Alberta**
• **Payroll remittance requirements**
• **Tax deductions and business expenses**
• **CRA compliance and regulations**
• **Small business tax planning**

Please ask me a specific question about any of these topics, and I'll provide detailed, up-to-date information based on current Canadian tax laws and Alberta regulations.

**Example questions**:
- "What are the GST filing deadlines for 2024?"
- "How do I register a corporation in Alberta?"
- "What business expenses can I deduct?"
- "When are payroll remittances due?"`;
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: getAIResponse(inputMessage),
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleExampleClick = (example: string) => {
    setInputMessage(example);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-amber-600 text-white p-4 rounded-full shadow-lg hover:bg-amber-700 transition-all transform hover:scale-105 z-50"
      >
        <MessageSquare className="w-6 h-6" />
      </button>
    );
  }

  return (
    <div className={`fixed bottom-6 right-6 bg-white rounded-xl shadow-2xl border border-gray-200 z-50 transition-all ${
      isMinimized ? 'w-80 h-16' : 'w-96 h-[600px]'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-amber-600 text-white rounded-t-xl">
        <div className="flex items-center space-x-2">
          <Bot className="w-5 h-5" />
          <span className="font-semibold">{t('ai.title')}</span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="hover:bg-amber-700 p-1 rounded"
          >
            {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
          <button
            onClick={() => setIsOpen(false)}
            className="hover:bg-amber-700 p-1 rounded"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {!isMinimized && (
        <>
          {/* Subtitle */}
          <div className="p-3 bg-amber-50 border-b border-gray-200">
            <p className="text-sm text-amber-700">{t('ai.subtitle')}</p>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 h-96 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex items-start space-x-2 max-w-[80%] ${
                  message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
                }`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    message.type === 'user' ? 'bg-amber-600' : 'bg-gray-200'
                  }`}>
                    {message.type === 'user' ? 
                      <User className="w-4 h-4 text-white" /> : 
                      <Bot className="w-4 h-4 text-gray-600" />
                    }
                  </div>
                  <div className={`p-3 rounded-lg ${
                    message.type === 'user' 
                      ? 'bg-amber-600 text-white' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    <div className="text-sm whitespace-pre-line">{message.content}</div>
                    <div className={`text-xs mt-1 ${
                      message.type === 'user' ? 'text-amber-100' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="flex items-start space-x-2">
                  <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-gray-600" />
                  </div>
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Example Questions */}
          {messages.length === 1 && (
            <div className="p-4 border-t border-gray-200 bg-gray-50">
              <p className="text-sm font-medium text-gray-700 mb-2">{t('ai.examples.title')}</p>
              <div className="space-y-1">
                {[
                  t('ai.example1'),
                  t('ai.example2'),
                  t('ai.example3'),
                  t('ai.example4')
                ].map((example, index) => (
                  <button
                    key={index}
                    onClick={() => handleExampleClick(example)}
                    className="block w-full text-left text-xs text-amber-600 hover:text-amber-700 hover:bg-amber-50 p-1 rounded"
                  >
                    • {example}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-4 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                placeholder={t('ai.placeholder')}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500 text-sm"
              />
              <button
                onClick={handleSendMessage}
                disabled={!inputMessage.trim() || isTyping}
                className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default AIAssistant;