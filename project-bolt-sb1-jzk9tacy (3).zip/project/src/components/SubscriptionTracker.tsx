import React, { useState } from 'react';
import { 
  CreditCard, 
  Calendar, 
  Bell, 
  TrendingUp, 
  AlertCircle,
  CheckCircle,
  Plus,
  Edit,
  Trash2,
  Search,
  Filter,
  Download,
  DollarSign,
  Clock,
  Zap,
  Pause,
  Play,
  X
} from 'lucide-react';

interface SubscriptionTrackerProps {
  onBack: () => void;
}

interface Subscription {
  id: string;
  name: string;
  category: string;
  amount: number;
  currency: string;
  frequency: 'weekly' | 'monthly' | 'quarterly' | 'annually';
  nextPaymentDate: string;
  status: 'active' | 'paused' | 'cancelled';
  autoRenewal: boolean;
  reminderDays: number;
  description?: string;
  website?: string;
  lastPaymentDate: string;
  totalPaid: number;
}

const SubscriptionTracker: React.FC<SubscriptionTrackerProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [selectedSubscription, setSelectedSubscription] = useState<Subscription | null>(null);

  const subscriptions: Subscription[] = [
    {
      id: '1',
      name: 'QuickBooks Online',
      category: 'Accounting Software',
      amount: 89.99,
      currency: 'CAD',
      frequency: 'monthly',
      nextPaymentDate: '2024-02-15',
      status: 'active',
      autoRenewal: true,
      reminderDays: 3,
      description: 'Professional accounting software',
      website: 'quickbooks.com',
      lastPaymentDate: '2024-01-15',
      totalPaid: 1079.88
    },
    {
      id: '2',
      name: 'Adobe Creative Cloud',
      category: 'Design Software',
      amount: 52.99,
      currency: 'CAD',
      frequency: 'monthly',
      nextPaymentDate: '2024-02-20',
      status: 'active',
      autoRenewal: true,
      reminderDays: 5,
      description: 'Creative design tools',
      website: 'adobe.com',
      lastPaymentDate: '2024-01-20',
      totalPaid: 635.88
    },
    {
      id: '3',
      name: 'Microsoft 365 Business',
      category: 'Productivity',
      amount: 22.00,
      currency: 'CAD',
      frequency: 'monthly',
      nextPaymentDate: '2024-02-10',
      status: 'active',
      autoRenewal: true,
      reminderDays: 7,
      description: 'Office productivity suite',
      website: 'microsoft.com',
      lastPaymentDate: '2024-01-10',
      totalPaid: 264.00
    },
    {
      id: '4',
      name: 'Dropbox Business',
      category: 'Cloud Storage',
      amount: 15.00,
      currency: 'CAD',
      frequency: 'monthly',
      nextPaymentDate: '2024-02-25',
      status: 'paused',
      autoRenewal: false,
      reminderDays: 3,
      description: 'Cloud file storage and sharing',
      website: 'dropbox.com',
      lastPaymentDate: '2023-12-25',
      totalPaid: 180.00
    },
    {
      id: '5',
      name: 'Zoom Pro',
      category: 'Communication',
      amount: 19.99,
      currency: 'CAD',
      frequency: 'monthly',
      nextPaymentDate: '2024-02-05',
      status: 'active',
      autoRenewal: true,
      reminderDays: 2,
      description: 'Video conferencing platform',
      website: 'zoom.us',
      lastPaymentDate: '2024-01-05',
      totalPaid: 239.88
    },
    {
      id: '6',
      name: 'Slack Pro',
      category: 'Communication',
      amount: 8.75,
      currency: 'CAD',
      frequency: 'monthly',
      nextPaymentDate: '2024-02-12',
      status: 'cancelled',
      autoRenewal: false,
      reminderDays: 0,
      description: 'Team communication tool',
      website: 'slack.com',
      lastPaymentDate: '2023-11-12',
      totalPaid: 105.00
    }
  ];

  const categories = [
    'All Categories',
    'Accounting Software',
    'Design Software',
    'Productivity',
    'Cloud Storage',
    'Communication',
    'Marketing',
    'Security',
    'Development Tools'
  ];

  const calculateMonthlyTotal = () => {
    return subscriptions
      .filter(sub => sub.status === 'active')
      .reduce((total, sub) => {
        const monthlyAmount = sub.frequency === 'monthly' ? sub.amount :
                             sub.frequency === 'quarterly' ? sub.amount / 3 :
                             sub.frequency === 'annually' ? sub.amount / 12 :
                             sub.amount * 4.33; // weekly
        return total + monthlyAmount;
      }, 0);
  };

  const calculateAnnualTotal = () => {
    return calculateMonthlyTotal() * 12;
  };

  const getUpcomingPayments = () => {
    const today = new Date();
    const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    return subscriptions
      .filter(sub => sub.status === 'active')
      .filter(sub => {
        const paymentDate = new Date(sub.nextPaymentDate);
        return paymentDate <= nextWeek;
      })
      .sort((a, b) => new Date(a.nextPaymentDate).getTime() - new Date(b.nextPaymentDate).getTime());
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="w-4 h-4" />;
      case 'paused': return <Pause className="w-4 h-4" />;
      case 'cancelled': return <X className="w-4 h-4" />;
      default: return <Clock className="w-4 h-4" />;
    }
  };

  const formatCurrency = (amount: number, currency: string = 'CAD') => {
    return new Intl.NumberFormat('en-CA', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2
    }).format(amount);
  };

  const getDaysUntilPayment = (paymentDate: string) => {
    const today = new Date();
    const payment = new Date(paymentDate);
    const diffTime = payment.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const handleSubscriptionAction = (action: 'pause' | 'resume' | 'cancel', subscriptionId: string) => {
    // This would update the subscription status
    console.log(`${action} subscription ${subscriptionId}`);
    // Show notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.textContent = `✅ Subscription ${action}d successfully!`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 3000);
  };

  const SubscriptionForm = () => (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Service Name</label>
          <input
            type="text"
            defaultValue={selectedSubscription?.name}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
            placeholder="e.g., Netflix, Spotify"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
          <select
            defaultValue={selectedSubscription?.category}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
          >
            {categories.slice(1).map(category => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Amount</label>
          <input
            type="number"
            step="0.01"
            defaultValue={selectedSubscription?.amount}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
            placeholder="0.00"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
          <select
            defaultValue={selectedSubscription?.currency || 'CAD'}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
          >
            <option value="CAD">CAD</option>
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Frequency</label>
          <select
            defaultValue={selectedSubscription?.frequency}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
          >
            <option value="weekly">Weekly</option>
            <option value="monthly">Monthly</option>
            <option value="quarterly">Quarterly</option>
            <option value="annually">Annually</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Next Payment Date</label>
          <input
            type="date"
            defaultValue={selectedSubscription?.nextPaymentDate}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Reminder (days before)</label>
          <input
            type="number"
            defaultValue={selectedSubscription?.reminderDays || 3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
            placeholder="3"
          />
        </div>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Website (optional)</label>
        <input
          type="url"
          defaultValue={selectedSubscription?.website}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
          placeholder="https://example.com"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Description (optional)</label>
        <textarea
          defaultValue={selectedSubscription?.description}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
          placeholder="Brief description of the service"
        />
      </div>
      
      <div className="flex items-center space-x-4">
        <label className="flex items-center space-x-2">
          <input
            type="checkbox"
            defaultChecked={selectedSubscription?.autoRenewal}
            className="rounded text-caramel-600 focus:ring-caramel-500"
          />
          <span className="text-sm font-medium text-gray-700">Auto-renewal enabled</span>
        </label>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-caramel-50 to-nescafe-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-caramel-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-caramel-600 hover:text-caramel-700 transition-colors font-medium"
              >
                ← Back to Dashboard
              </button>
              <h1 className="text-2xl font-bold text-coffee-900">Subscription Tracker</h1>
            </div>
            <button
              onClick={() => {
                setSelectedSubscription(null);
                setShowSubscriptionModal(true);
              }}
              className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors flex items-center space-x-2 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>Add Subscription</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-caramel-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Monthly Total</p>
                <p className="text-2xl font-bold text-blue-600">
                  {formatCurrency(calculateMonthlyTotal())}
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Annual Total</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(calculateAnnualTotal())}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Subscriptions</p>
                <p className="text-2xl font-bold text-green-600">
                  {subscriptions.filter(sub => sub.status === 'active').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Upcoming Payments</p>
                <p className="text-2xl font-bold text-orange-600">
                  {getUpcomingPayments().length}
                </p>
              </div>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <Bell className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-sm">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview', icon: CreditCard },
                { id: 'subscriptions', label: 'All Subscriptions', icon: Calendar },
                { id: 'upcoming', label: 'Upcoming Payments', icon: Bell },
                { id: 'analytics', label: 'Analytics', icon: TrendingUp }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 font-medium text-sm flex items-center space-x-2 ${
                    activeTab === tab.id
                      ? 'text-caramel-600 border-b-2 border-caramel-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Upcoming Payments */}
                  <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">Upcoming Payments (Next 7 Days)</h3>
                    <div className="space-y-3">
                      {getUpcomingPayments().slice(0, 5).map((subscription) => (
                        <div key={subscription.id} className="flex items-center justify-between p-3 bg-white rounded-lg border border-caramel-100">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-caramel-100 rounded-lg flex items-center justify-center">
                              <CreditCard className="w-5 h-5 text-caramel-600" />
                            </div>
                            <div>
                              <p className="font-medium text-coffee-900">{subscription.name}</p>
                              <p className="text-sm text-coffee-600">{subscription.category}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-coffee-900">{formatCurrency(subscription.amount)}</p>
                            <p className="text-sm text-coffee-600">
                              {getDaysUntilPayment(subscription.nextPaymentDate)} days
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Category Breakdown */}
                  <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">Spending by Category</h3>
                    <div className="space-y-3">
                      {categories.slice(1, 6).map((category, index) => {
                        const categorySubscriptions = subscriptions.filter(sub => 
                          sub.category === category && sub.status === 'active'
                        );
                        const categoryTotal = categorySubscriptions.reduce((sum, sub) => {
                          const monthlyAmount = sub.frequency === 'monthly' ? sub.amount :
                                             sub.frequency === 'quarterly' ? sub.amount / 3 :
                                             sub.frequency === 'annually' ? sub.amount / 12 :
                                             sub.amount * 4.33;
                          return sum + monthlyAmount;
                        }, 0);
                        
                        if (categoryTotal === 0) return null;
                        
                        const percentage = (categoryTotal / calculateMonthlyTotal()) * 100;
                        
                        return (
                          <div key={category} className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <div className="w-4 h-4 bg-caramel-600 rounded-full"></div>
                              <span className="text-coffee-700">{category}</span>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold text-coffee-900">{formatCurrency(categoryTotal)}</div>
                              <div className="text-sm text-coffee-600">{percentage.toFixed(1)}%</div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                  <h3 className="text-lg font-semibold text-coffee-900 mb-4">Quick Actions</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <button className="bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Plus className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">Add Subscription</p>
                          <p className="text-sm text-coffee-600">Track a new service</p>
                        </div>
                      </div>
                    </button>
                    
                    <button className="bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                          <Download className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">Export Data</p>
                          <p className="text-sm text-coffee-600">Download subscription report</p>
                        </div>
                      </div>
                    </button>
                    
                    <button className="bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                          <Bell className="w-5 h-5 text-purple-600" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">Set Reminders</p>
                          <p className="text-sm text-coffee-600">Manage notifications</p>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'subscriptions' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">All Subscriptions</h3>
                  <div className="flex space-x-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search subscriptions..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
                      />
                    </div>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Filter className="w-4 h-4" />
                      <span>Filter</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Download className="w-4 h-4" />
                      <span>Export</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {subscriptions.map((subscription) => (
                    <div key={subscription.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-12 h-12 bg-caramel-100 rounded-lg flex items-center justify-center">
                            <CreditCard className="w-6 h-6 text-caramel-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-coffee-900">{subscription.name}</h4>
                            <p className="text-sm text-coffee-600">{subscription.category}</p>
                          </div>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium flex items-center space-x-1 ${getStatusColor(subscription.status)}`}>
                          {getStatusIcon(subscription.status)}
                          <span>{subscription.status}</span>
                        </span>
                      </div>
                      
                      <div className="space-y-3 mb-4">
                        <div className="flex justify-between">
                          <span className="text-coffee-600">Amount:</span>
                          <span className="font-semibold text-coffee-900">
                            {formatCurrency(subscription.amount)} / {subscription.frequency}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-coffee-600">Next payment:</span>
                          <span className="font-medium text-coffee-900">{subscription.nextPaymentDate}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-coffee-600">Total paid:</span>
                          <span className="font-medium text-coffee-900">{formatCurrency(subscription.totalPaid)}</span>
                        </div>
                        {subscription.autoRenewal && (
                          <div className="flex items-center space-x-2">
                            <Zap className="w-4 h-4 text-green-600" />
                            <span className="text-sm text-green-600">Auto-renewal enabled</span>
                          </div>
                        )}
                      </div>
                      
                      <div className="flex space-x-2">
                        <button
                          onClick={() => {
                            setSelectedSubscription(subscription);
                            setShowSubscriptionModal(true);
                          }}
                          className="flex-1 text-caramel-600 hover:text-caramel-700 px-3 py-2 border border-caramel-600 rounded-lg hover:bg-caramel-50 transition-colors text-sm"
                        >
                          Edit
                        </button>
                        {subscription.status === 'active' ? (
                          <button
                            onClick={() => handleSubscriptionAction('pause', subscription.id)}
                            className="px-3 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors text-sm"
                          >
                            <Pause className="w-4 h-4" />
                          </button>
                        ) : subscription.status === 'paused' ? (
                          <button
                            onClick={() => handleSubscriptionAction('resume', subscription.id)}
                            className="px-3 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors text-sm"
                          >
                            <Play className="w-4 h-4" />
                          </button>
                        ) : null}
                        <button
                          onClick={() => handleSubscriptionAction('cancel', subscription.id)}
                          className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'upcoming' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-coffee-900">Upcoming Payments</h3>
                
                <div className="space-y-4">
                  {getUpcomingPayments().map((subscription) => (
                    <div key={subscription.id} className="bg-white border border-gray-200 rounded-xl p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-caramel-100 rounded-lg flex items-center justify-center">
                            <CreditCard className="w-6 h-6 text-caramel-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-coffee-900">{subscription.name}</h4>
                            <p className="text-coffee-600">{subscription.category}</p>
                            <div className="flex items-center space-x-4 mt-1 text-sm text-coffee-500">
                              <span>Due: {subscription.nextPaymentDate}</span>
                              <span>•</span>
                              <span>{getDaysUntilPayment(subscription.nextPaymentDate)} days remaining</span>
                              <span>•</span>
                              <span className="capitalize">{subscription.frequency}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-coffee-900">{formatCurrency(subscription.amount)}</p>
                          <p className="text-sm text-coffee-600">{subscription.currency}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-coffee-900">Subscription Analytics</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h4 className="font-semibold text-coffee-900 mb-4">Monthly Spending Trend</h4>
                    <div className="text-center py-8">
                      <TrendingUp className="w-16 h-16 text-caramel-600 mx-auto mb-4" />
                      <p className="text-coffee-600">Chart visualization would go here</p>
                      <p className="text-sm text-coffee-500 mt-2">
                        Current monthly total: {formatCurrency(calculateMonthlyTotal())}
                      </p>
                    </div>
                  </div>
                  
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h4 className="font-semibold text-coffee-900 mb-4">Cost Optimization</h4>
                    <div className="space-y-3">
                      <div className="p-3 bg-yellow-50 rounded-lg">
                        <p className="font-medium text-yellow-800">Potential Savings</p>
                        <p className="text-sm text-yellow-700">
                          You have {subscriptions.filter(s => s.status === 'paused').length} paused subscriptions. 
                          Consider cancelling unused services to save {formatCurrency(150)} per month.
                        </p>
                      </div>
                      <div className="p-3 bg-blue-50 rounded-lg">
                        <p className="font-medium text-blue-800">Annual vs Monthly</p>
                        <p className="text-sm text-blue-700">
                          Switching to annual billing could save you up to {formatCurrency(240)} per year.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Subscription Modal */}
      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-coffee-900">
                {selectedSubscription ? 'Edit Subscription' : 'Add New Subscription'}
              </h3>
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <SubscriptionForm />
            
            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setShowSubscriptionModal(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  // Handle save logic here
                  setShowSubscriptionModal(false);
                }}
                className="flex-1 bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors"
              >
                {selectedSubscription ? 'Update Subscription' : 'Add Subscription'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SubscriptionTracker;