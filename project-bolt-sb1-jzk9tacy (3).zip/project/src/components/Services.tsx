import React from 'react';
import { 
  Calculator, 
  FileText, 
  TrendingUp, 
  DollarSign, 
  Building, 
  Users, 
  GraduationCap, 
  MapPin,
  BarChart3
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

const Services: React.FC = () => {
  const { t } = useLanguage();

  const services = [
    {
      id: 1,
      title: t('service.software.title'),
      description: t('service.software.description'),
      icon: Calculator,
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Software Selection", "Installation & Configuration", "Full Training", "Ongoing Support"]
    },
    {
      id: 2,
      title: t('service.bookkeeping.title'),
      description: t('service.bookkeeping.description'),
      icon: FileText,
      image: "https://images.pexels.com/photos/6863183/pexels-photo-6863183.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Financial Record-Keeping", "Financial Statements", "Bank Reconciliation", "Organized Tracking"]
    },
    {
      id: 3,
      title: "Financial and Business Consulting",
      description: "We provide consulting for business growth and development, financial planning, budgeting, profit & loss analysis and support for smart and strategic financial decisions.",
      icon: TrendingUp,
      image: "https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Business Growth Consulting", "Financial Planning", "Budgeting & P&L Analysis", "Strategic Decisions"]
    },
    {
      id: 4,
      title: "Tax Services",
      description: "We handle personal and corporate tax filings, GST/HST reports, tax optimization strategies to minimize your tax burden while ensuring full compliance.",
      icon: DollarSign,
      image: "https://images.pexels.com/photos/6863332/pexels-photo-6863332.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Personal & Corporate Tax", "GST/HST Reports", "Tax Optimization", "Compliance Assurance"]
    },
    {
      id: 5,
      title: "Company Registration and Basic Legal Services",
      description: "We guide you through choosing the right business structure, prepare required documents and complete all initial legal steps for proper business registration.",
      icon: Building,
      image: "https://images.pexels.com/photos/5668858/pexels-photo-5668858.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Business Structure Guidance", "Document Preparation", "Legal Registration Steps", "Compliance Setup"]
    },
    {
      id: 6,
      title: "Payroll Services",
      description: "We calculate salaries & benefits, generate required payroll reports, submit to the relevant authorities, & ensure compliance with all employment & tax regulations.",
      icon: Users,
      image: "https://images.pexels.com/photos/6863515/pexels-photo-6863515.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Salary & Benefits Calculation", "Payroll Reports", "Authority Submissions", "Compliance Management"]
    },
    {
      id: 7,
      title: "Accounting Training and Support",
      description: "Accounting principles & software explained clearly & practically, with ongoing support to enhance your skills & resolve challenges.",
      icon: GraduationCap,
      image: "https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Clear Practical Training", "Accounting Principles", "Skill Enhancement", "Challenge Resolution"]
    },
    {
      id: 8,
      title: "Immigrant Business Consulting",
      description: "We help newcomers understand Canada's financial & tax systems, navigate the business registration process & offer practical advice for a confident business start.",
      icon: MapPin,
      image: "https://images.pexels.com/photos/3184639/pexels-photo-3184639.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Canadian Tax System Guide", "Registration Navigation", "Practical Business Advice", "Confident Start Support"]
    },
    {
      id: 9,
      title: "Financial and Cash Flow Management",
      description: "We provide detailed cash flow planning, expense & income analysis & custom budgeting to ensure financial control and stability for your business.",
      icon: BarChart3,
      image: "https://images.pexels.com/photos/6863668/pexels-photo-6863668.jpeg?auto=compress&cs=tinysrgb&w=800",
      features: ["Detailed Cash Flow Planning", "Expense & Income Analysis", "Custom Budgeting", "Financial Stability"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-gradient-to-b from-white to-caramel-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-coffee-900 mb-4">
            {t('services.title')} <span className="bg-gradient-to-r from-caramel-600 to-nescafe-600 bg-clip-text text-transparent">{t('services.titleHighlight')}</span>
          </h2>
          <p className="text-lg text-coffee-600 max-w-2xl mx-auto">
            {t('services.description')}
          </p>
        </div>

        <div className="space-y-16">
          {services.map((service, index) => (
            <div key={service.id} className={`flex flex-col lg:flex-row items-center gap-12 ${
              index % 2 === 1 ? 'lg:flex-row-reverse' : ''
            }`}>
              <div className="lg:w-1/2">
                <div className="relative overflow-hidden rounded-2xl shadow-xl group border-4 border-white/50">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-80 object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-coffee-900/30 to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <div className="w-12 h-12 bg-white/95 backdrop-blur-sm rounded-lg flex items-center justify-center shadow-lg border border-caramel-200">
                      <service.icon className="w-6 h-6 text-caramel-600" />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="lg:w-1/2 space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-caramel-100 to-caramel-200 rounded-lg flex items-center justify-center shadow-md">
                    <service.icon className="w-6 h-6 text-caramel-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-coffee-900">{service.title}</h3>
                </div>
                
                <p className="text-coffee-600 text-lg leading-relaxed">
                  {service.description}
                </p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {service.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-full"></div>
                      <span className="text-coffee-700">{feature}</span>
                    </div>
                  ))}
                </div>
                
                <button className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-caramel-600 hover:to-nescafe-600 transition-all shadow-lg hover:shadow-xl transform hover:scale-105">
                  {t('services.learnMore')}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;