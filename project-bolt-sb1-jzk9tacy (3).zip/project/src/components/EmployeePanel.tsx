import React, { useState } from 'react';
import { 
  Users, 
  FileText, 
  Calendar, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Plus,
  Search,
  Filter,
  MessageSquare,
  Phone,
  Mail,
  User,
  Bell,
  Calculator,
  DollarSign,
  TrendingUp,
  BarChart3,
  Receipt,
  CreditCard,
  Building,
  Target,
  Briefcase,
  BookOpen,
  Settings,
  Download,
  Upload,
  Edit,
  Trash2,
  Eye,
  Send,
  Archive,
  Star,
  Award,
  Shield,
  Zap,
  Globe,
  PieChart,
  LineChart,
  Activity,
  Layers,
  Database,
  FileCheck,
  Clipboard,
  Headphones,
  Video,
  Share2
} from 'lucide-react';

interface EmployeePanelProps {
  onBack: () => void;
}

const EmployeePanel: React.FC<EmployeePanelProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedClient, setSelectedClient] = useState<any>(null);
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [showClientModal, setShowClientModal] = useState(false);

  const myStats = {
    assignedClients: 25,
    pendingTasks: 8,
    completedTasks: 42,
    upcomingDeadlines: 5,
    monthlyRevenue: 45600,
    clientSatisfaction: 4.8,
    tasksThisWeek: 15,
    billableHours: 32.5
  };

  const myClients = [
    { 
      id: '1', 
      name: 'ABC Corp', 
      contact: 'John Smith', 
      email: 'john@abc.com', 
      phone: '(403) 555-0101', 
      nextDeadline: '2024-02-15', 
      status: 'active',
      subscription: 'Professional',
      monthlyValue: 1200,
      lastContact: '2024-01-10',
      satisfaction: 5,
      tasksCompleted: 12,
      pendingTasks: 3
    },
    { 
      id: '2', 
      name: 'XYZ Ltd', 
      contact: 'Sarah Wilson', 
      email: 'sarah@xyz.com', 
      phone: '(403) 555-0102', 
      nextDeadline: '2024-02-20', 
      status: 'active',
      subscription: 'Enterprise',
      monthlyValue: 2500,
      lastContact: '2024-01-12',
      satisfaction: 4.5,
      tasksCompleted: 18,
      pendingTasks: 2
    },
    { 
      id: '3', 
      name: 'StartUp Inc', 
      contact: 'Mike Johnson', 
      email: 'mike@startup.com', 
      phone: '(403) 555-0103', 
      nextDeadline: '2024-02-18', 
      status: 'pending',
      subscription: 'Basic',
      monthlyValue: 800,
      lastContact: '2024-01-08',
      satisfaction: 4.2,
      tasksCompleted: 8,
      pendingTasks: 5
    }
  ];

  const myTasks = [
    { 
      id: '1', 
      title: 'Prepare GST/HST Return', 
      client: 'ABC Corp', 
      dueDate: '2024-02-15', 
      priority: 'high', 
      status: 'pending',
      estimatedHours: 4,
      billableRate: 85,
      category: 'Tax Filing',
      description: 'Quarterly GST/HST return preparation and filing'
    },
    { 
      id: '2', 
      title: 'Monthly Bookkeeping Review', 
      client: 'XYZ Ltd', 
      dueDate: '2024-02-20', 
      priority: 'medium', 
      status: 'in-progress',
      estimatedHours: 6,
      billableRate: 75,
      category: 'Bookkeeping',
      description: 'Review and reconcile monthly financial records'
    },
    { 
      id: '3', 
      title: 'Tax Planning Consultation', 
      client: 'StartUp Inc', 
      dueDate: '2024-02-18', 
      priority: 'high', 
      status: 'pending',
      estimatedHours: 2,
      billableRate: 95,
      category: 'Consulting',
      description: 'Strategic tax planning session for 2024'
    },
    { 
      id: '4', 
      title: 'Payroll Processing', 
      client: 'ABC Corp', 
      dueDate: '2024-02-16', 
      priority: 'medium', 
      status: 'completed',
      estimatedHours: 3,
      billableRate: 70,
      category: 'Payroll',
      description: 'Bi-weekly payroll processing and remittances'
    }
  ];

  const upcomingDeadlines = [
    { client: 'ABC Corp', type: 'GST/HST Return', date: '2024-02-15', daysLeft: 3, priority: 'high' },
    { client: 'StartUp Inc', type: 'Corporate Tax', date: '2024-02-18', daysLeft: 6, priority: 'high' },
    { client: 'XYZ Ltd', type: 'Payroll Remittance', date: '2024-02-20', daysLeft: 8, priority: 'medium' },
    { client: 'Tech Solutions', type: 'Monthly Reports', date: '2024-02-22', daysLeft: 10, priority: 'low' },
    { client: 'Retail Plus', type: 'Tax Filing', date: '2024-02-25', daysLeft: 13, priority: 'medium' }
  ];

  const recentActivities = [
    { id: '1', action: 'Completed GST filing for ABC Corp', time: '2 hours ago', type: 'success' },
    { id: '2', action: 'Started bookkeeping review for XYZ Ltd', time: '4 hours ago', type: 'info' },
    { id: '3', action: 'Client meeting scheduled with StartUp Inc', time: '1 day ago', type: 'info' },
    { id: '4', action: 'Submitted monthly reports for Tech Solutions', time: '2 days ago', type: 'success' },
    { id: '5', action: 'Deadline reminder sent to Retail Plus', time: '3 days ago', type: 'warning' }
  ];

  const accountingTools = [
    { 
      name: 'Tax Calculator', 
      description: 'Calculate taxes for individuals and corporations',
      icon: Calculator,
      color: 'from-caramel-500 to-nescafe-500'
    },
    { 
      name: 'Financial Analyzer', 
      description: 'Analyze client financial statements and ratios',
      icon: BarChart3,
      color: 'from-blue-500 to-blue-600'
    },
    { 
      name: 'Expense Categorizer', 
      description: 'Automatically categorize business expenses',
      icon: Receipt,
      color: 'from-green-500 to-green-600'
    },
    { 
      name: 'Payroll Calculator', 
      description: 'Calculate payroll taxes and deductions',
      icon: DollarSign,
      color: 'from-purple-500 to-purple-600'
    },
    { 
      name: 'Compliance Checker', 
      description: 'Verify CRA and provincial compliance',
      icon: Shield,
      color: 'from-red-500 to-red-600'
    },
    { 
      name: 'Report Generator', 
      description: 'Generate professional financial reports',
      icon: FileText,
      color: 'from-indigo-500 to-indigo-600'
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'in-progress': return 'text-blue-600 bg-blue-100';
      case 'pending': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'success': return 'text-green-600 bg-green-100';
      case 'warning': return 'text-yellow-600 bg-yellow-100';
      case 'info': return 'text-blue-600 bg-blue-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-caramel-50 to-nescafe-50">
      <div className="bg-white shadow-sm border-b border-caramel-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-caramel-600 hover:text-caramel-700 transition-colors font-medium"
              >
                ← Back to Website
              </button>
              <h1 className="text-2xl font-bold text-coffee-900">Employee Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Bell className="w-6 h-6 text-coffee-600" />
                <span className="absolute -top-2 -right-2 w-4 h-4 bg-red-500 rounded-full text-white text-xs flex items-center justify-center">3</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-caramel-100 to-caramel-200 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-caramel-600" />
                </div>
                <span className="text-coffee-700 font-medium">Sarah Johnson</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-xl shadow-sm border border-caramel-200">
          <div className="border-b border-caramel-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'dashboard', label: 'Dashboard', icon: BarChart3 },
                { id: 'clients', label: 'My Clients', icon: Users },
                { id: 'tasks', label: 'Tasks & Projects', icon: FileText },
                { id: 'tools', label: 'Accounting Tools', icon: Calculator },
                { id: 'deadlines', label: 'Deadlines', icon: Clock },
                { id: 'reports', label: 'Client Reports', icon: PieChart },
                { id: 'communication', label: 'Client Communication', icon: MessageSquare },
                { id: 'training', label: 'Training & Resources', icon: BookOpen },
                { id: 'performance', label: 'Performance', icon: Award }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 font-medium text-sm flex items-center space-x-2 transition-colors ${
                    activeTab === tab.id
                      ? 'text-caramel-600 border-b-2 border-caramel-600'
                      : 'text-coffee-500 hover:text-coffee-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                {/* Enhanced Stats Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-r from-caramel-50 to-nescafe-50 p-6 rounded-xl border border-caramel-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-caramel-600 font-medium">My Clients</p>
                        <p className="text-2xl font-bold text-coffee-900">{myStats.assignedClients}</p>
                        <p className="text-sm text-coffee-600">+3 this month</p>
                      </div>
                      <Users className="w-8 h-8 text-caramel-600" />
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-blue-600 font-medium">Billable Hours</p>
                        <p className="text-2xl font-bold text-coffee-900">{myStats.billableHours}h</p>
                        <p className="text-sm text-coffee-600">This week</p>
                      </div>
                      <Clock className="w-8 h-8 text-blue-600" />
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-green-600 font-medium">Monthly Revenue</p>
                        <p className="text-2xl font-bold text-coffee-900">${myStats.monthlyRevenue.toLocaleString()}</p>
                        <p className="text-sm text-coffee-600">+12% vs last month</p>
                      </div>
                      <DollarSign className="w-8 h-8 text-green-600" />
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-purple-600 font-medium">Client Satisfaction</p>
                        <p className="text-2xl font-bold text-coffee-900">{myStats.clientSatisfaction}/5</p>
                        <p className="text-sm text-coffee-600">Excellent rating</p>
                      </div>
                      <Star className="w-8 h-8 text-purple-600" />
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                  <h3 className="text-lg font-semibold text-coffee-900 mb-4">Quick Actions</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <button className="bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-lg flex items-center justify-center">
                          <Plus className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">New Task</p>
                          <p className="text-sm text-coffee-600">Create a new client task</p>
                        </div>
                      </div>
                    </button>
                    
                    <button className="bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                          <Calculator className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">Tax Calculator</p>
                          <p className="text-sm text-coffee-600">Calculate client taxes</p>
                        </div>
                      </div>
                    </button>
                    
                    <button className="bg-white border border-caramel-200 rounded-lg p-4 text-left hover:bg-caramel-50 transition-colors">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-green-600 rounded-lg flex items-center justify-center">
                          <FileText className="w-5 h-5 text-white" />
                        </div>
                        <div>
                          <p className="font-medium text-coffee-900">Generate Report</p>
                          <p className="text-sm text-coffee-600">Create client reports</p>
                        </div>
                      </div>
                    </button>
                  </div>
                </div>

                {/* Recent Activities and Upcoming Deadlines */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white border border-caramel-200 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">Recent Activities</h3>
                    <div className="space-y-3">
                      {recentActivities.map((activity) => (
                        <div key={activity.id} className="flex items-center space-x-3 p-3 bg-caramel-50 rounded-lg">
                          <div className={`w-2 h-2 rounded-full ${getActivityColor(activity.type).split(' ')[1]}`}></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium text-coffee-900">{activity.action}</p>
                            <p className="text-xs text-coffee-600">{activity.time}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white border border-caramel-200 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">Upcoming Deadlines</h3>
                    <div className="space-y-3">
                      {upcomingDeadlines.slice(0, 5).map((deadline, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-caramel-50 rounded-lg">
                          <div>
                            <p className="font-medium text-coffee-900">{deadline.client}</p>
                            <p className="text-sm text-coffee-600">{deadline.type}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-sm font-medium text-coffee-900">{deadline.date}</p>
                            <p className={`text-xs ${deadline.daysLeft <= 5 ? 'text-red-600' : 'text-coffee-600'}`}>
                              {deadline.daysLeft} days left
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'tools' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Professional Accounting Tools</h3>
                  <button className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors">
                    Request New Tool
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {accountingTools.map((tool, index) => (
                    <div key={index} className="bg-white border border-caramel-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
                      <div className="flex items-center space-x-3 mb-4">
                        <div className={`w-12 h-12 bg-gradient-to-r ${tool.color} rounded-lg flex items-center justify-center`}>
                          <tool.icon className="w-6 h-6 text-white" />
                        </div>
                        <h4 className="text-lg font-semibold text-coffee-900">{tool.name}</h4>
                      </div>
                      <p className="text-coffee-600 mb-4">{tool.description}</p>
                      <button className="w-full bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors">
                        Launch Tool
                      </button>
                    </div>
                  ))}
                </div>

                {/* Advanced Tools Section */}
                <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                  <h4 className="text-lg font-semibold text-coffee-900 mb-4">Advanced Professional Tools</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white rounded-lg p-4 border border-caramel-200">
                      <h5 className="font-semibold text-coffee-900 mb-2">Financial Statement Analyzer</h5>
                      <p className="text-sm text-coffee-600 mb-3">Comprehensive analysis of client financial statements with ratio calculations and trend analysis.</p>
                      <button className="text-caramel-600 hover:text-caramel-700 font-medium text-sm">Launch Analyzer →</button>
                    </div>
                    <div className="bg-white rounded-lg p-4 border border-caramel-200">
                      <h5 className="font-semibold text-coffee-900 mb-2">Tax Optimization Engine</h5>
                      <p className="text-sm text-coffee-600 mb-3">AI-powered tax optimization suggestions and deduction maximization strategies.</p>
                      <button className="text-caramel-600 hover:text-caramel-700 font-medium text-sm">Start Optimization →</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'communication' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Client Communication Center</h3>
                  <div className="flex space-x-3">
                    <button className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors flex items-center space-x-2">
                      <MessageSquare className="w-4 h-4" />
                      <span>New Message</span>
                    </button>
                    <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                      <Video className="w-4 h-4" />
                      <span>Schedule Meeting</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 bg-white border border-caramel-200 rounded-xl p-6">
                    <h4 className="font-semibold text-coffee-900 mb-4">Recent Communications</h4>
                    <div className="space-y-4">
                      {[
                        { client: 'ABC Corp', type: 'Email', subject: 'GST Return Completed', time: '2 hours ago', status: 'sent' },
                        { client: 'XYZ Ltd', type: 'Meeting', subject: 'Monthly Review Session', time: '1 day ago', status: 'completed' },
                        { client: 'StartUp Inc', type: 'Call', subject: 'Tax Planning Discussion', time: '2 days ago', status: 'scheduled' }
                      ].map((comm, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-caramel-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-r from-caramel-100 to-caramel-200 rounded-lg flex items-center justify-center">
                              {comm.type === 'Email' && <Mail className="w-5 h-5 text-caramel-600" />}
                              {comm.type === 'Meeting' && <Video className="w-5 h-5 text-caramel-600" />}
                              {comm.type === 'Call' && <Phone className="w-5 h-5 text-caramel-600" />}
                            </div>
                            <div>
                              <p className="font-medium text-coffee-900">{comm.client}</p>
                              <p className="text-sm text-coffee-600">{comm.subject}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-coffee-600">{comm.time}</p>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              comm.status === 'sent' ? 'bg-green-100 text-green-800' :
                              comm.status === 'completed' ? 'bg-blue-100 text-blue-800' :
                              'bg-yellow-100 text-yellow-800'
                            }`}>
                              {comm.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white border border-caramel-200 rounded-xl p-6">
                    <h4 className="font-semibold text-coffee-900 mb-4">Communication Templates</h4>
                    <div className="space-y-3">
                      {[
                        'Tax Return Completion Notice',
                        'Payment Reminder',
                        'Meeting Confirmation',
                        'Document Request',
                        'Deadline Alert'
                      ].map((template, index) => (
                        <button key={index} className="w-full text-left p-3 bg-caramel-50 rounded-lg hover:bg-caramel-100 transition-colors">
                          <p className="text-sm font-medium text-coffee-900">{template}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'performance' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-coffee-900">Performance Analytics</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-gradient-to-r from-caramel-50 to-nescafe-50 p-6 rounded-xl border border-caramel-200">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-coffee-900">This Month</h4>
                      <TrendingUp className="w-5 h-5 text-caramel-600" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Tasks Completed:</span>
                        <span className="font-medium text-coffee-900">28</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Billable Hours:</span>
                        <span className="font-medium text-coffee-900">124h</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Revenue Generated:</span>
                        <span className="font-medium text-coffee-900">$9,800</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-coffee-900">Client Metrics</h4>
                      <Users className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Satisfaction Score:</span>
                        <span className="font-medium text-coffee-900">4.8/5</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Retention Rate:</span>
                        <span className="font-medium text-coffee-900">96%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Referrals:</span>
                        <span className="font-medium text-coffee-900">12</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-coffee-900">Quality Metrics</h4>
                      <Award className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Accuracy Rate:</span>
                        <span className="font-medium text-coffee-900">99.2%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">On-Time Delivery:</span>
                        <span className="font-medium text-coffee-900">98%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Error Rate:</span>
                        <span className="font-medium text-coffee-900">0.8%</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-coffee-900">Growth</h4>
                      <BarChart3 className="w-5 h-5 text-purple-600" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-coffee-600">YoY Revenue:</span>
                        <span className="font-medium text-green-600">+24%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Client Growth:</span>
                        <span className="font-medium text-green-600">+18%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-coffee-600">Efficiency:</span>
                        <span className="font-medium text-green-600">+15%</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Performance Chart Placeholder */}
                <div className="bg-white border border-caramel-200 rounded-xl p-6">
                  <h4 className="font-semibold text-coffee-900 mb-4">Performance Trends</h4>
                  <div className="h-64 bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-lg flex items-center justify-center border border-caramel-200">
                    <div className="text-center">
                      <LineChart className="w-16 h-16 text-caramel-600 mx-auto mb-4" />
                      <p className="text-coffee-600">Performance analytics chart would display here</p>
                      <p className="text-sm text-coffee-500 mt-2">Showing revenue, client satisfaction, and efficiency trends</p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Other existing tabs with enhanced styling */}
            {activeTab === 'clients' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">My Clients</h3>
                  <div className="flex space-x-3">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search clients..."
                        className="pl-10 pr-4 py-2 border border-caramel-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500"
                      />
                    </div>
                    <button className="flex items-center space-x-2 px-4 py-2 border border-caramel-300 rounded-lg hover:bg-caramel-50">
                      <Filter className="w-4 h-4" />
                      <span>Filter</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {myClients.map((client) => (
                    <div key={client.id} className="bg-white border border-caramel-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-lg font-semibold text-coffee-900">{client.name}</h4>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          client.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                        }`}>
                          {client.status}
                        </span>
                      </div>
                      
                      <div className="space-y-3">
                        <div className="flex items-center space-x-2">
                          <User className="w-4 h-4 text-caramel-400" />
                          <span className="text-coffee-700">{client.contact}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Mail className="w-4 h-4 text-caramel-400" />
                          <span className="text-coffee-700">{client.email}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4 text-caramel-400" />
                          <span className="text-coffee-700">{client.phone}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <DollarSign className="w-4 h-4 text-caramel-400" />
                          <span className="text-coffee-700">${client.monthlyValue}/month</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Star className="w-4 h-4 text-caramel-400" />
                          <span className="text-coffee-700">{client.satisfaction}/5 satisfaction</span>
                        </div>
                      </div>
                      
                      <div className="mt-4 flex space-x-2">
                        <button className="flex-1 bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors text-sm">
                          View Details
                        </button>
                        <button className="px-3 py-2 border border-caramel-300 rounded-lg hover:bg-caramel-50 transition-colors">
                          <MessageSquare className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'tasks' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Tasks & Projects</h3>
                  <button 
                    onClick={() => setShowTaskModal(true)}
                    className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors flex items-center space-x-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>New Task</span>
                  </button>
                </div>

                <div className="bg-white border border-caramel-200 rounded-xl overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gradient-to-r from-caramel-50 to-nescafe-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-coffee-500 uppercase tracking-wider">Task</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-coffee-500 uppercase tracking-wider">Client</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-coffee-500 uppercase tracking-wider">Due Date</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-coffee-500 uppercase tracking-wider">Priority</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-coffee-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-coffee-500 uppercase tracking-wider">Billable</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-coffee-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-caramel-200">
                      {myTasks.map((task) => (
                        <tr key={task.id} className="hover:bg-caramel-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div>
                              <div className="text-sm font-medium text-coffee-900">{task.title}</div>
                              <div className="text-sm text-coffee-600">{task.category}</div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-coffee-900">{task.client}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-coffee-900">{task.dueDate}</td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`}>
                              {task.priority}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(task.status)}`}>
                              {task.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-coffee-900">
                            ${task.estimatedHours * task.billableRate}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <button className="text-caramel-600 hover:text-caramel-900 mr-3">Edit</button>
                            <button className="text-green-600 hover:text-green-900">Complete</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeePanel;