import React from 'react';
import { ArrowRight, Shield, TrendingUp, Users } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface HeroProps {
  onPlans: () => void;
}

const Hero: React.FC<HeroProps> = ({ onPlans }) => {
  const { t } = useLanguage();

  return (
    <section id="home" className="relative min-h-screen bg-gradient-to-br from-caramel-50 via-nescafe-50 to-coffee-50">
      <div className="absolute inset-0 bg-gradient-to-r from-white/30 to-caramel-100/20"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Text Content */}
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-6xl font-bold text-coffee-900 mb-6">
              <span className="bg-gradient-to-r from-caramel-600 to-nescafe-600 bg-clip-text text-transparent">
                {t('hero.title')}
              </span>
              <br />
              <span className="text-coffee-800">{t('hero.subtitle')}</span>
            </h1>
            
            <p className="text-lg md:text-xl text-coffee-600 mb-8 max-w-2xl mx-auto lg:mx-0">
              {t('hero.description')}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8">
              <button 
                onClick={onPlans}
                className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-8 py-3 rounded-lg font-semibold hover:from-caramel-600 hover:to-nescafe-600 transition-all transform hover:scale-105 shadow-lg"
              >
                {t('hero.viewPlans')}
                <ArrowRight className="inline-block w-5 h-5 ml-2" />
              </button>
              <button className="border-2 border-caramel-600 text-caramel-600 px-8 py-3 rounded-lg font-semibold hover:bg-gradient-to-r hover:from-caramel-500 hover:to-nescafe-500 hover:text-white hover:border-transparent transition-all shadow-md">
                {t('hero.consultation')}
              </button>
            </div>
          </div>

          {/* Right Column - Hero Image */}
          <div className="relative">
            <div className="relative overflow-hidden rounded-2xl shadow-2xl border-4 border-white/50">
              <img 
                src="/photo_2025-07-15 16.37.18.jpeg" 
                alt="Professional business meeting with digital network visualization"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-coffee-900/20 to-transparent"></div>
            </div>
            
            {/* Floating Stats Cards */}
            <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-4 border border-caramel-200">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-r from-green-100 to-green-200 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-coffee-900">150+</p>
                  <p className="text-sm text-coffee-600">Happy Clients</p>
                </div>
              </div>
            </div>
            
            <div className="absolute -top-6 -right-6 bg-white rounded-xl shadow-xl p-4 border border-caramel-200">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-r from-caramel-100 to-caramel-200 rounded-lg flex items-center justify-center">
                  <Shield className="w-6 h-6 text-caramel-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-coffee-900">100%</p>
                  <p className="text-sm text-coffee-600">CRA Compliant</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Feature Cards - Moved Below */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20">
          <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg hover:shadow-xl transition-all hover:transform hover:scale-105 border border-caramel-100">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-caramel-100 to-caramel-200 rounded-lg flex items-center justify-center">
                <Shield className="w-6 h-6 text-caramel-600" />
              </div>
            </div>
            <h3 className="text-xl font-semibold text-coffee-800 mb-2 text-center">Secure & Compliant</h3>
            <p className="text-coffee-600 text-center">Full CRA compliance and secure handling of your financial data</p>
          </div>
          
          <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg hover:shadow-xl transition-all hover:transform hover:scale-105 border border-caramel-100">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-nescafe-100 to-nescafe-200 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-nescafe-600" />
              </div>
            </div>
            <h3 className="text-xl font-semibold text-coffee-800 mb-2 text-center">Business Growth</h3>
            <p className="text-coffee-600 text-center">Strategic financial planning to accelerate your business growth</p>
          </div>
          
          <div className="bg-white/90 backdrop-blur-sm p-6 rounded-xl shadow-lg hover:shadow-xl transition-all hover:transform hover:scale-105 border border-caramel-100">
            <div className="flex items-center justify-center mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-coffee-100 to-coffee-200 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-coffee-600" />
              </div>
            </div>
            <h3 className="text-xl font-semibold text-coffee-800 mb-2 text-center">Expert Team</h3>
            <p className="text-coffee-600 text-center">Experienced professionals dedicated to your financial success</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;