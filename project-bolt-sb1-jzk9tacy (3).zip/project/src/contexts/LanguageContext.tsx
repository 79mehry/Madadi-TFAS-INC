import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'fa' | 'es' | 'fr';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const translations: Record<Language, Record<string, any>> = {
    en: {
      // Header Translations
      header: {
        home: 'Home',
        services: 'Services',
        software: 'Software',
        pricing: 'Pricing',
        contact: 'Contact',
        login: 'Login',
        logout: 'Logout',
        dashboard: 'Dashboard',
        admin: 'Admin Panel',
        employee: 'Employee Panel'
      },
      
      // Hero Section Translations
      hero: {
        title: 'Precision in Numbers',
        subtitle: 'Vision in Finance',
        description: 'Professional accounting and financial services tailored for businesses in Calgary. We handle your numbers so you can focus on growth.',
        viewPlans: 'View Plans',
        consultation: 'Free Consultation'
      },
      
      // Services Section Translations
      services: {
        title: 'Our',
        titleHighlight: 'Services',
        description: 'Comprehensive financial and accounting solutions designed to support your business at every stage',
        learnMore: 'Learn More'
      },
      
      // Service Item Translations
      service: {
        software: {
          title: 'Accounting Software Solutions',
          description: 'We provide selection, setup, and training for the right accounting software to match your business needs.'
        },
        bookkeeping: {
          title: 'Bookkeeping Services',
          description: 'We maintain accurate financial records, prepare financial statements, and ensure your books are always in order.'
        }
      },
      
      // AI Assistant Translations
      ai: {
        title: 'Accounting Assistant',
        subtitle: 'Ask me anything about Calgary tax laws, CRA regulations, or accounting best practices',
        placeholder: 'Type your question here...',
        examples: {
          title: 'Try asking about:',
        },
        example1: 'What are the GST filing deadlines?',
        example2: 'How do I register a corporation in Alberta?',
        example3: 'What business expenses can I deduct?',
        example4: 'When are payroll remittances due?'
      },
      
      // Legal and Compliance Translations
      legal: {
        privacy: {
          title: 'Privacy Policy',
          subtitle: 'How we protect and manage your information',
          overview: {
            title: 'Overview',
            content: 'At Madadi TFAS INC, we take your privacy seriously. This policy outlines how we collect, use, and protect your personal and financial information in compliance with PIPEDA and other applicable Canadian privacy laws.'
          },
          collection: {
            title: 'Information We Collect',
            intro: 'We collect various types of information to provide our accounting and financial services:',
            personal: 'Personal identification information (name, email, phone number, address)',
            financial: 'Financial information (bank details, income, expenses, tax information)',
            business: 'Business information (company details, employee information)',
            technical: 'Technical information (IP address, browser type, device information)',
            communication: 'Communication records and correspondence'
          },
          usage: {
            title: 'How We Use Your Information',
            intro: 'We use your information for the following purposes:',
            services: 'To provide and improve our accounting and financial services',
            compliance: 'To comply with legal and regulatory requirements',
            communication: 'To communicate with you about your account and services',
            improvement: 'To improve our website and services',
            legal: 'To protect our legal rights and interests'
          },
          protection: {
            title: 'How We Protect Your Information',
            intro: 'We implement various security measures to maintain the safety of your information:',
            technical: 'Technical Safeguards',
            technicalDesc: 'Encryption, secure servers, firewalls, and regular security assessments',
            administrative: 'Administrative Controls',
            administrativeDesc: 'Staff training, access limitations, and confidentiality agreements'
          },
          thirdParty: {
            title: 'Third-Party Sharing',
            intro: 'We may share your information with trusted third parties:',
            services: 'Payment processors for processing transactions',
            paypal: 'For secure payment processing',
            stripe: 'For secure payment processing',
            analytics: 'For website analytics and improvement',
            storage: 'For secure cloud storage of documents'
          },
          rights: {
            title: 'Your Rights',
            intro: 'Under Canadian privacy laws, you have the right to:',
            access: 'Access your personal information',
            correction: 'Request corrections to inaccurate information',
            deletion: 'Request deletion of your information where applicable',
            portability: 'Request a copy of your information in a structured format',
            withdrawal: 'Withdraw consent for future use',
            complaint: 'File a complaint with the Privacy Commissioner of Canada'
          },
          contact: {
            title: 'Contact Us',
            intro: 'If you have questions about our privacy practices, please contact us at:'
          },
          lastUpdated: 'Last Updated',
          pipedaCompliance: 'This privacy policy complies with the Personal Information Protection and Electronic Documents Act (PIPEDA) and applicable provincial privacy laws.'
        },
        terms: {
          title: 'Terms & Conditions',
          subtitle: 'The terms governing your use of our services',
          acceptance: {
            title: 'Acceptance of Terms',
            content: 'By accessing or using Madadi TFAS INC services, you agree to be bound by these Terms and Conditions and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using our services.'
          },
          services: {
            title: 'Services',
            intro: 'Madadi TFAS INC provides accounting, tax, and financial services including but not limited to:',
            accounting: 'Accounting Services',
            bookkeeping: 'Bookkeeping and financial record-keeping',
            statements: 'Preparation of financial statements',
            reconciliation: 'Bank reconciliation',
            tax: 'Tax Services',
            preparation: 'Tax return preparation',
            filing: 'Tax filing with CRA',
            planning: 'Tax planning and optimization'
          },
          liability: {
            title: 'Limitation of Liability',
            disclaimer: 'Important disclaimers regarding our services:',
            professional: 'We provide professional services but cannot guarantee specific outcomes',
            decisions: 'Final business and financial decisions remain your responsibility',
            accuracy: 'We rely on the accuracy and completeness of information you provide',
            thirdParty: 'We are not responsible for third-party services or software'
          },
          responsibilities: {
            title: 'Client Responsibilities',
            intro: 'As a client, you are responsible for:',
            client: 'Your Responsibilities',
            accurate: 'Providing accurate and complete information',
            timely: 'Submitting documents and information in a timely manner',
            cooperation: 'Cooperating with reasonable requests for information',
            compliance: 'Complying with all applicable laws and regulations'
          },
          payment: {
            title: 'Payment Terms',
            terms: 'Payment Schedule',
            monthly: 'Monthly subscription fees are due on the 1st of each month',
            advance: 'One-time services require payment in advance',
            late: 'Late payments may incur additional fees',
            methods: 'Payment Methods',
            credit: 'Credit/Debit cards',
            bank: 'Electronic funds transfer',
            paypal: 'PayPal and other electronic payment methods'
          },
          refund: {
            title: 'Refund Policy',
            policy: 'Our refund policy is as follows:',
            services: 'Professional services are non-refundable once work has begun',
            software: 'Software purchases may be refunded within 14 days if unused',
            cancellation: 'Subscription cancellations are effective at the end of the current billing period'
          },
          jurisdiction: {
            title: 'Governing Law',
            governing: 'These Terms and Conditions are governed by:',
            alberta: 'The laws of the Province of Alberta',
            federal: 'Applicable federal laws of Canada',
            disputes: 'Any disputes shall be resolved in the courts of Alberta'
          },
          modifications: {
            title: 'Modifications to Terms',
            content: 'Madadi TFAS INC reserves the right to modify these terms at any time. Changes will be effective immediately upon posting to our website. Your continued use of our services constitutes acceptance of the modified terms.'
          },
          lastUpdated: 'Last Updated',
          contact: 'For questions regarding these terms, please contact'
        },
        cookies: {
          title: 'Cookie Policy',
          subtitle: 'How we use cookies and similar technologies',
          what: {
            title: 'What Are Cookies',
            content: 'Cookies are small text files that are placed on your device when you visit our website. They help us provide you with a better experience by enabling certain features, remembering your preferences, and helping us understand how visitors interact with our site.'
          },
          types: {
            title: 'Types of Cookies We Use'
          },
          essential: {
            title: 'Essential Cookies',
            required: 'Required for the website to function',
            description: 'These cookies are necessary for the website to function properly. They enable core functionality such as security, network management, and account access.',
            session: 'Session management cookies',
            security: 'Security cookies to prevent fraud',
            preferences: 'Basic preference settings'
          },
          analytics: {
            title: 'Analytics Cookies',
            optional: 'Optional but helpful',
            description: 'These cookies allow us to count visits and traffic sources so we can measure and improve the performance of our site.',
            usage: 'Website usage statistics',
            performance: 'Performance monitoring',
            google: 'Google Analytics cookies'
          },
          preferences: {
            title: 'Preference Cookies',
            optional: 'Optional for better experience',
            description: 'These cookies enable the website to remember choices you make and provide enhanced, personalized features.',
            language: 'Language preferences',
            theme: 'Visual theme settings',
            dashboard: 'Dashboard layout preferences'
          },
          marketing: {
            title: 'Marketing Cookies',
            optional: 'Completely optional',
            description: 'These cookies are used to track visitors across websites to display relevant advertisements and content based on your interests.',
            advertising: 'Targeted advertising',
            social: 'Social media integration',
            tracking: 'Cross-site tracking'
          },
          thirdParty: {
            title: 'Third-Party Cookies',
            description: 'Some cookies are placed by third-party services that appear on our pages:',
            services: 'Third-Party Services',
            purposes: 'Used For',
            analytics: 'Website analytics',
            payments: 'Secure payment processing',
            support: 'Customer support chat',
            security: 'Security and fraud prevention'
          },
          manage: {
            title: 'Managing Cookies',
            description: 'You can control and manage cookies in various ways. You can modify your browser settings to reject or delete cookies, or you can use the controls below to manage your preferences for our website.'
          },
          save: 'Save Preferences',
          reject: 'Reject Optional Cookies',
          always: 'Always Active',
          saved: 'Your cookie preferences have been saved!',
          lastUpdated: 'Last Updated',
          contact: 'For questions about cookies, please contact'
        },
        licensing: {
          title: 'Legal & Licensing Information',
          subtitle: 'Our professional credentials and legal compliance',
          overview: {
            title: 'Overview',
            content: 'Madadi TFAS INC is a fully licensed and registered accounting and financial services firm operating in Calgary, Alberta. We maintain all necessary business licenses, professional certifications, and regulatory compliance required to provide accounting, tax, and financial services in Canada.'
          },
          business: {
            title: 'Business Registration',
            federal: 'Federal Business Number',
            alberta: 'Alberta Business License',
            number: 'Business Number',
            license: 'License Number',
            status: 'Status',
            active: 'Active',
            registered: 'Registered Date',
            expires: 'Expiration Date'
          },
          tax: {
            title: 'Tax Practitioner Information',
            cra: 'CRA Registration',
            gst: 'GST/HST Number',
            payroll: 'Payroll Number',
            status: 'Compliance Status',
            compliant: 'Fully Compliant',
            lastFiled: 'Last Filing Date'
          },
          professional: {
            title: 'Professional Certifications',
            certifications: 'Individual Certifications',
            cpa: 'Chartered Professional Accountant (CPA)',
            cga: 'Certified General Accountant (CGA)',
            tax: 'Certified Tax Specialist',
            memberships: 'Professional Memberships',
            cpaa: 'CPA Alberta',
            chamber: 'Calgary Chamber of Commerce',
            ita: 'International Tax Association'
          },
          compliance: {
            title: 'Regulatory Compliance',
            standards: 'Compliance Standards',
            cra: 'CRA Tax Practitioner Guidelines',
            alberta: 'Alberta Business Standards',
            pipeda: 'PIPEDA Privacy Compliance',
            aml: 'Anti-Money Laundering Compliance',
            professional: 'Professional Ethics Standards',
            ethics: 'CPA Code of Professional Conduct'
          },
          contact: {
            title: 'Contact Information',
            business: 'Business Information',
            info: 'Contact Details'
          },
          lastUpdated: 'Last Updated',
          verification: 'All licensing information can be verified through the appropriate regulatory bodies.'
        },
        security: {
          title: 'Security Information',
          subtitle: 'How we protect your data and financial information',
          commitment: {
            title: 'Our Security Commitment',
            content: 'At Madadi TFAS INC, we implement industry-leading security measures to protect your sensitive financial and personal information. We adhere to the highest standards of data protection and security best practices.'
          },
          encryption: {
            title: 'Encryption & Data Protection',
            ssl: 'Website Security',
            tls: 'TLS 1.3 encryption for all web traffic',
            certificate: 'Extended Validation (EV) SSL certificate',
            transit: 'All data encrypted in transit',
            data: 'Data Encryption',
            aes: 'AES-256 encryption for stored data',
            rest: 'All sensitive information encrypted at rest',
            backup: 'Encrypted backup systems'
          },
          payments: {
            title: 'Payment Security',
            processors: 'Payment Processors',
            pci: 'PCI DSS Level 1 compliant',
            tokenization: 'Card tokenization (no card data stored)',
            fraud: 'Advanced fraud detection',
            secure: 'Secure payment processing',
            buyer: 'Buyer protection policies',
            encryption: 'End-to-end encryption',
            disclaimer: 'Payment Disclaimer',
            disclaimerText: 'While we use industry-standard security measures, no method of electronic transmission or storage is 100% secure. We continuously update our security practices to maintain the highest level of protection.'
          },
          infrastructure: {
            title: 'Infrastructure Security',
            hosting: 'Hosting Security',
            cloud: 'Enterprise-grade cloud infrastructure',
            redundancy: 'Redundant systems and backups',
            monitoring: '24/7 security monitoring',
            access: 'Access Controls',
            mfa: 'Multi-factor authentication',
            rbac: 'Role-based access control',
            audit: 'Comprehensive audit logging',
            backup: 'Data Backup',
            automated: 'Automated daily backups',
            geographic: 'Geographically distributed storage',
            recovery: 'Disaster recovery planning'
          },
          confidentiality: {
            title: 'Confidentiality',
            professional: 'Professional Confidentiality',
            description: 'As accounting professionals, we maintain strict confidentiality of all client information in accordance with CPA ethical standards and legal requirements.',
            privilege: 'Accountant-client privilege protection',
            disclosure: 'No disclosure without explicit consent or legal requirement',
            retention: 'Secure data retention policies',
            disposal: 'Secure data disposal procedures'
          },
          compliance: {
            title: 'Security Compliance',
            standards: 'Security Standards',
            pipeda: 'PIPEDA compliant',
            sox: 'SOX compliance for applicable services',
            iso: 'ISO 27001 security framework',
            audits: 'Security Audits',
            annual: 'Annual security assessments',
            penetration: 'Regular penetration testing',
            vulnerability: 'Continuous vulnerability scanning'
          },
          incident: {
            title: 'Incident Response',
            response: 'Incident Response Plan',
            description: 'We maintain a comprehensive incident response plan to address any potential security incidents promptly and effectively.',
            immediate: 'Immediate Response',
            containment: 'Rapid containment procedures',
            assessment: 'Damage assessment protocols',
            notification: 'Client notification process',
            followup: 'Follow-up Actions',
            investigation: 'Thorough investigation',
            remediation: 'System remediation',
            prevention: 'Future prevention measures'
          },
          lastUpdated: 'Last Updated',
          contact: 'For security-related inquiries, please contact'
        }
      },
      
      // Footer Translations
      footer: {
        rights: 'Todos los derechos reservados',
        services: 'Servicios',
        contact: 'Contacto',
        legal: 'Legal'
      }
    },
    
    // French Translations
    fr: {
      // Header Translations
      header: {
        home: 'Accueil',
        services: 'Services',
        software: 'Logiciels',
        pricing: 'Tarifs',
        contact: 'Contact',
        login: 'Connexion',
        logout: 'Déconnexion',
        dashboard: 'Tableau de Bord',
        admin: 'Panneau d\'Administration',
        employee: 'Panneau des Employés'
      },
      
      // Hero Section Translations
      hero: {
        title: 'Précision dans les Chiffres',
        subtitle: 'Vision en Finance',
        description: 'Services professionnels de comptabilité et de finance adaptés aux entreprises de Calgary. Nous gérons vos chiffres pour que vous puissiez vous concentrer sur la croissance.',
        viewPlans: 'Voir les Forfaits',
        consultation: 'Consultation Gratuite'
      },
      
      // Services Section Translations
      services: {
        title: 'Nos',
        titleHighlight: 'Services',
        description: 'Solutions financières et comptables complètes conçues pour soutenir votre entreprise à chaque étape',
        learnMore: 'En Savoir Plus'
      },
      
      // Service Item Translations
      service: {
        software: {
          title: 'Solutions Logicielles Comptables',
          description: 'Nous fournissons la sélection, la configuration et la formation pour le logiciel comptable adapté aux besoins de votre entreprise.'
        },
        bookkeeping: {
          title: 'Services de Comptabilité',
          description: 'Nous maintenons des registres financiers précis, préparons des états financiers et veillons à ce que vos livres soient toujours en ordre.'
        }
      },
      
      // AI Assistant Translations
      ai: {
        title: 'Assistant Comptable',
        subtitle: 'Posez-moi n\'importe quelle question sur les lois fiscales de Calgary, les réglementations de l\'ARC ou les meilleures pratiques comptables',
        placeholder: 'Tapez votre question ici...',
        examples: {
          title: 'Essayez de demander:',
        },
        example1: 'Quelles sont les dates limites de déclaration de TPS?',
        example2: 'Comment enregistrer une société en Alberta?',
        example3: 'Quelles dépenses d\'entreprise puis-je déduire?',
        example4: 'Quand les versements de paie sont-ils dus?'
      },
      
      // Legal and Compliance Translations - French
      legal: {
        privacy: {
          title: 'Politique de Confidentialité',
          subtitle: 'Comment nous protégeons et gérons vos informations',
          overview: {
            title: 'Aperçu',
            content: 'Chez Madadi TFAS INC, nous prenons votre vie privée au sérieux. Cette politique décrit comment nous collectons, utilisons et protégeons vos informations personnelles et financières conformément à la LPRPDE et aux autres lois canadiennes sur la protection de la vie privée applicables.'
          },
          collection: {
            title: 'Informations que Nous Collectons',
            intro: 'Nous collectons différents types d\'informations pour fournir nos services comptables et financiers:',
            personal: 'Informations d\'identification personnelle (nom, email, numéro de téléphone, adresse)',
            financial: 'Informations financières (coordonnées bancaires, revenus, dépenses, informations fiscales)',
            business: 'Informations commerciales (détails de l\'entreprise, informations sur les employés)',
            technical: 'Informations techniques (adresse IP, type de navigateur, informations sur l\'appareil)',
            communication: 'Enregistrements de communication et correspondance'
          },
          usage: {
            title: 'Comment Nous Utilisons Vos Informations',
            intro: 'Nous utilisons vos informations aux fins suivantes:',
            services: 'Pour fournir et améliorer nos services comptables et financiers',
            compliance: 'Pour se conformer aux exigences légales et réglementaires',
            communication: 'Pour communiquer avec vous concernant votre compte et vos services',
            improvement: 'Pour améliorer notre site web et nos services',
            legal: 'Pour protéger nos droits et intérêts légaux'
          },
          protection: {
            title: 'Comment Nous Protégeons Vos Informations',
            intro: 'Nous mettons en œuvre diverses mesures de sécurité pour maintenir la sécurité de vos informations:',
            technical: 'Protections Techniques',
            technicalDesc: 'Cryptage, serveurs sécurisés, pare-feu et évaluations de sécurité régulières',
            administrative: 'Contrôles Administratifs',
            administrativeDesc: 'Formation du personnel, limitations d\'accès et accords de confidentialité'
          },
          thirdParty: {
            title: 'Partage avec des Tiers',
            intro: 'Nous pouvons partager vos informations avec des tiers de confiance:',
            services: 'Processeurs de paiement pour le traitement des transactions',
            paypal: 'Pour un traitement sécurisé des paiements',
            stripe: 'Pour un traitement sécurisé des paiements',
            analytics: 'Pour l\'analyse et l\'amélioration du site web',
            storage: 'Pour le stockage sécurisé de documents dans le cloud'
          },
          rights: {
            title: 'Vos Droits',
            intro: 'En vertu des lois canadiennes sur la protection de la vie privée, vous avez le droit de:',
            access: 'Accéder à vos informations personnelles',
            correction: 'Demander des corrections aux informations inexactes',
            deletion: 'Demander la suppression de vos informations lorsque applicable',
            portability: 'Demander une copie de vos informations dans un format structuré',
            withdrawal: 'Retirer le consentement pour une utilisation future',
            complaint: 'Déposer une plainte auprès du Commissaire à la protection de la vie privée du Canada'
          },
          contact: {
            title: 'Contactez-Nous',
            intro: 'Si vous avez des questions sur nos pratiques de confidentialité, veuillez nous contacter à:'
          },
          lastUpdated: 'Dernière Mise à Jour',
          pipedaCompliance: 'Cette politique de confidentialité est conforme à la Loi sur la protection des renseignements personnels et les documents électroniques (LPRPDE) et aux lois provinciales applicables sur la protection de la vie privée.'
        },
        terms: {
          title: 'Conditions Générales',
          subtitle: 'Les conditions régissant votre utilisation de nos services',
          acceptance: {
            title: 'Acceptation des Conditions',
            content: 'En accédant ou en utilisant les services de Madadi TFAS INC, vous acceptez d\'être lié par ces Conditions Générales et toutes les lois et réglementations applicables. Si vous n\'êtes pas d\'accord avec l\'une de ces conditions, il vous est interdit d\'utiliser nos services.'
          },
          services: {
            title: 'Services',
            intro: 'Madadi TFAS INC fournit des services comptables, fiscaux et financiers comprenant, sans s\'y limiter:',
            accounting: 'Services Comptables',
            bookkeeping: 'Tenue de livres et enregistrements financiers',
            statements: 'Préparation d\'états financiers',
            reconciliation: 'Rapprochement bancaire',
            tax: 'Services Fiscaux',
            preparation: 'Préparation de déclarations fiscales',
            filing: 'Dépôt fiscal auprès de l\'ARC',
            planning: 'Planification et optimisation fiscale'
          },
          liability: {
            title: 'Limitation de Responsabilité',
            disclaimer: 'Avis de non-responsabilité importants concernant nos services:',
            professional: 'Nous fournissons des services professionnels mais ne pouvons garantir des résultats spécifiques',
            decisions: 'Les décisions commerciales et financières finales restent votre responsabilité',
            accuracy: 'Nous comptons sur l\'exactitude et l\'exhaustivité des informations que vous fournissez',
            thirdParty: 'Nous ne sommes pas responsables des services ou logiciels tiers'
          },
          responsibilities: {
            title: 'Responsabilités du Client',
            intro: 'En tant que client, vous êtes responsable de:',
            client: 'Vos Responsabilités',
            accurate: 'Fournir des informations précises et complètes',
            timely: 'Soumettre des documents et des informations en temps opportun',
            cooperation: 'Coopérer avec les demandes raisonnables d\'informations',
            compliance: 'Se conformer à toutes les lois et réglementations applicables'
          },
          payment: {
            title: 'Conditions de Paiement',
            terms: 'Calendrier de Paiement',
            monthly: 'Les frais d\'abonnement mensuels sont dus le 1er de chaque mois',
            advance: 'Les services ponctuels nécessitent un paiement à l\'avance',
            late: 'Les paiements tardifs peuvent entraîner des frais supplémentaires',
            methods: 'Méthodes de Paiement',
            credit: 'Cartes de crédit/débit',
            bank: 'Transfert électronique de fonds',
            paypal: 'PayPal et autres méthodes de paiement électronique'
          },
          refund: {
            title: 'Politique de Remboursement',
            policy: 'Notre politique de remboursement est la suivante:',
            services: 'Les services professionnels ne sont pas remboursables une fois le travail commencé',
            software: 'Les achats de logiciels peuvent être remboursés dans les 14 jours s\'ils ne sont pas utilisés',
            cancellation: 'Les annulations d\'abonnement prennent effet à la fin de la période de facturation en cours'
          },
          jurisdiction: {
            title: 'Loi Applicable',
            governing: 'Ces Conditions Générales sont régies par:',
            alberta: 'Les lois de la province de l\'Alberta',
            federal: 'Les lois fédérales applicables du Canada',
            disputes: 'Tout litige sera résolu devant les tribunaux de l\'Alberta'
          },
          modifications: {
            title: 'Modifications des Conditions',
            content: 'Madadi TFAS INC se réserve le droit de modifier ces conditions à tout moment. Les modifications prendront effet immédiatement après leur publication sur notre site web. Votre utilisation continue de nos services constitue une acceptation des conditions modifiées.'
          },
          lastUpdated: 'Dernière Mise à Jour',
          contact: 'Pour toute question concernant ces conditions, veuillez contacter'
        },
        cookies: {
          title: 'Politique de Cookies',
          subtitle: 'Comment nous utilisons les cookies et technologies similaires',
          what: {
            title: 'Que Sont les Cookies',
            content: 'Les cookies sont de petits fichiers texte placés sur votre appareil lorsque vous visitez notre site web. Ils nous aident à vous offrir une meilleure expérience en activant certaines fonctionnalités, en mémorisant vos préférences et en nous aidant à comprendre comment les visiteurs interagissent avec notre site.'
          },
          types: {
            title: 'Types de Cookies que Nous Utilisons'
          },
          essential: {
            title: 'Cookies Essentiels',
            required: 'Nécessaires au fonctionnement du site',
            description: 'Ces cookies sont nécessaires au bon fonctionnement du site web. Ils permettent des fonctionnalités de base telles que la sécurité, la gestion du réseau et l\'accès au compte.',
            session: 'Cookies de gestion de session',
            security: 'Cookies de sécurité pour prévenir la fraude',
            preferences: 'Paramètres de préférences de base'
          },
          analytics: {
            title: 'Cookies Analytiques',
            optional: 'Optionnels mais utiles',
            description: 'Ces cookies nous permettent de compter les visites et les sources de trafic afin de mesurer et d\'améliorer les performances de notre site.',
            usage: 'Statistiques d\'utilisation du site web',
            performance: 'Surveillance des performances',
            google: 'Cookies Google Analytics'
          },
          preferences: {
            title: 'Cookies de Préférences',
            optional: 'Optionnels pour une meilleure expérience',
            description: 'Ces cookies permettent au site web de mémoriser les choix que vous faites et de fournir des fonctionnalités améliorées et personnalisées.',
            language: 'Préférences de langue',
            theme: 'Paramètres de thème visuel',
            dashboard: 'Préférences de mise en page du tableau de bord'
          },
          marketing: {
            title: 'Cookies Marketing',
            optional: 'Complètement optionnels',
            description: 'Ces cookies sont utilisés pour suivre les visiteurs sur les sites web afin d\'afficher des publicités et du contenu pertinents en fonction de vos intérêts.',
            advertising: 'Publicité ciblée',
            social: 'Intégration des médias sociaux',
            tracking: 'Suivi inter-sites'
          },
          thirdParty: {
            title: 'Cookies Tiers',
            description: 'Certains cookies sont placés par des services tiers qui apparaissent sur nos pages:',
            services: 'Services Tiers',
            purposes: 'Utilisés Pour',
            analytics: 'Analyse de site web',
            payments: 'Traitement sécurisé des paiements',
            support: 'Chat de support client',
            security: 'Sécurité et prévention des fraudes'
          },
          manage: {
            title: 'Gestion des Cookies',
            description: 'Vous pouvez contrôler et gérer les cookies de différentes manières. Vous pouvez modifier les paramètres de votre navigateur pour rejeter ou supprimer les cookies, ou vous pouvez utiliser les contrôles ci-dessous pour gérer vos préférences pour notre site web.'
          },
          save: 'Enregistrer les Préférences',
          reject: 'Rejeter les Cookies Optionnels',
          always: 'Toujours Actif',
          saved: 'Vos préférences de cookies ont été enregistrées!',
          lastUpdated: 'Dernière Mise à Jour',
          contact: 'Pour toute question concernant les cookies, veuillez contacter'
        },
        licensing: {
          title: 'Informations Légales et Licences',
          subtitle: 'Nos qualifications professionnelles et conformité légale',
          overview: {
            title: 'Aperçu',
            content: 'Madadi TFAS INC est un cabinet de services comptables et financiers entièrement agréé et enregistré opérant à Calgary, Alberta. Nous maintenons toutes les licences commerciales nécessaires, les certifications professionnelles et la conformité réglementaire requises pour fournir des services comptables, fiscaux et financiers au Canada.'
          },
          business: {
            title: 'Enregistrement d\'Entreprise',
            federal: 'Numéro d\'Entreprise Fédéral',
            alberta: 'Licence d\'Entreprise de l\'Alberta',
            number: 'Numéro d\'Entreprise',
            license: 'Numéro de Licence',
            status: 'Statut',
            active: 'Actif',
            registered: 'Date d\'Enregistrement',
            expires: 'Date d\'Expiration'
          },
          tax: {
            title: 'Informations de Praticien Fiscal',
            cra: 'Enregistrement ARC',
            gst: 'Numéro de TPS/TVH',
            payroll: 'Numéro de Paie',
            status: 'Statut de Conformité',
            compliant: 'Entièrement Conforme',
            lastFiled: 'Dernière Date de Dépôt'
          },
          professional: {
            title: 'Certifications Professionnelles',
            certifications: 'Certifications Individuelles',
            cpa: 'Comptable Professionnel Agréé (CPA)',
            cga: 'Comptable Général Accrédité (CGA)',
            tax: 'Spécialiste Fiscal Certifié',
            memberships: 'Adhésions Professionnelles',
            cpaa: 'CPA Alberta',
            chamber: 'Chambre de Commerce de Calgary',
            ita: 'Association Fiscale Internationale'
          },
          compliance: {
            title: 'Conformité Réglementaire',
            standards: 'Normes de Conformité',
            cra: 'Directives pour les Praticiens Fiscaux de l\'ARC',
            alberta: 'Normes Commerciales de l\'Alberta',
            pipeda: 'Conformité à la LPRPDE en matière de confidentialité',
            aml: 'Conformité à la Lutte Contre le Blanchiment d\'Argent',
            professional: 'Normes d\'Éthique Professionnelle',
            ethics: 'Code de Conduite Professionnelle CPA'
          },
          contact: {
            title: 'Coordonnées',
            business: 'Informations d\'Entreprise',
            info: 'Coordonnées'
          },
          lastUpdated: 'Dernière Mise à Jour',
          verification: 'Toutes les informations de licence peuvent être vérifiées auprès des organismes de réglementation appropriés.'
        },
        security: {
          title: 'Informations de Sécurité',
          subtitle: 'Comment nous protégeons vos données et informations financières',
          commitment: {
            title: 'Notre Engagement en Matière de Sécurité',
            content: 'Chez Madadi TFAS INC, nous mettons en œuvre des mesures de sécurité de pointe pour protéger vos informations financières et personnelles sensibles. Nous adhérons aux normes les plus élevées de protection des données et aux meilleures pratiques de sécurité.'
          },
          encryption: {
            title: 'Cryptage et Protection des Données',
            ssl: 'Sécurité du Site Web',
            tls: 'Cryptage TLS 1.3 pour tout le trafic web',
            certificate: 'Certificat SSL à validation étendue (EV)',
            transit: 'Toutes les données cryptées en transit',
            data: 'Cryptage des Données',
            aes: 'Cryptage AES-256 pour les données stockées',
            rest: 'Toutes les informations sensibles cryptées au repos',
            backup: 'Systèmes de sauvegarde cryptés'
          },
          payments: {
            title: 'Sécurité des Paiements',
            processors: 'Processeurs de Paiement',
            pci: 'Conforme à PCI DSS Niveau 1',
            tokenization: 'Tokenisation des cartes (aucune donnée de carte stockée)',
            fraud: 'Détection avancée des fraudes',
            secure: 'Traitement sécurisé des paiements',
            buyer: 'Politiques de protection des acheteurs',
            encryption: 'Cryptage de bout en bout',
            disclaimer: 'Avis de Non-Responsabilité de Paiement',
            disclaimerText: 'Bien que nous utilisions des mesures de sécurité standard de l\'industrie, aucune méthode de transmission ou de stockage électronique n\'est sécurisée à 100%. Nous mettons continuellement à jour nos pratiques de sécurité pour maintenir le plus haut niveau de protection.'
          },
          infrastructure: {
            title: 'Sécurité de l\'Infrastructure',
            hosting: 'Sécurité de l\'Hébergement',
            cloud: 'Infrastructure cloud de niveau entreprise',
            redundancy: 'Systèmes redondants et sauvegardes',
            monitoring: 'Surveillance de sécurité 24/7',
            access: 'Contrôles d\'Accès',
            mfa: 'Authentification multi-facteurs',
            rbac: 'Contrôle d\'accès basé sur les rôles',
            audit: 'Journalisation d\'audit complète',
            backup: 'Sauvegarde des Données',
            automated: 'Sauvegardes automatiques quotidiennes',
            geographic: 'Stockage géographiquement distribué',
            recovery: 'Planification de récupération après sinistre'
          },
          confidentiality: {
            title: 'Confidentialité',
            professional: 'Confidentialité Professionnelle',
            description: 'En tant que professionnels de la comptabilité, nous maintenons une stricte confidentialité de toutes les informations des clients conformément aux normes éthiques CPA et aux exigences légales.',
            privilege: 'Protection du privilège comptable-client',
            disclosure: 'Pas de divulgation sans consentement explicite ou exigence légale',
            retention: 'Politiques de conservation des données sécurisées',
            disposal: 'Procédures d\'élimination sécurisée des données'
          },
          compliance: {
            title: 'Conformité de Sécurité',
            standards: 'Normes de Sécurité',
            pipeda: 'Conforme à la LPRPDE',
            sox: 'Conformité SOX pour les services applicables',
            iso: 'Cadre de sécurité ISO 27001',
            audits: 'Audits de Sécurité',
            annual: 'Évaluations de sécurité annuelles',
            penetration: 'Tests de pénétration réguliers',
            vulnerability: 'Analyse continue des vulnérabilités'
          },
          incident: {
            title: 'Réponse aux Incidents',
            response: 'Plan de Réponse aux Incidents',
            description: 'Nous maintenons un plan complet de réponse aux incidents pour traiter rapidement et efficacement tout incident de sécurité potentiel.',
            immediate: 'Réponse Immédiate',
            containment: 'Procédures de confinement rapide',
            assessment: 'Protocoles d\'évaluation des dommages',
            notification: 'Processus de notification des clients',
            followup: 'Actions de Suivi',
            investigation: 'Enquête approfondie',
            remediation: 'Remédiation du système',
            prevention: 'Mesures de prévention futures'
          },
          lastUpdated: 'Dernière Mise à Jour',
          contact: 'Pour les demandes liées à la sécurité, veuillez contacter'
        }
      },
      
      // Footer Translations
      footer: {
        rights: 'Tous droits réservés',
        services: 'Services',
        contact: 'Contact',
        legal: 'Légal'
      }
    }
  };

  // Function to get nested translations
  const t = (key: string): string => {
    const keys = key.split('.');
    let result: any = translations[language];
    
    for (const k of keys) {
      if (result && result[k] !== undefined) {
        result = result[k];
      } else {
        // Fallback to English if translation not found
        let fallback = translations['en'];
        for (const fk of keys) {
          if (fallback && fallback[fk] !== undefined) {
            fallback = fallback[fk];
          } else {
            return key; // Return the key if no translation found
          }
        }
        return typeof fallback === 'string' ? fallback : key;
      }
    }
    
    return typeof result === 'string' ? result : key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};