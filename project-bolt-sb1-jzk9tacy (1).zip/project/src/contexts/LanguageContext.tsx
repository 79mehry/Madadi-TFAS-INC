import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'fa' | 'es' | 'fr';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // Header
    'header.home': 'Home',
    'header.services': 'Services',
    'header.software': 'Software',
    'header.pricing': 'Pricing',
    'header.contact': 'Contact',
    'header.login': 'Client Login',
    'header.logout': 'Logout',
    'header.dashboard': 'Dashboard',
    'header.admin': 'Admin Panel',
    'header.employee': 'Employee Panel',
    
    // Hero Section
    'hero.title': 'Precision in Numbers,',
    'hero.subtitle': 'Vision in Finance',
    'hero.description': 'Madadi Financial and Accounting Services INC - Professional accounting solutions for Calgary businesses',
    'hero.viewPlans': 'View Pricing Plans',
    'hero.consultation': 'Free Consultation',
    'hero.offer.title': '🎉 Limited Time Offer!',
    'hero.offer.save': 'Save up to',
    'hero.offer.free': 'FREE',
    'hero.offer.setup': 'software setup worth $300',
    'hero.offer.basic': 'Basic Plan',
    'hero.offer.professional': 'Professional Plan',
    'hero.offer.enterprise': 'Enterprise Plan',
    'hero.offer.valid': '*Offer valid until March 31, 2024. New clients only.',
    
    // Services
    'services.title': 'Our',
    'services.titleHighlight': 'Services',
    'services.description': 'Comprehensive financial and accounting solutions designed to support your business at every stage',
    'services.learnMore': 'Learn More',
    
    // Service Names
    'service.software.title': 'Accounting Software Sales',
    'service.software.description': 'We help you select the right accounting software for your business, install and configure it properly, and provide full training so you can use it efficiently. Ongoing technical support and updates are also included.',
    'service.bookkeeping.title': 'Accounting and Bookkeeping',
    'service.bookkeeping.description': 'We offer accurate financial record-keeping, financial statement preparation, bank reconciliation and organized financial tracking tailored for small and medium-sized businesses.',
    'service.consulting.title': 'Financial and Business Consulting',
    'service.consulting.description': 'We provide consulting for business growth and development, financial planning, budgeting, profit & loss analysis and support for smart and strategic financial decisions.',
    'service.tax.title': 'Tax Services',
    'service.tax.description': 'We handle personal and corporate tax filings, GST/HST reports, tax optimization strategies to minimize your tax burden while ensuring full compliance.',
    'service.registration.title': 'Company Registration and Basic Legal Services',
    'service.registration.description': 'We guide you through choosing the right business structure, prepare required documents and complete all initial legal steps for proper business registration.',
    'service.payroll.title': 'Payroll Services',
    'service.payroll.description': 'We calculate salaries & benefits, generate required payroll reports, submit to the relevant authorities, & ensure compliance with all employment & tax regulations.',
    'service.training.title': 'Accounting Training and Support',
    'service.training.description': 'Accounting principles & software explained clearly & practically, with ongoing support to enhance your skills & resolve challenges.',
    'service.immigrant.title': 'Immigrant Business Consulting',
    'service.immigrant.description': 'We help newcomers understand Canada\'s financial & tax systems, navigate the business registration process & offer practical advice for a confident business start.',
    'service.cashflow.title': 'Financial and Cash Flow Management',
    'service.cashflow.description': 'We provide detailed cash flow planning, expense & income analysis & custom budgeting to ensure financial control and stability for your business.',
    
    // Footer
    'footer.services': 'Services',
    'footer.contact': 'Contact Info',
    'footer.quickLinks': 'Quick Links',
    'footer.rights': 'All rights reserved.',
    'footer.licensed': 'Licensed in Alberta, Canada | Serving Calgary and surrounding areas',
    
    // AI Assistant
    'ai.title': 'AI Accounting Assistant',
    'ai.subtitle': 'Get instant answers about Calgary tax laws, CRA regulations, and accounting practices',
    'ai.placeholder': 'Ask about tax deadlines, CRA requirements, business registration...',
    'ai.send': 'Send',
    'ai.examples.title': 'Try asking:',
    'ai.example1': 'What are the GST/HST filing deadlines for 2024?',
    'ai.example2': 'How do I register a corporation in Alberta?',
    'ai.example3': 'What business expenses are tax deductible in Canada?',
    'ai.example4': 'What are the payroll remittance requirements?',
    
    // Common
    'common.loading': 'Loading...',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.edit': 'Edit',
    'common.delete': 'Delete',
    'common.add': 'Add',
    'common.search': 'Search',
    'common.filter': 'Filter',
    'common.export': 'Export',
    'common.back': 'Back to Website',
  },
  
  // Legal and Compliance Translations
  legal: {
    privacy: {
      title: 'Privacy Policy',
      subtitle: 'How we collect, use, and protect your personal information',
      overview: {
        title: 'Privacy Overview',
        content: 'Madadi TFAS INC is committed to protecting your privacy and personal information in accordance with the Personal Information Protection and Electronic Documents Act (PIPEDA) and other applicable Canadian privacy laws.'
      },
      collection: {
        title: 'Information We Collect',
        intro: 'We collect the following types of information to provide our accounting and tax services:',
        personal: 'Personal identification information (name, address, phone, email)',
        financial: 'Financial information (income, expenses, tax documents, bank statements)',
        business: 'Business information (company details, registration numbers, financial records)',
        technical: 'Technical information (IP address, browser type, usage analytics)',
        communication: 'Communication records (emails, phone calls, support tickets)'
      },
      usage: {
        title: 'How We Use Your Information',
        intro: 'We use your personal information for the following purposes:',
        services: 'Providing accounting, bookkeeping, and tax preparation services',
        compliance: 'Ensuring compliance with CRA and provincial tax regulations',
        communication: 'Communicating with you about our services and your account',
        improvement: 'Improving our services and developing new features',
        legal: 'Meeting legal and regulatory requirements'
      },
      protection: {
        title: 'How We Protect Your Information',
        intro: 'We implement comprehensive security measures to protect your personal information:',
        technical: 'Technical Safeguards',
        technicalDesc: 'SSL encryption, secure servers, access controls, and regular security audits',
        administrative: 'Administrative Safeguards',
        administrativeDesc: 'Staff training, confidentiality agreements, and strict access policies'
      },
      thirdParty: {
        title: 'Third-Party Services',
        intro: 'We work with trusted third-party service providers who may have access to your information:',
        services: 'Third-Party Services We Use:',
        stripe: 'Payment processing and secure transactions',
        paypal: 'Alternative payment processing',
        analytics: 'Website analytics and performance monitoring',
        storage: 'Secure document storage and backup services'
      },
      rights: {
        title: 'Your Privacy Rights',
        intro: 'Under PIPEDA, you have the following rights regarding your personal information:',
        access: 'Right to access your personal information',
        correction: 'Right to request correction of inaccurate information',
        deletion: 'Right to request deletion of your information',
        portability: 'Right to data portability',
        withdrawal: 'Right to withdraw consent',
        complaint: 'Right to file a complaint with the Privacy Commissioner'
      },
      contact: {
        title: 'Privacy Contact Information',
        intro: 'For any privacy-related questions or requests, please contact us:'
      },
      lastUpdated: 'Last Updated',
      pipedaCompliance: 'This privacy policy complies with the Personal Information Protection and Electronic Documents Act (PIPEDA) and applicable provincial privacy legislation.'
    },
    terms: {
      title: 'Terms and Conditions',
      subtitle: 'Legal terms governing the use of our services',
      acceptance: {
        title: 'Acceptance of Terms',
        content: 'By using our services, you agree to be bound by these terms and conditions. If you do not agree with any part of these terms, you may not use our services.'
      },
      services: {
        title: 'Services Offered',
        intro: 'Madadi TFAS INC provides the following professional services:',
        accounting: 'Accounting Services',
        bookkeeping: 'Bookkeeping and financial record maintenance',
        statements: 'Financial statement preparation',
        reconciliation: 'Bank reconciliation services',
        tax: 'Tax Services',
        preparation: 'Tax return preparation and filing',
        filing: 'GST/HST and payroll remittance filing',
        planning: 'Tax planning and optimization strategies'
      },
      liability: {
        title: 'Liability and Disclaimers',
        disclaimer: 'Important Disclaimers:',
        professional: 'Our services are provided for informational purposes and professional guidance',
        decisions: 'Final financial and tax decisions remain your responsibility',
        accuracy: 'While we strive for accuracy, we cannot guarantee error-free results',
        thirdParty: 'We are not liable for third-party service failures or data breaches'
      },
      responsibilities: {
        title: 'Client Responsibilities',
        intro: 'As our client, you are responsible for:',
        client: 'Your Responsibilities:',
        accurate: 'Providing accurate and complete financial information',
        timely: 'Submitting documents and information in a timely manner',
        cooperation: 'Cooperating with our requests for additional information',
        compliance: 'Ensuring compliance with all applicable laws and regulations'
      },
      payment: {
        title: 'Payment Terms',
        terms: 'Payment Terms:',
        monthly: 'Monthly subscription fees are due in advance',
        advance: 'Project-based services require 50% payment in advance',
        late: 'Late payment fees may apply after 30 days',
        methods: 'Accepted Payment Methods:',
        credit: 'Credit and debit cards (via Stripe)',
        bank: 'Bank transfers and wire payments',
        paypal: 'PayPal payments'
      },
      refund: {
        title: 'Refund and Cancellation Policy',
        policy: 'Our refund policy includes the following terms:',
        services: 'Services already provided are non-refundable',
        software: 'Software purchases are refundable within 30 days',
        cancellation: 'Subscription cancellations take effect at the end of the billing period'
      },
      jurisdiction: {
        title: 'Governing Law and Jurisdiction',
        governing: 'These terms are governed by:',
        alberta: 'The laws of the Province of Alberta, Canada',
        federal: 'Applicable federal laws of Canada',
        disputes: 'Disputes will be resolved in Alberta courts'
      },
      modifications: {
        title: 'Modifications to Terms',
        content: 'We reserve the right to modify these terms at any time. Changes will be posted on our website and take effect immediately upon posting.'
      },
      lastUpdated: 'Last Updated',
      contact: 'For questions about these terms, contact us at'
    },
    cookies: {
      title: 'Cookie Policy',
      subtitle: 'How we use cookies and similar technologies',
      what: {
        title: 'What Are Cookies?',
        content: 'Cookies are small text files stored on your device when you visit our website. They help us provide you with a better user experience and analyze how our website is used.'
      },
      types: {
        title: 'Types of Cookies We Use'
      },
      essential: {
        title: 'Essential Cookies',
        required: 'Always Required',
        description: 'These cookies are necessary for the website to function properly and cannot be disabled.',
        session: 'Session management and user authentication',
        security: 'Security features and fraud prevention',
        preferences: 'Basic user preferences and settings'
      },
      analytics: {
        title: 'Analytics Cookies',
        optional: 'Optional',
        description: 'These cookies help us understand how visitors interact with our website.',
        usage: 'Website usage statistics and performance metrics',
        performance: 'Page load times and error tracking',
        google: 'Google Analytics for traffic analysis'
      },
      preferences: {
        title: 'Preference Cookies',
        optional: 'Optional',
        description: 'These cookies remember your choices and provide enhanced features.',
        language: 'Language and region preferences',
        theme: 'Theme and display preferences',
        dashboard: 'Dashboard layout and customizations'
      },
      marketing: {
        title: 'Marketing Cookies',
        optional: 'Optional',
        description: 'These cookies are used to deliver relevant advertisements and track campaign effectiveness.',
        advertising: 'Targeted advertising and remarketing',
        social: 'Social media integration and sharing',
        tracking: 'Conversion tracking and attribution'
      },
      thirdParty: {
        title: 'Third-Party Cookies',
        description: 'We use third-party services that may set their own cookies:',
        services: 'Third-Party Services:',
        purposes: 'Purposes:',
        analytics: 'Website analytics and insights',
        payments: 'Secure payment processing',
        support: 'Customer support and live chat',
        security: 'Security and fraud prevention'
      },
      manage: {
        title: 'Manage Your Cookie Preferences',
        description: 'You can control which cookies you accept using the settings below:'
      },
      always: 'Always Active',
      save: 'Save Preferences',
      reject: 'Reject All',
      saved: 'Cookie preferences saved successfully!',
      lastUpdated: 'Last Updated',
      contact: 'For questions about our cookie policy, contact us at'
    },
    licensing: {
      title: 'Legal & Licensing Information',
      subtitle: 'Our professional credentials and regulatory compliance',
      overview: {
        title: 'Professional Overview',
        content: 'Madadi TFAS INC is a fully licensed and regulated accounting firm operating in compliance with all Canadian federal and Alberta provincial requirements.'
      },
      business: {
        title: 'Business Registration',
        federal: 'Federal Business Registration',
        alberta: 'Alberta Provincial License',
        number: 'Business Number',
        license: 'License Number',
        status: 'Status',
        active: 'Active',
        registered: 'Registered',
        expires: 'Expires'
      },
      tax: {
        title: 'Tax Registration',
        cra: 'Canada Revenue Agency (CRA) Registration',
        gst: 'GST/HST Number',
        payroll: 'Payroll Account',
        status: 'Compliance Status',
        compliant: 'Fully Compliant',
        lastFiled: 'Last Filed'
      },
      professional: {
        title: 'Professional Certifications',
        certifications: 'Professional Certifications:',
        cpa: 'Chartered Professional Accountant (CPA)',
        cga: 'Certified General Accountant (CGA)',
        tax: 'Professional Tax Preparer Certification',
        memberships: 'Professional Memberships:',
        cpaa: 'CPA Alberta',
        chamber: 'Calgary Chamber of Commerce',
        ita: 'Institute of Tax Advisors'
      },
      compliance: {
        title: 'Regulatory Compliance',
        standards: 'We adhere to the following standards and regulations:',
        cra: 'Canada Revenue Agency regulations and guidelines',
        alberta: 'Alberta provincial accounting and business regulations',
        pipeda: 'Personal Information Protection and Electronic Documents Act (PIPEDA)',
        aml: 'Anti-Money Laundering (AML) compliance',
        professional: 'Professional accounting standards and ethics',
        ethics: 'Code of Professional Conduct'
      },
      contact: {
        title: 'Contact Information',
        business: 'Business Information:',
        info: 'Contact Details:'
      },
      lastUpdated: 'Last Updated',
      verification: 'All licenses and certifications are current and can be verified with the respective regulatory bodies.'
    },
    security: {
      title: 'Security Disclaimer',
      subtitle: 'Our commitment to protecting your data and financial information',
      commitment: {
        title: 'Our Security Commitment',
        content: 'We employ industry-leading security measures to protect your sensitive financial and personal information. Your data security is our top priority.'
      },
      encryption: {
        title: 'Data Encryption',
        ssl: 'SSL/TLS Encryption',
        tls: 'TLS 1.3 encryption for all data transmission',
        certificate: 'Extended Validation (EV) SSL certificates',
        transit: 'End-to-end encryption for data in transit',
        data: 'Data at Rest Encryption',
        aes: 'AES-256 encryption for stored data',
        rest: 'Encrypted database storage',
        backup: 'Encrypted backup and disaster recovery'
      },
      payments: {
        title: 'Secure Payment Processing',
        processors: 'Trusted Payment Processors',
        pci: 'PCI DSS Level 1 compliance',
        tokenization: 'Credit card tokenization',
        fraud: 'Advanced fraud detection',
        secure: 'Secure payment gateway',
        buyer: 'Buyer protection programs',
        encryption: 'End-to-end payment encryption',
        disclaimer: 'Payment Security Disclaimer',
        disclaimerText: 'We do not store credit card information on our servers. All payment data is processed by certified third-party payment processors.'
      },
      infrastructure: {
        title: 'Infrastructure Security',
        hosting: 'Secure Hosting',
        cloud: 'Enterprise-grade cloud infrastructure',
        redundancy: 'Multiple data center redundancy',
        monitoring: '24/7 security monitoring',
        access: 'Access Controls',
        mfa: 'Multi-factor authentication (MFA)',
        rbac: 'Role-based access control (RBAC)',
        audit: 'Comprehensive audit logging',
        backup: 'Backup & Recovery',
        automated: 'Automated daily backups',
        geographic: 'Geographically distributed backups',
        recovery: 'Tested disaster recovery procedures'
      },
      confidentiality: {
        title: 'Professional Confidentiality',
        professional: 'Accountant-Client Privilege',
        description: 'As professional accountants, we maintain strict confidentiality of all client information in accordance with professional standards and legal requirements.',
        privilege: 'Accountant-client privilege protection',
        disclosure: 'No unauthorized disclosure of client information',
        retention: 'Secure document retention policies',
        disposal: 'Secure disposal of sensitive documents'
      },
      compliance: {
        title: 'Security Compliance',
        standards: 'Compliance Standards:',
        pipeda: 'PIPEDA compliance for privacy protection',
        sox: 'SOX compliance for financial controls',
        iso: 'ISO 27001 security management standards',
        audits: 'Regular Security Audits:',
        annual: 'Annual third-party security assessments',
        penetration: 'Regular penetration testing',
        vulnerability: 'Continuous vulnerability scanning'
      },
      incident: {
        title: 'Security Incident Response',
        response: 'Incident Response Plan',
        description: 'We maintain a comprehensive incident response plan to address any potential security issues:',
        immediate: 'Immediate Response:',
        containment: 'Immediate threat containment',
        assessment: 'Rapid impact assessment',
        notification: 'Client notification within 24 hours',
        followup: 'Follow-up Actions:',
        investigation: 'Thorough investigation and analysis',
        remediation: 'Complete remediation of vulnerabilities',
        prevention: 'Enhanced prevention measures'
      },
      lastUpdated: 'Last Updated',
      contact: 'For security concerns, contact us at'
    }
  },

  fa: {
    // Header - Persian
    'header.home': 'خانه',
    'header.services': 'خدمات',
    'header.software': 'نرم افزار',
    'header.pricing': 'قیمت گذاری',
    'header.contact': 'تماس',
    'header.login': 'ورود مشتری',
    'header.logout': 'خروج',
    'header.dashboard': 'داشبورد',
    'header.admin': 'پنل مدیریت',
    'header.employee': 'پنل کارمند',
    
    // Hero Section - Persian
    'hero.title': 'دقت در اعداد،',
    'hero.subtitle': 'چشم انداز در امور مالی',
    'hero.description': 'شرکت خدمات مالی و حسابداری مددی - راه حل های حسابداری حرفه ای برای کسب و کارهای کلگری',
    'hero.viewPlans': 'مشاهده طرح های قیمت گذاری',
    'hero.consultation': 'مشاوره رایگان',
    'hero.offer.title': '🎉 پیشنهاد محدود!',
    'hero.offer.save': 'تا',
    'hero.offer.free': 'رایگان',
    'hero.offer.setup': 'نصب نرم افزار به ارزش ۳۰۰ دلار',
    'hero.offer.basic': 'طرح پایه',
    'hero.offer.professional': 'طرح حرفه ای',
    'hero.offer.enterprise': 'طرح سازمانی',
    'hero.offer.valid': '*پیشنهاد تا ۳۱ مارس ۲۰۲۴ معتبر است. فقط مشتریان جدید.',
    
    // Services - Persian
    'services.title': 'خدمات',
    'services.titleHighlight': 'ما',
    'services.description': 'راه حل های جامع مالی و حسابداری طراحی شده برای حمایت از کسب و کار شما در هر مرحله',
    'services.learnMore': 'بیشتر بدانید',
    
    // Service Names - Persian
    'service.software.title': 'فروش نرم افزار حسابداری',
    'service.software.description': 'ما به شما کمک می کنیم نرم افزار حسابداری مناسب برای کسب و کار خود را انتخاب کنید، آن را به درستی نصب و پیکربندی کنید و آموزش کاملی ارائه دهیم تا بتوانید به طور موثر از آن استفاده کنید.',
    'service.bookkeeping.title': 'حسابداری و دفترداری',
    'service.bookkeeping.description': 'ما نگهداری دقیق سوابق مالی، تهیه صورت های مالی، تطبیق بانکی و ردیابی مالی سازمان یافته متناسب با کسب و کارهای کوچک و متوسط ارائه می دهیم.',
    'service.consulting.title': 'مشاوره مالی و تجاری',
    'service.consulting.description': 'ما مشاوره برای رشد و توسعه کسب و کار، برنامه ریزی مالی، بودجه بندی، تجزیه و تحلیل سود و زیان و پشتیبانی برای تصمیمات مالی هوشمند و استراتژیک ارائه می دهیم.',
    'service.tax.title': 'خدمات مالیاتی',
    'service.tax.description': 'ما اظهارنامه های مالیاتی شخصی و شرکتی، گزارش های GST/HST، استراتژی های بهینه سازی مالیاتی را برای به حداقل رساندن بار مالیاتی شما در عین اطمینان از انطباق کامل انجام می دهیم.',
    'service.registration.title': 'ثبت شرکت و خدمات حقوقی پایه',
    'service.registration.description': 'ما شما را در انتخاب ساختار تجاری مناسب راهنمایی می کنیم، اسناد مورد نیاز را تهیه می کنیم و تمام مراحل حقوقی اولیه را برای ثبت مناسب کسب و کار تکمیل می کنیم.',
    'service.payroll.title': 'خدمات حقوق و دستمزد',
    'service.payroll.description': 'ما حقوق و مزایا را محاسبه می کنیم، گزارش های حقوق و دستمزد مورد نیاز را تولید می کنیم، به مقامات مربوطه ارسال می کنیم و انطباق با تمام مقررات اشتغال و مالیاتی را تضمین می کنیم.',
    'service.training.title': 'آموزش و پشتیبانی حسابداری',
    'service.training.description': 'اصول حسابداری و نرم افزار به وضوح و عملی توضیح داده شده، با پشتیبانی مداوم برای تقویت مهارت های شما و حل چالش ها.',
    'service.immigrant.title': 'مشاوره کسب و کار مهاجران',
    'service.immigrant.description': 'ما به تازه واردان کمک می کنیم تا سیستم های مالی و مالیاتی کانادا را درک کنند، در فرآیند ثبت کسب و کار راهنمایی شوند و مشاوره عملی برای شروع اعتماد به نفس کسب و کار ارائه دهیم.',
    'service.cashflow.title': 'مدیریت مالی و جریان نقدی',
    'service.cashflow.description': 'ما برنامه ریزی دقیق جریان نقدی، تجزیه و تحلیل هزینه و درآمد و بودجه بندی سفارشی برای اطمینان از کنترل مالی و ثبات کسب و کار شما ارائه می دهیم.',
    
    // AI Assistant - Persian
    'ai.title': 'دستیار هوش مصنوعی حسابداری',
    'ai.subtitle': 'پاسخ های فوری درباره قوانین مالیاتی کلگری، مقررات CRA و شیوه های حسابداری دریافت کنید',
    'ai.placeholder': 'درباره مهلت های مالیاتی، الزامات CRA، ثبت کسب و کار بپرسید...',
    'ai.send': 'ارسال',
    'ai.examples.title': 'امتحان کنید:',
    'ai.example1': 'مهلت های ثبت GST/HST برای سال ۲۰۲۴ چیست؟',
    'ai.example2': 'چگونه یک شرکت در آلبرتا ثبت کنم؟',
    'ai.example3': 'چه هزینه های تجاری در کانادا قابل کسر مالیاتی هستند؟',
    'ai.example4': 'الزامات حواله حقوق و دستمزد چیست؟',
    
    // Common - Persian
    'common.loading': 'در حال بارگذاری...',
    'common.save': 'ذخیره',
    'common.cancel': 'لغو',
    'common.edit': 'ویرایش',
    'common.delete': 'حذف',
    'common.add': 'اضافه کردن',
    'common.search': 'جستجو',
    'common.filter': 'فیلتر',
    'common.export': 'صادرات',
    'common.back': 'بازگشت به وب سایت',
  },
  
  // Legal and Compliance Translations - Persian
  legal: {
    privacy: {
      title: 'سیاست حفظ حریم خصوصی',
      subtitle: 'نحوه جمع‌آوری، استفاده و حفاظت از اطلاعات شخصی شما',
      overview: {
        title: 'نمای کلی حریم خصوصی',
        content: 'شرکت مددی TFAS متعهد به حفاظت از حریم خصوصی و اطلاعات شخصی شما مطابق با قانون حفاظت از اطلاعات شخصی و اسناد الکترونیکی (PIPEDA) و سایر قوانین حریم خصوصی کانادا است.'
      },
      collection: {
        title: 'اطلاعاتی که جمع‌آوری می‌کنیم',
        intro: 'ما انواع اطلاعات زیر را برای ارائه خدمات حسابداری و مالیاتی جمع‌آوری می‌کنیم:',
        personal: 'اطلاعات شناسایی شخصی (نام، آدرس، تلفن، ایمیل)',
        financial: 'اطلاعات مالی (درآمد، هزینه‌ها، اسناد مالیاتی، صورت‌حساب بانکی)',
        business: 'اطلاعات تجاری (جزئیات شرکت، شماره‌های ثبت، سوابق مالی)',
        technical: 'اطلاعات فنی (آدرس IP، نوع مرورگر، تجزیه و تحلیل استفاده)',
        communication: 'سوابق ارتباطی (ایمیل‌ها، تماس‌های تلفنی، تیکت‌های پشتیبانی)'
      },
      usage: {
        title: 'نحوه استفاده از اطلاعات شما',
        intro: 'ما از اطلاعات شخصی شما برای اهداف زیر استفاده می‌کنیم:',
        services: 'ارائه خدمات حسابداری، دفترداری و تهیه مالیات',
        compliance: 'اطمینان از انطباق با مقررات مالیاتی CRA و استانی',
        communication: 'ارتباط با شما در مورد خدمات ما و حساب شما',
        improvement: 'بهبود خدمات ما و توسعه ویژگی‌های جدید',
        legal: 'رعایت الزامات قانونی و نظارتی'
      },
      protection: {
        title: 'نحوه حفاظت از اطلاعات شما',
        intro: 'ما اقدامات امنیتی جامعی برای حفاظت از اطلاعات شخصی شما اجرا می‌کنیم:',
        technical: 'محافظت‌های فنی',
        technicalDesc: 'رمزگذاری SSL، سرورهای امن، کنترل دسترسی و ممیزی‌های امنیتی منظم',
        administrative: 'محافظت‌های اداری',
        administrativeDesc: 'آموزش کارکنان، قراردادهای محرمانگی و سیاست‌های دسترسی سخت‌گیرانه'
      },
      thirdParty: {
        title: 'خدمات شخص ثالث',
        intro: 'ما با ارائه‌دهندگان خدمات شخص ثالث قابل اعتماد کار می‌کنیم که ممکن است به اطلاعات شما دسترسی داشته باشند:',
        services: 'خدمات شخص ثالث که استفاده می‌کنیم:',
        stripe: 'پردازش پرداخت و تراکنش‌های امن',
        paypal: 'پردازش پرداخت جایگزین',
        analytics: 'تجزیه و تحلیل وب‌سایت و نظارت بر عملکرد',
        storage: 'ذخیره‌سازی امن اسناد و خدمات پشتیبان‌گیری'
      },
      rights: {
        title: 'حقوق حریم خصوصی شما',
        intro: 'تحت PIPEDA، شما حقوق زیر را در مورد اطلاعات شخصی خود دارید:',
        access: 'حق دسترسی به اطلاعات شخصی خود',
        correction: 'حق درخواست تصحیح اطلاعات نادرست',
        deletion: 'حق درخواست حذف اطلاعات خود',
        portability: 'حق قابلیت حمل داده',
        withdrawal: 'حق لغو رضایت',
        complaint: 'حق ثبت شکایت نزد کمیسر حریم خصوصی'
      },
      contact: {
        title: 'اطلاعات تماس حریم خصوصی',
        intro: 'برای هرگونه سؤال یا درخواست مربوط به حریم خصوصی، لطفاً با ما تماس بگیرید:'
      },
      lastUpdated: 'آخرین به‌روزرسانی',
      pipedaCompliance: 'این سیاست حریم خصوصی با قانون حفاظت از اطلاعات شخصی و اسناد الکترونیکی (PIPEDA) و قوانین حریم خصوصی استانی قابل اجرا مطابقت دارد.'
    },
    terms: {
      title: 'شرایط و ضوابط',
      subtitle: 'شرایط قانونی حاکم بر استفاده از خدمات ما',
      acceptance: {
        title: 'پذیرش شرایط',
        content: 'با استفاده از خدمات ما، شما موافقت می‌کنید که تحت این شرایط و ضوابط متعهد باشید. اگر با هر بخشی از این شرایط موافق نیستید، نمی‌توانید از خدمات ما استفاده کنید.'
      },
      services: {
        title: 'خدمات ارائه شده',
        intro: 'شرکت مددی TFAS خدمات حرفه‌ای زیر را ارائه می‌دهد:',
        accounting: 'خدمات حسابداری',
        bookkeeping: 'دفترداری و نگهداری سوابق مالی',
        statements: 'تهیه صورت‌های مالی',
        reconciliation: 'خدمات تطبیق بانکی',
        tax: 'خدمات مالیاتی',
        preparation: 'تهیه و ثبت اظهارنامه مالیاتی',
        filing: 'ثبت GST/HST و حقوق و دستمزد',
        planning: 'استراتژی‌های برنامه‌ریزی و بهینه‌سازی مالیاتی'
      },
      liability: {
        title: 'مسئولیت و سلب مسئولیت',
        disclaimer: 'سلب مسئولیت‌های مهم:',
        professional: 'خدمات ما برای اهداف اطلاعاتی و راهنمایی حرفه‌ای ارائه می‌شود',
        decisions: 'تصمیمات نهایی مالی و مالیاتی مسئولیت شما است',
        accuracy: 'در حالی که ما برای دقت تلاش می‌کنیم، نمی‌توانیم نتایج بدون خطا را تضمین کنیم',
        thirdParty: 'ما مسئول شکست خدمات شخص ثالث یا نقض داده‌ها نیستیم'
      },
      responsibilities: {
        title: 'مسئولیت‌های مشتری',
        intro: 'به عنوان مشتری ما، شما مسئول موارد زیر هستید:',
        client: 'مسئولیت‌های شما:',
        accurate: 'ارائه اطلاعات مالی دقیق و کامل',
        timely: 'ارسال اسناد و اطلاعات به موقع',
        cooperation: 'همکاری با درخواست‌های ما برای اطلاعات اضافی',
        compliance: 'اطمینان از انطباق با تمام قوانین و مقررات قابل اجرا'
      },
      payment: {
        title: 'شرایط پرداخت',
        terms: 'شرایط پرداخت:',
        monthly: 'هزینه‌های اشتراک ماهانه از قبل قابل پرداخت است',
        advance: 'خدمات مبتنی بر پروژه نیاز به ۵۰٪ پرداخت از قبل دارند',
        late: 'هزینه‌های تأخیر در پرداخت ممکن است پس از ۳۰ روز اعمال شود',
        methods: 'روش‌های پرداخت پذیرفته شده:',
        credit: 'کارت‌های اعتباری و نقدی (از طریق Stripe)',
        bank: 'انتقال بانکی و پرداخت‌های سیمی',
        paypal: 'پرداخت‌های PayPal'
      },
      refund: {
        title: 'سیاست بازپرداخت و لغو',
        policy: 'سیاست بازپرداخت ما شامل شرایط زیر است:',
        services: 'خدمات ارائه شده قابل بازپرداخت نیستند',
        software: 'خریدهای نرم‌افزار ظرف ۳۰ روز قابل بازپرداخت هستند',
        cancellation: 'لغو اشتراک در پایان دوره صورت‌حساب اعمال می‌شود'
      },
      jurisdiction: {
        title: 'قانون حاکم و صلاحیت قضایی',
        governing: 'این شرایط تحت حاکمیت موارد زیر است:',
        alberta: 'قوانین استان آلبرتا، کانادا',
        federal: 'قوانین فدرال قابل اجرا کانادا',
        disputes: 'اختلافات در دادگاه‌های آلبرتا حل خواهد شد'
      },
      modifications: {
        title: 'تغییرات در شرایط',
        content: 'ما حق تغییر این شرایط را در هر زمان محفوظ می‌داریم. تغییرات در وب‌سایت ما منتشر خواهد شد و بلافاصله پس از انتشار اعمال می‌شود.'
      },
      lastUpdated: 'آخرین به‌روزرسانی',
      contact: 'برای سؤالات در مورد این شرایط، با ما تماس بگیرید'
    },
    cookies: {
      title: 'سیاست کوکی',
      subtitle: 'نحوه استفاده از کوکی‌ها و فناوری‌های مشابه',
      what: {
        title: 'کوکی‌ها چیستند؟',
        content: 'کوکی‌ها فایل‌های متنی کوچکی هستند که هنگام بازدید از وب‌سایت ما روی دستگاه شما ذخیره می‌شوند. آنها به ما کمک می‌کنند تا تجربه کاربری بهتری ارائه دهیم و تجزیه و تحلیل کنیم که چگونه از وب‌سایت ما استفاده می‌شود.'
      },
      types: {
        title: 'انواع کوکی‌هایی که استفاده می‌کنیم'
      },
      essential: {
        title: 'کوکی‌های ضروری',
        required: 'همیشه مورد نیاز',
        description: 'این کوکی‌ها برای عملکرد صحیح وب‌سایت ضروری هستند و نمی‌توان آنها را غیرفعال کرد.',
        session: 'مدیریت جلسه و احراز هویت کاربر',
        security: 'ویژگی‌های امنیتی و جلوگیری از تقلب',
        preferences: 'تنظیمات و ترجیحات پایه کاربر'
      },
      analytics: {
        title: 'کوکی‌های تجزیه و تحلیل',
        optional: 'اختیاری',
        description: 'این کوکی‌ها به ما کمک می‌کنند تا بفهمیم بازدیدکنندگان چگونه با وب‌سایت ما تعامل می‌کنند.',
        usage: 'آمار استفاده از وب‌سایت و معیارهای عملکرد',
        performance: 'زمان بارگذاری صفحه و ردیابی خطا',
        google: 'Google Analytics برای تجزیه و تحلیل ترافیک'
      },
      preferences: {
        title: 'کوکی‌های ترجیحات',
        optional: 'اختیاری',
        description: 'این کوکی‌ها انتخاب‌های شما را به خاطر می‌سپارند و ویژگی‌های پیشرفته ارائه می‌دهند.',
        language: 'ترجیحات زبان و منطقه',
        theme: 'ترجیحات تم و نمایش',
        dashboard: 'طرح‌بندی و سفارشی‌سازی داشبورد'
      },
      marketing: {
        title: 'کوکی‌های بازاریابی',
        optional: 'اختیاری',
        description: 'این کوکی‌ها برای ارائه تبلیغات مرتبط و ردیابی اثربخشی کمپین استفاده می‌شوند.',
        advertising: 'تبلیغات هدفمند و بازاریابی مجدد',
        social: 'یکپارچگی و اشتراک‌گذاری رسانه‌های اجتماعی',
        tracking: 'ردیابی تبدیل و انتساب'
      },
      thirdParty: {
        title: 'کوکی‌های شخص ثالث',
        description: 'ما از خدمات شخص ثالث استفاده می‌کنیم که ممکن است کوکی‌های خود را تنظیم کنند:',
        services: 'خدمات شخص ثالث:',
        purposes: 'اهداف:',
        analytics: 'تجزیه و تحلیل وب‌سایت و بینش‌ها',
        payments: 'پردازش پرداخت امن',
        support: 'پشتیبانی مشتری و چت زنده',
        security: 'امنیت و جلوگیری از تقلب'
      },
      manage: {
        title: 'مدیریت ترجیحات کوکی شما',
        description: 'شما می‌توانید کنترل کنید که کدام کوکی‌ها را با استفاده از تنظیمات زیر می‌پذیرید:'
      },
      always: 'همیشه فعال',
      save: 'ذخیره ترجیحات',
      reject: 'رد همه',
      saved: 'ترجیحات کوکی با موفقیت ذخیره شد!',
      lastUpdated: 'آخرین به‌روزرسانی',
      contact: 'برای سؤالات در مورد سیاست کوکی ما، با ما تماس بگیرید'
    },
    licensing: {
      title: 'اطلاعات قانونی و مجوز',
      subtitle: 'اعتبارات حرفه‌ای و انطباق نظارتی ما',
      overview: {
        title: 'نمای کلی حرفه‌ای',
        content: 'شرکت مددی TFAS یک شرکت حسابداری کاملاً مجاز و تنظیم شده است که در انطباق با تمام الزامات فدرال کانادا و استان آلبرتا فعالیت می‌کند.'
      },
      business: {
        title: 'ثبت کسب و کار',
        federal: 'ثبت کسب و کار فدرال',
        alberta: 'مجوز استانی آلبرتا',
        number: 'شماره کسب و کار',
        license: 'شماره مجوز',
        status: 'وضعیت',
        active: 'فعال',
        registered: 'ثبت شده',
        expires: 'انقضا'
      },
      tax: {
        title: 'ثبت مالیاتی',
        cra: 'ثبت اداره درآمد کانادا (CRA)',
        gst: 'شماره GST/HST',
        payroll: 'حساب حقوق و دستمزد',
        status: 'وضعیت انطباق',
        compliant: 'کاملاً منطبق',
        lastFiled: 'آخرین ثبت'
      },
      professional: {
        title: 'گواهینامه‌های حرفه‌ای',
        certifications: 'گواهینامه‌های حرفه‌ای:',
        cpa: 'حسابدار حرفه‌ای منشور (CPA)',
        cga: 'حسابدار عمومی تأیید شده (CGA)',
        tax: 'گواهینامه تهیه‌کننده مالیات حرفه‌ای',
        memberships: 'عضویت‌های حرفه‌ای:',
        cpaa: 'CPA آلبرتا',
        chamber: 'اتاق بازرگانی کلگری',
        ita: 'موسسه مشاوران مالیاتی'
      },
      compliance: {
        title: 'انطباق نظارتی',
        standards: 'ما به استانداردها و مقررات زیر پایبند هستیم:',
        cra: 'مقررات و دستورالعمل‌های اداره درآمد کانادا',
        alberta: 'مقررات حسابداری و کسب و کار استان آلبرتا',
        pipeda: 'قانون حفاظت از اطلاعات شخصی و اسناد الکترونیکی (PIPEDA)',
        aml: 'انطباق ضد پولشویی (AML)',
        professional: 'استانداردها و اخلاق حسابداری حرفه‌ای',
        ethics: 'کد رفتار حرفه‌ای'
      },
      contact: {
        title: 'اطلاعات تماس',
        business: 'اطلاعات کسب و کار:',
        info: 'جزئیات تماس:'
      },
      lastUpdated: 'آخرین به‌روزرسانی',
      verification: 'تمام مجوزها و گواهینامه‌ها جاری هستند و می‌توانند با نهادهای نظارتی مربوطه تأیید شوند.'
    },
    security: {
      title: 'سلب مسئولیت امنیتی',
      subtitle: 'تعهد ما به حفاظت از داده‌ها و اطلاعات مالی شما',
      commitment: {
        title: 'تعهد امنیتی ما',
        content: 'ما از اقدامات امنیتی پیشرو در صنعت برای حفاظت از اطلاعات مالی و شخصی حساس شما استفاده می‌کنیم. امنیت داده‌های شما اولویت اصلی ما است.'
      },
      encryption: {
        title: 'رمزگذاری داده',
        ssl: 'رمزگذاری SSL/TLS',
        tls: 'رمزگذاری TLS 1.3 برای تمام انتقال داده',
        certificate: 'گواهینامه‌های SSL اعتبارسنجی توسعه‌یافته (EV)',
        transit: 'رمزگذاری انتها به انتها برای داده‌های در حال انتقال',
        data: 'رمزگذاری داده‌های در حالت استراحت',
        aes: 'رمزگذاری AES-256 برای داده‌های ذخیره شده',
        rest: 'ذخیره‌سازی پایگاه داده رمزگذاری شده',
        backup: 'پشتیبان‌گیری رمزگذاری شده و بازیابی فاجعه'
      },
      payments: {
        title: 'پردازش پرداخت امن',
        processors: 'پردازنده‌های پرداخت قابل اعتماد',
        pci: 'انطباق PCI DSS سطح 1',
        tokenization: 'توکن‌سازی کارت اعتباری',
        fraud: 'تشخیص پیشرفته تقلب',
        secure: 'دروازه پرداخت امن',
        buyer: 'برنامه‌های حفاظت از خریدار',
        encryption: 'رمزگذاری پرداخت انتها به انتها',
        disclaimer: 'سلب مسئولیت امنیت پرداخت',
        disclaimerText: 'ما اطلاعات کارت اعتباری را روی سرورهای خود ذخیره نمی‌کنیم. تمام داده‌های پرداخت توسط پردازنده‌های پرداخت شخص ثالث تأیید شده پردازش می‌شود.'
      },
      infrastructure: {
        title: 'امنیت زیرساخت',
        hosting: 'میزبانی امن',
        cloud: 'زیرساخت ابری درجه سازمانی',
        redundancy: 'افزونگی چندین مرکز داده',
        monitoring: 'نظارت امنیتی ۲۴/۷',
        access: 'کنترل‌های دسترسی',
        mfa: 'احراز هویت چندعاملی (MFA)',
        rbac: 'کنترل دسترسی مبتنی بر نقش (RBAC)',
        audit: 'ثبت ممیزی جامع',
        backup: 'پشتیبان‌گیری و بازیابی',
        automated: 'پشتیبان‌گیری خودکار روزانه',
        geographic: 'پشتیبان‌گیری‌های توزیع شده جغرافیایی',
        recovery: 'رویه‌های بازیابی فاجعه آزمایش شده'
      },
      confidentiality: {
        title: 'محرمانگی حرفه‌ای',
        professional: 'امتیاز حسابدار-مشتری',
        description: 'به عنوان حسابداران حرفه‌ای، ما محرمانگی سختگیرانه تمام اطلاعات مشتری را مطابق با استانداردهای حرفه‌ای و الزامات قانونی حفظ می‌کنیم.',
        privilege: 'حفاظت از امتیاز حسابدار-مشتری',
        disclosure: 'عدم افشای غیرمجاز اطلاعات مشتری',
        retention: 'سیاست‌های نگهداری امن اسناد',
        disposal: 'دفع امن اسناد حساس'
      },
      compliance: {
        title: 'انطباق امنیتی',
        standards: 'استانداردهای انطباق:',
        pipeda: 'انطباق PIPEDA برای حفاظت از حریم خصوصی',
        sox: 'انطباق SOX برای کنترل‌های مالی',
        iso: 'استانداردهای مدیریت امنیت ISO 27001',
        audits: 'ممیزی‌های امنیتی منظم:',
        annual: 'ارزیابی‌های امنیتی سالانه شخص ثالث',
        penetration: 'تست نفوذ منظم',
        vulnerability: 'اسکن مداوم آسیب‌پذیری'
      },
      incident: {
        title: 'پاسخ به حادثه امنیتی',
        response: 'طرح پاسخ به حادثه',
        description: 'ما یک طرح جامع پاسخ به حادثه برای رسیدگی به هر مسئله امنیتی احتمالی حفظ می‌کنیم:',
        immediate: 'پاسخ فوری:',
        containment: 'مهار فوری تهدید',
        assessment: 'ارزیابی سریع تأثیر',
        notification: 'اطلاع‌رسانی به مشتری ظرف ۲۴ ساعت',
        followup: 'اقدامات پیگیری:',
        investigation: 'تحقیق و تجزیه و تحلیل کامل',
        remediation: 'اصلاح کامل آسیب‌پذیری‌ها',
        prevention: 'اقدامات پیشگیری تقویت شده'
      },
      lastUpdated: 'آخرین به‌روزرسانی',
      contact: 'برای نگرانی‌های امنیتی، با ما تماس بگیرید'
    }
  },

  es: {
    // Header - Spanish
    'header.home': 'Inicio',
    'header.services': 'Servicios',
    'header.software': 'Software',
    'header.pricing': 'Precios',
    'header.contact': 'Contacto',
    'header.login': 'Acceso Cliente',
    'header.logout': 'Cerrar Sesión',
    'header.dashboard': 'Panel',
    'header.admin': 'Panel Admin',
    'header.employee': 'Panel Empleado',
    
    // Hero Section - Spanish
    'hero.title': 'Precisión en Números,',
    'hero.subtitle': 'Visión en Finanzas',
    'hero.description': 'Madadi Servicios Financieros y Contables INC - Soluciones contables profesionales para empresas de Calgary',
    'hero.viewPlans': 'Ver Planes de Precios',
    'hero.consultation': 'Consulta Gratuita',
    'hero.offer.title': '🎉 ¡Oferta por Tiempo Limitado!',
    'hero.offer.save': 'Ahorra hasta',
    'hero.offer.free': 'GRATIS',
    'hero.offer.setup': 'instalación de software por valor de $300',
    'hero.offer.basic': 'Plan Básico',
    'hero.offer.professional': 'Plan Profesional',
    'hero.offer.enterprise': 'Plan Empresarial',
    'hero.offer.valid': '*Oferta válida hasta el 31 de marzo de 2024. Solo clientes nuevos.',
    
    // Services - Spanish
    'services.title': 'Nuestros',
    'services.titleHighlight': 'Servicios',
    'services.description': 'Soluciones financieras y contables integrales diseñadas para apoyar su negocio en cada etapa',
    'services.learnMore': 'Saber Más',
    
    // AI Assistant - Spanish
    'ai.title': 'Asistente IA de Contabilidad',
    'ai.subtitle': 'Obtenga respuestas instantáneas sobre las leyes fiscales de Calgary, regulaciones de CRA y prácticas contables',
    'ai.placeholder': 'Pregunte sobre fechas límite de impuestos, requisitos de CRA, registro de empresas...',
    'ai.send': 'Enviar',
    'ai.examples.title': 'Pruebe preguntando:',
    'ai.example1': '¿Cuáles son las fechas límite de presentación de GST/HST para 2024?',
    'ai.example2': '¿Cómo registro una corporación en Alberta?',
    'ai.example3': '¿Qué gastos comerciales son deducibles de impuestos en Canadá?',
    'ai.example4': '¿Cuáles son los requisitos de remesa de nómina?',
    
    // Common - Spanish
    'common.loading': 'Cargando...',
    'common.save': 'Guardar',
    'common.cancel': 'Cancelar',
    'common.edit': 'Editar',
    'common.delete': 'Eliminar',
    'common.add': 'Agregar',
    'common.search': 'Buscar',
    'common.filter': 'Filtrar',
    'common.export': 'Exportar',
    'common.back': 'Volver al Sitio Web',
  },
  
  // Legal and Compliance Translations - Spanish
  legal: {
    privacy: {
      title: 'Política de Privacidad',
      subtitle: 'Cómo recopilamos, usamos y protegemos su información personal',
      overview: {
        title: 'Resumen de Privacidad',
        content: 'Madadi TFAS INC se compromete a proteger su privacidad e información personal de acuerdo con la Ley de Protección de Información Personal y Documentos Electrónicos (PIPEDA) y otras leyes de privacidad canadienses aplicables.'
      },
      collection: {
        title: 'Información que Recopilamos',
        intro: 'Recopilamos los siguientes tipos de información para brindar nuestros servicios de contabilidad e impuestos:',
        personal: 'Información de identificación personal (nombre, dirección, teléfono, correo electrónico)',
        financial: 'Información financiera (ingresos, gastos, documentos fiscales, estados de cuenta bancarios)',
        business: 'Información comercial (detalles de la empresa, números de registro, registros financieros)',
        technical: 'Información técnica (dirección IP, tipo de navegador, análisis de uso)',
        communication: 'Registros de comunicación (correos electrónicos, llamadas telefónicas, tickets de soporte)'
      },
      usage: {
        title: 'Cómo Usamos Su Información',
        intro: 'Utilizamos su información personal para los siguientes propósitos:',
        services: 'Proporcionar servicios de contabilidad, teneduría de libros y preparación de impuestos',
        compliance: 'Garantizar el cumplimiento de las regulaciones fiscales de CRA y provinciales',
        communication: 'Comunicarnos con usted sobre nuestros servicios y su cuenta',
        improvement: 'Mejorar nuestros servicios y desarrollar nuevas características',
        legal: 'Cumplir con los requisitos legales y regulatorios'
      },
      protection: {
        title: 'Cómo Protegemos Su Información',
        intro: 'Implementamos medidas de seguridad integrales para proteger su información personal:',
        technical: 'Salvaguardas Técnicas',
        technicalDesc: 'Cifrado SSL, servidores seguros, controles de acceso y auditorías de seguridad regulares',
        administrative: 'Salvaguardas Administrativas',
        administrativeDesc: 'Capacitación del personal, acuerdos de confidencialidad y políticas de acceso estrictas'
      },
      thirdParty: {
        title: 'Servicios de Terceros',
        intro: 'Trabajamos con proveedores de servicios de terceros confiables que pueden tener acceso a su información:',
        services: 'Servicios de Terceros que Utilizamos:',
        stripe: 'Procesamiento de pagos y transacciones seguras',
        paypal: 'Procesamiento de pagos alternativo',
        analytics: 'Análisis del sitio web y monitoreo de rendimiento',
        storage: 'Almacenamiento seguro de documentos y servicios de respaldo'
      },
      rights: {
        title: 'Sus Derechos de Privacidad',
        intro: 'Bajo PIPEDA, usted tiene los siguientes derechos con respecto a su información personal:',
        access: 'Derecho a acceder a su información personal',
        correction: 'Derecho a solicitar corrección de información inexacta',
        deletion: 'Derecho a solicitar eliminación de su información',
        portability: 'Derecho a la portabilidad de datos',
        withdrawal: 'Derecho a retirar el consentimiento',
        complaint: 'Derecho a presentar una queja ante el Comisionado de Privacidad'
      },
      contact: {
        title: 'Información de Contacto de Privacidad',
        intro: 'Para cualquier pregunta o solicitud relacionada con la privacidad, contáctenos:'
      },
      lastUpdated: 'Última Actualización',
      pipedaCompliance: 'Esta política de privacidad cumple con la Ley de Protección de Información Personal y Documentos Electrónicos (PIPEDA) y la legislación provincial de privacidad aplicable.'
    },
    terms: {
      title: 'Términos y Condiciones',
      subtitle: 'Términos legales que rigen el uso de nuestros servicios',
      acceptance: {
        title: 'Aceptación de Términos',
        content: 'Al usar nuestros servicios, usted acepta estar sujeto a estos términos y condiciones. Si no está de acuerdo con alguna parte de estos términos, no puede usar nuestros servicios.'
      },
      services: {
        title: 'Servicios Ofrecidos',
        intro: 'Madadi TFAS INC proporciona los siguientes servicios profesionales:',
        accounting: 'Servicios de Contabilidad',
        bookkeeping: 'Teneduría de libros y mantenimiento de registros financieros',
        statements: 'Preparación de estados financieros',
        reconciliation: 'Servicios de conciliación bancaria',
        tax: 'Servicios Fiscales',
        preparation: 'Preparación y presentación de declaraciones de impuestos',
        filing: 'Presentación de GST/HST y remesas de nómina',
        planning: 'Estrategias de planificación y optimización fiscal'
      },
      liability: {
        title: 'Responsabilidad y Exenciones',
        disclaimer: 'Exenciones Importantes:',
        professional: 'Nuestros servicios se proporcionan con fines informativos y orientación profesional',
        decisions: 'Las decisiones financieras y fiscales finales siguen siendo su responsabilidad',
        accuracy: 'Aunque nos esforzamos por la precisión, no podemos garantizar resultados libres de errores',
        thirdParty: 'No somos responsables de fallas de servicios de terceros o violaciones de datos'
      },
      responsibilities: {
        title: 'Responsabilidades del Cliente',
        intro: 'Como nuestro cliente, usted es responsable de:',
        client: 'Sus Responsabilidades:',
        accurate: 'Proporcionar información financiera precisa y completa',
        timely: 'Enviar documentos e información de manera oportuna',
        cooperation: 'Cooperar con nuestras solicitudes de información adicional',
        compliance: 'Garantizar el cumplimiento de todas las leyes y regulaciones aplicables'
      },
      payment: {
        title: 'Términos de Pago',
        terms: 'Términos de Pago:',
        monthly: 'Las tarifas de suscripción mensual se deben pagar por adelantado',
        advance: 'Los servicios basados en proyectos requieren un 50% de pago por adelantado',
        late: 'Pueden aplicarse tarifas por pago tardío después de 30 días',
        methods: 'Métodos de Pago Aceptados:',
        credit: 'Tarjetas de crédito y débito (a través de Stripe)',
        bank: 'Transferencias bancarias y pagos por cable',
        paypal: 'Pagos de PayPal'
      },
      refund: {
        title: 'Política de Reembolso y Cancelación',
        policy: 'Nuestra política de reembolso incluye los siguientes términos:',
        services: 'Los servicios ya proporcionados no son reembolsables',
        software: 'Las compras de software son reembolsables dentro de 30 días',
        cancellation: 'Las cancelaciones de suscripción toman efecto al final del período de facturación'
      },
      jurisdiction: {
        title: 'Ley Aplicable y Jurisdicción',
        governing: 'Estos términos se rigen por:',
        alberta: 'Las leyes de la Provincia de Alberta, Canadá',
        federal: 'Las leyes federales aplicables de Canadá',
        disputes: 'Las disputas se resolverán en los tribunales de Alberta'
      },
      modifications: {
        title: 'Modificaciones a los Términos',
        content: 'Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios se publicarán en nuestro sitio web y entrarán en vigor inmediatamente después de la publicación.'
      },
      lastUpdated: 'Última Actualización',
      contact: 'Para preguntas sobre estos términos, contáctenos en'
    },
    cookies: {
      title: 'Política de Cookies',
      subtitle: 'Cómo usamos cookies y tecnologías similares',
      what: {
        title: '¿Qué son las Cookies?',
        content: 'Las cookies son pequeños archivos de texto almacenados en su dispositivo cuando visita nuestro sitio web. Nos ayudan a brindarle una mejor experiencia de usuario y analizar cómo se usa nuestro sitio web.'
      },
      types: {
        title: 'Tipos de Cookies que Usamos'
      },
      essential: {
        title: 'Cookies Esenciales',
        required: 'Siempre Requeridas',
        description: 'Estas cookies son necesarias para que el sitio web funcione correctamente y no se pueden desactivar.',
        session: 'Gestión de sesiones y autenticación de usuarios',
        security: 'Características de seguridad y prevención de fraude',
        preferences: 'Preferencias y configuraciones básicas del usuario'
      },
      analytics: {
        title: 'Cookies de Análisis',
        optional: 'Opcional',
        description: 'Estas cookies nos ayudan a entender cómo los visitantes interactúan con nuestro sitio web.',
        usage: 'Estadísticas de uso del sitio web y métricas de rendimiento',
        performance: 'Tiempos de carga de página y seguimiento de errores',
        google: 'Google Analytics para análisis de tráfico'
      },
      preferences: {
        title: 'Cookies de Preferencias',
        optional: 'Opcional',
        description: 'Estas cookies recuerdan sus elecciones y proporcionan características mejoradas.',
        language: 'Preferencias de idioma y región',
        theme: 'Preferencias de tema y visualización',
        dashboard: 'Diseño del panel y personalizaciones'
      },
      marketing: {
        title: 'Cookies de Marketing',
        optional: 'Opcional',
        description: 'Estas cookies se usan para entregar anuncios relevantes y rastrear la efectividad de las campañas.',
        advertising: 'Publicidad dirigida y remarketing',
        social: 'Integración y compartición en redes sociales',
        tracking: 'Seguimiento de conversiones y atribución'
      },
      thirdParty: {
        title: 'Cookies de Terceros',
        description: 'Usamos servicios de terceros que pueden establecer sus propias cookies:',
        services: 'Servicios de Terceros:',
        purposes: 'Propósitos:',
        analytics: 'Análisis del sitio web e insights',
        payments: 'Procesamiento seguro de pagos',
        support: 'Soporte al cliente y chat en vivo',
        security: 'Seguridad y prevención de fraude'
      },
      manage: {
        title: 'Gestione Sus Preferencias de Cookies',
        description: 'Puede controlar qué cookies acepta usando la configuración a continuación:'
      },
      always: 'Siempre Activo',
      save: 'Guardar Preferencias',
      reject: 'Rechazar Todo',
      saved: '¡Preferencias de cookies guardadas exitosamente!',
      lastUpdated: 'Última Actualización',
      contact: 'Para preguntas sobre nuestra política de cookies, contáctenos en'
    },
    licensing: {
      title: 'Información Legal y de Licencias',
      subtitle: 'Nuestras credenciales profesionales y cumplimiento regulatorio',
      overview: {
        title: 'Resumen Profesional',
        content: 'Madadi TFAS INC es una firma de contabilidad completamente licenciada y regulada que opera en cumplimiento con todos los requisitos federales canadienses y provinciales de Alberta.'
      },
      business: {
        title: 'Registro Comercial',
        federal: 'Registro Comercial Federal',
        alberta: 'Licencia Provincial de Alberta',
        number: 'Número de Negocio',
        license: 'Número de Licencia',
        status: 'Estado',
        active: 'Activo',
        registered: 'Registrado',
        expires: 'Expira'
      },
      tax: {
        title: 'Registro Fiscal',
        cra: 'Registro de la Agencia de Ingresos de Canadá (CRA)',
        gst: 'Número GST/HST',
        payroll: 'Cuenta de Nómina',
        status: 'Estado de Cumplimiento',
        compliant: 'Totalmente Conforme',
        lastFiled: 'Última Presentación'
      },
      professional: {
        title: 'Certificaciones Profesionales',
        certifications: 'Certificaciones Profesionales:',
        cpa: 'Contador Profesional Colegiado (CPA)',
        cga: 'Contador General Certificado (CGA)',
        tax: 'Certificación de Preparador de Impuestos Profesional',
        memberships: 'Membresías Profesionales:',
        cpaa: 'CPA Alberta',
        chamber: 'Cámara de Comercio de Calgary',
        ita: 'Instituto de Asesores Fiscales'
      },
      compliance: {
        title: 'Cumplimiento Regulatorio',
        standards: 'Nos adherimos a los siguientes estándares y regulaciones:',
        cra: 'Regulaciones y pautas de la Agencia de Ingresos de Canadá',
        alberta: 'Regulaciones de contabilidad y negocios provinciales de Alberta',
        pipeda: 'Ley de Protección de Información Personal y Documentos Electrónicos (PIPEDA)',
        aml: 'Cumplimiento Anti-Lavado de Dinero (AML)',
        professional: 'Estándares y ética de contabilidad profesional',
        ethics: 'Código de Conducta Profesional'
      },
      contact: {
        title: 'Información de Contacto',
        business: 'Información Comercial:',
        info: 'Detalles de Contacto:'
      },
      lastUpdated: 'Última Actualización',
      verification: 'Todas las licencias y certificaciones están vigentes y pueden verificarse con los organismos reguladores respectivos.'
    },
    security: {
      title: 'Exención de Responsabilidad de Seguridad',
      subtitle: 'Nuestro compromiso con la protección de sus datos e información financiera',
      commitment: {
        title: 'Nuestro Compromiso de Seguridad',
        content: 'Empleamos medidas de seguridad líderes en la industria para proteger su información financiera y personal sensible. La seguridad de sus datos es nuestra máxima prioridad.'
      },
      encryption: {
        title: 'Cifrado de Datos',
        ssl: 'Cifrado SSL/TLS',
        tls: 'Cifrado TLS 1.3 para toda transmisión de datos',
        certificate: 'Certificados SSL de Validación Extendida (EV)',
        transit: 'Cifrado de extremo a extremo para datos en tránsito',
        data: 'Cifrado de Datos en Reposo',
        aes: 'Cifrado AES-256 para datos almacenados',
        rest: 'Almacenamiento de base de datos cifrado',
        backup: 'Respaldo cifrado y recuperación ante desastres'
      },
      payments: {
        title: 'Procesamiento Seguro de Pagos',
        processors: 'Procesadores de Pago Confiables',
        pci: 'Cumplimiento PCI DSS Nivel 1',
        tokenization: 'Tokenización de tarjetas de crédito',
        fraud: 'Detección avanzada de fraude',
        secure: 'Pasarela de pago segura',
        buyer: 'Programas de protección al comprador',
        encryption: 'Cifrado de pago de extremo a extremo',
        disclaimer: 'Exención de Responsabilidad de Seguridad de Pagos',
        disclaimerText: 'No almacenamos información de tarjetas de crédito en nuestros servidores. Todos los datos de pago son procesados por procesadores de pago de terceros certificados.'
      },
      infrastructure: {
        title: 'Seguridad de Infraestructura',
        hosting: 'Alojamiento Seguro',
        cloud: 'Infraestructura en la nube de grado empresarial',
        redundancy: 'Redundancia de múltiples centros de datos',
        monitoring: 'Monitoreo de seguridad 24/7',
        access: 'Controles de Acceso',
        mfa: 'Autenticación multifactor (MFA)',
        rbac: 'Control de acceso basado en roles (RBAC)',
        audit: 'Registro de auditoría integral',
        backup: 'Respaldo y Recuperación',
        automated: 'Respaldos diarios automatizados',
        geographic: 'Respaldos distribuidos geográficamente',
        recovery: 'Procedimientos de recuperación ante desastres probados'
      },
      confidentiality: {
        title: 'Confidencialidad Profesional',
        professional: 'Privilegio Contador-Cliente',
        description: 'Como contadores profesionales, mantenemos estricta confidencialidad de toda la información del cliente de acuerdo con los estándares profesionales y requisitos legales.',
        privilege: 'Protección del privilegio contador-cliente',
        disclosure: 'No divulgación no autorizada de información del cliente',
        retention: 'Políticas de retención segura de documentos',
        disposal: 'Disposición segura de documentos sensibles'
      },
      compliance: {
        title: 'Cumplimiento de Seguridad',
        standards: 'Estándares de Cumplimiento:',
        pipeda: 'Cumplimiento PIPEDA para protección de privacidad',
        sox: 'Cumplimiento SOX para controles financieros',
        iso: 'Estándares de gestión de seguridad ISO 27001',
        audits: 'Auditorías de Seguridad Regulares:',
        annual: 'Evaluaciones de seguridad anuales de terceros',
        penetration: 'Pruebas de penetración regulares',
        vulnerability: 'Escaneo continuo de vulnerabilidades'
      },
      incident: {
        title: 'Respuesta a Incidentes de Seguridad',
        response: 'Plan de Respuesta a Incidentes',
        description: 'Mantenemos un plan integral de respuesta a incidentes para abordar cualquier problema de seguridad potencial:',
        immediate: 'Respuesta Inmediata:',
        containment: 'Contención inmediata de amenazas',
        assessment: 'Evaluación rápida del impacto',
        notification: 'Notificación al cliente dentro de 24 horas',
        followup: 'Acciones de Seguimiento:',
        investigation: 'Investigación y análisis exhaustivos',
        remediation: 'Remediación completa de vulnerabilidades',
        prevention: 'Medidas de prevención mejoradas'
      },
      lastUpdated: 'Última Actualización',
      contact: 'Para preocupaciones de seguridad, contáctenos en'
    }
  },

  fr: {
    // Header - French
    'header.home': 'Accueil',
    'header.services': 'Services',
    'header.software': 'Logiciel',
    'header.pricing': 'Tarifs',
    'header.contact': 'Contact',
    'header.login': 'Connexion Client',
    'header.logout': 'Déconnexion',
    'header.dashboard': 'Tableau de Bord',
    'header.admin': 'Panneau Admin',
    'header.employee': 'Panneau Employé',
    
    // Hero Section - French
    'hero.title': 'Précision dans les Chiffres,',
    'hero.subtitle': 'Vision en Finance',
    'hero.description': 'Madadi Services Financiers et Comptables INC - Solutions comptables professionnelles pour les entreprises de Calgary',
    'hero.viewPlans': 'Voir les Plans Tarifaires',
    'hero.consultation': 'Consultation Gratuite',
    'hero.offer.title': '🎉 Offre à Durée Limitée!',
    'hero.offer.save': 'Économisez jusqu\'à',
    'hero.offer.free': 'GRATUIT',
    'hero.offer.setup': 'installation de logiciel d\'une valeur de 300$',
    'hero.offer.basic': 'Plan de Base',
    'hero.offer.professional': 'Plan Professionnel',
    'hero.offer.enterprise': 'Plan Entreprise',
    'hero.offer.valid': '*Offre valide jusqu\'au 31 mars 2024. Nouveaux clients seulement.',
    
    // Services - French
    'services.title': 'Nos',
    'services.titleHighlight': 'Services',
    'services.description': 'Solutions financières et comptables complètes conçues pour soutenir votre entreprise à chaque étape',
    'services.learnMore': 'En Savoir Plus',
    
    // AI Assistant - French
    'ai.title': 'Assistant IA Comptable',
    'ai.subtitle': 'Obtenez des réponses instantanées sur les lois fiscales de Calgary, les réglementations ARC et les pratiques comptables',
    'ai.placeholder': 'Demandez sur les échéances fiscales, les exigences ARC, l\'enregistrement d\'entreprise...',
    'ai.send': 'Envoyer',
    'ai.examples.title': 'Essayez de demander:',
    'ai.example1': 'Quelles sont les échéances de dépôt TPS/TVH pour 2024?',
    'ai.example2': 'Comment enregistrer une corporation en Alberta?',
    'ai.example3': 'Quelles dépenses d\'entreprise sont déductibles d\'impôt au Canada?',
    'ai.example4': 'Quelles sont les exigences de versement de paie?',
    
    // Common - French
    'common.loading': 'Chargement...',
    'common.save': 'Sauvegarder',
    'common.cancel': 'Annuler',
    'common.edit': 'Modifier',
    'common.delete': 'Supprimer',
    'common.add': 'Ajouter',
    'common.search': 'Rechercher',
    'common.filter': 'Filtrer',
    'common.export': 'Exporter',
    'common.back': 'Retour au Site Web',
  },
  
  // Legal and Compliance Translations - French
  legal: {
    privacy: {
      title: 'Politique de Confidentialité',
      subtitle: 'Comment nous collectons, utilisons et protégeons vos informations personnelles',
      overview: {
        title: 'Aperçu de la Confidentialité',
        content: 'Madadi TFAS INC s\'engage à protéger votre vie privée et vos informations personnelles conformément à la Loi sur la protection des renseignements personnels et les documents électroniques (LPRPDE) et autres lois canadiennes sur la vie privée applicables.'
      },
      collection: {
        title: 'Informations que Nous Collectons',
        intro: 'Nous collectons les types d\'informations suivants pour fournir nos services de comptabilité et d\'impôts :',
        personal: 'Informations d\'identification personnelle (nom, adresse, téléphone, courriel)',
        financial: 'Informations financières (revenus, dépenses, documents fiscaux, relevés bancaires)',
        business: 'Informations commerciales (détails de l\'entreprise, numéros d\'enregistrement, dossiers financiers)',
        technical: 'Informations techniques (adresse IP, type de navigateur, analyses d\'utilisation)',
        communication: 'Enregistrements de communication (courriels, appels téléphoniques, tickets de support)'
      },
      usage: {
        title: 'Comment Nous Utilisons Vos Informations',
        intro: 'Nous utilisons vos informations personnelles aux fins suivantes :',
        services: 'Fournir des services de comptabilité, de tenue de livres et de préparation d\'impôts',
        compliance: 'Assurer la conformité avec les réglementations fiscales de l\'ARC et provinciales',
        communication: 'Communiquer avec vous concernant nos services et votre compte',
        improvement: 'Améliorer nos services et développer de nouvelles fonctionnalités',
        legal: 'Respecter les exigences légales et réglementaires'
      },
      protection: {
        title: 'Comment Nous Protégeons Vos Informations',
        intro: 'Nous mettons en œuvre des mesures de sécurité complètes pour protéger vos informations personnelles :',
        technical: 'Mesures de Protection Techniques',
        technicalDesc: 'Chiffrement SSL, serveurs sécurisés, contrôles d\'accès et audits de sécurité réguliers',
        administrative: 'Mesures de Protection Administratives',
        administrativeDesc: 'Formation du personnel, accords de confidentialité et politiques d\'accès strictes'
      },
      thirdParty: {
        title: 'Services de Tiers',
        intro: 'Nous travaillons avec des fournisseurs de services tiers de confiance qui peuvent avoir accès à vos informations :',
        services: 'Services de Tiers que Nous Utilisons :',
        stripe: 'Traitement des paiements et transactions sécurisées',
        paypal: 'Traitement de paiement alternatif',
        analytics: 'Analyses du site web et surveillance des performances',
        storage: 'Stockage sécurisé de documents et services de sauvegarde'
      },
      rights: {
        title: 'Vos Droits de Confidentialité',
        intro: 'Sous la LPRPDE, vous avez les droits suivants concernant vos informations personnelles :',
        access: 'Droit d\'accéder à vos informations personnelles',
        correction: 'Droit de demander la correction d\'informations inexactes',
        deletion: 'Droit de demander la suppression de vos informations',
        portability: 'Droit à la portabilité des données',
        withdrawal: 'Droit de retirer le consentement',
        complaint: 'Droit de déposer une plainte auprès du Commissaire à la protection de la vie privée'
      },
      contact: {
        title: 'Informations de Contact pour la Confidentialité',
        intro: 'Pour toute question ou demande liée à la confidentialité, veuillez nous contacter :'
      },
      lastUpdated: 'Dernière Mise à Jour',
      pipedaCompliance: 'Cette politique de confidentialité est conforme à la Loi sur la protection des renseignements personnels et les documents électroniques (LPRPDE) et à la législation provinciale sur la vie privée applicable.'
    },
    terms: {
      title: 'Termes et Conditions',
      subtitle: 'Termes légaux régissant l\'utilisation de nos services',
      acceptance: {
        title: 'Acceptation des Termes',
        content: 'En utilisant nos services, vous acceptez d\'être lié par ces termes et conditions. Si vous n\'êtes pas d\'accord avec une partie de ces termes, vous ne pouvez pas utiliser nos services.'
      },
      services: {
        title: 'Services Offerts',
        intro: 'Madadi TFAS INC fournit les services professionnels suivants :',
        accounting: 'Services de Comptabilité',
        bookkeeping: 'Tenue de livres et maintenance des dossiers financiers',
        statements: 'Préparation d\'états financiers',
        reconciliation: 'Services de rapprochement bancaire',
        tax: 'Services Fiscaux',
        preparation: 'Préparation et dépôt de déclarations d\'impôts',
        filing: 'Dépôt de TPS/TVH et remises de paie',
        planning: 'Stratégies de planification et d\'optimisation fiscale'
      },
      liability: {
        title: 'Responsabilité et Décharges',
        disclaimer: 'Décharges Importantes :',
        professional: 'Nos services sont fournis à des fins d\'information et d\'orientation professionnelle',
        decisions: 'Les décisions financières et fiscales finales restent de votre responsabilité',
        accuracy: 'Bien que nous nous efforcions d\'être précis, nous ne pouvons garantir des résultats sans erreur',
        thirdParty: 'Nous ne sommes pas responsables des défaillances de services tiers ou des violations de données'
      },
      responsibilities: {
        title: 'Responsabilités du Client',
        intro: 'En tant que notre client, vous êtes responsable de :',
        client: 'Vos Responsabilités :',
        accurate: 'Fournir des informations financières précises et complètes',
        timely: 'Soumettre les documents et informations en temps opportun',
        cooperation: 'Coopérer avec nos demandes d\'informations supplémentaires',
        compliance: 'Assurer la conformité avec toutes les lois et réglementations applicables'
      },
      payment: {
        title: 'Conditions de Paiement',
        terms: 'Conditions de Paiement :',
        monthly: 'Les frais d\'abonnement mensuel sont dus à l\'avance',
        advance: 'Les services basés sur des projets nécessitent 50% de paiement à l\'avance',
        late: 'Des frais de retard peuvent s\'appliquer après 30 jours',
        methods: 'Méthodes de Paiement Acceptées :',
        credit: 'Cartes de crédit et de débit (via Stripe)',
        bank: 'Virements bancaires et paiements par virement',
        paypal: 'Paiements PayPal'
      },
      refund: {
        title: 'Politique de Remboursement et d\'Annulation',
        policy: 'Notre politique de remboursement comprend les termes suivants :',
        services: 'Les services déjà fournis ne sont pas remboursables',
        software: 'Les achats de logiciels sont remboursables dans les 30 jours',
        cancellation: 'Les annulations d\'abonnement prennent effet à la fin de la période de facturation'
      },
      jurisdiction: {
        title: 'Loi Applicable et Juridiction',
        governing: 'Ces termes sont régis par :',
        alberta: 'Les lois de la Province d\'Alberta, Canada',
        federal: 'Les lois fédérales applicables du Canada',
        disputes: 'Les litiges seront résolus dans les tribunaux de l\'Alberta'
      },
      modifications: {
        title: 'Modifications des Termes',
        content: 'Nous nous réservons le droit de modifier ces termes à tout moment. Les changements seront publiés sur notre site web et prendront effet immédiatement après publication.'
      },
      lastUpdated: 'Dernière Mise à Jour',
      contact: 'Pour des questions sur ces termes, contactez-nous à'
    },
    cookies: {
      title: 'Politique des Cookies',
      subtitle: 'Comment nous utilisons les cookies et technologies similaires',
      what: {
        title: 'Que sont les Cookies ?',
        content: 'Les cookies sont de petits fichiers texte stockés sur votre appareil lorsque vous visitez notre site web. Ils nous aident à vous fournir une meilleure expérience utilisateur et à analyser comment notre site web est utilisé.'
      },
      types: {
        title: 'Types de Cookies que Nous Utilisons'
      },
      essential: {
        title: 'Cookies Essentiels',
        required: 'Toujours Requis',
        description: 'Ces cookies sont nécessaires au bon fonctionnement du site web et ne peuvent pas être désactivés.',
        session: 'Gestion de session et authentification utilisateur',
        security: 'Fonctionnalités de sécurité et prévention de la fraude',
        preferences: 'Préférences et paramètres de base de l\'utilisateur'
      },
      analytics: {
        title: 'Cookies d\'Analyse',
        optional: 'Optionnel',
        description: 'Ces cookies nous aident à comprendre comment les visiteurs interagissent avec notre site web.',
        usage: 'Statistiques d\'utilisation du site web et métriques de performance',
        performance: 'Temps de chargement des pages et suivi des erreurs',
        google: 'Google Analytics pour l\'analyse du trafic'
      },
      preferences: {
        title: 'Cookies de Préférences',
        optional: 'Optionnel',
        description: 'Ces cookies se souviennent de vos choix et fournissent des fonctionnalités améliorées.',
        language: 'Préférences de langue et de région',
        theme: 'Préférences de thème et d\'affichage',
        dashboard: 'Mise en page du tableau de bord et personnalisations'
      },
      marketing: {
        title: 'Cookies de Marketing',
        optional: 'Optionnel',
        description: 'Ces cookies sont utilisés pour diffuser des publicités pertinentes et suivre l\'efficacité des campagnes.',
        advertising: 'Publicité ciblée et remarketing',
        social: 'Intégration et partage sur les réseaux sociaux',
        tracking: 'Suivi des conversions et attribution'
      },
      thirdParty: {
        title: 'Cookies de Tiers',
        description: 'Nous utilisons des services tiers qui peuvent définir leurs propres cookies :',
        services: 'Services de Tiers :',
        purposes: 'Objectifs :',
        analytics: 'Analyses du site web et insights',
        payments: 'Traitement sécurisé des paiements',
        support: 'Support client et chat en direct',
        security: 'Sécurité et prévention de la fraude'
      },
      manage: {
        title: 'Gérez Vos Préférences de Cookies',
        description: 'Vous pouvez contrôler quels cookies vous acceptez en utilisant les paramètres ci-dessous :'
      },
      always: 'Toujours Actif',
      save: 'Sauvegarder les Préférences',
      reject: 'Tout Rejeter',
      saved: 'Préférences de cookies sauvegardées avec succès !',
      lastUpdated: 'Dernière Mise à Jour',
      contact: 'Pour des questions sur notre politique de cookies, contactez-nous à'
    },
    licensing: {
      title: 'Informations Légales et de Licence',
      subtitle: 'Nos références professionnelles et conformité réglementaire',
      overview: {
        title: 'Aperçu Professionnel',
        content: 'Madadi TFAS INC est une firme comptable entièrement licenciée et réglementée opérant en conformité avec toutes les exigences fédérales canadiennes et provinciales de l\'Alberta.'
      },
      business: {
        title: 'Enregistrement Commercial',
        federal: 'Enregistrement Commercial Fédéral',
        alberta: 'Licence Provinciale de l\'Alberta',
        number: 'Numéro d\'Entreprise',
        license: 'Numéro de Licence',
        status: 'Statut',
        active: 'Actif',
        registered: 'Enregistré',
        expires: 'Expire'
      },
      tax: {
        title: 'Enregistrement Fiscal',
        cra: 'Enregistrement de l\'Agence du Revenu du Canada (ARC)',
        gst: 'Numéro TPS/TVH',
        payroll: 'Compte de Paie',
        status: 'Statut de Conformité',
        compliant: 'Entièrement Conforme',
        lastFiled: 'Dernier Dépôt'
      },
      professional: {
        title: 'Certifications Professionnelles',
        certifications: 'Certifications Professionnelles :',
        cpa: 'Comptable Professionnel Agréé (CPA)',
        cga: 'Comptable Général Accrédité (CGA)',
        tax: 'Certification de Préparateur d\'Impôts Professionnel',
        memberships: 'Adhésions Professionnelles :',
        cpaa: 'CPA Alberta',
        chamber: 'Chambre de Commerce de Calgary',
        ita: 'Institut des Conseillers Fiscaux'
      },
      compliance: {
        title: 'Conformité Réglementaire',
        standards: 'Nous adhérons aux normes et réglementations suivantes :',
        cra: 'Réglementations et directives de l\'Agence du Revenu du Canada',
        alberta: 'Réglementations comptables et commerciales provinciales de l\'Alberta',
        pipeda: 'Loi sur la protection des renseignements personnels et les documents électroniques (LPRPDE)',
        aml: 'Conformité Anti-Blanchiment d\'Argent (AML)',
        professional: 'Normes et éthique comptables professionnelles',
        ethics: 'Code de Conduite Professionnelle'
      },
      contact: {
        title: 'Informations de Contact',
        business: 'Informations Commerciales :',
        info: 'Détails de Contact :'
      },
      lastUpdated: 'Dernière Mise à Jour',
      verification: 'Toutes les licences et certifications sont à jour et peuvent être vérifiées auprès des organismes de réglementation respectifs.'
    },
    security: {
      title: 'Décharge de Responsabilité de Sécurité',
      subtitle: 'Notre engagement à protéger vos données et informations financières',
      commitment: {
        title: 'Notre Engagement de Sécurité',
        content: 'Nous employons des mesures de sécurité de pointe dans l\'industrie pour protéger vos informations financières et personnelles sensibles. La sécurité de vos données est notre priorité absolue.'
      },
      encryption: {
        title: 'Chiffrement des Données',
        ssl: 'Chiffrement SSL/TLS',
        tls: 'Chiffrement TLS 1.3 pour toute transmission de données',
        certificate: 'Certificats SSL à Validation Étendue (EV)',
        transit: 'Chiffrement de bout en bout pour les données en transit',
        data: 'Chiffrement des Données au Repos',
        aes: 'Chiffrement AES-256 pour les données stockées',
        rest: 'Stockage de base de données chiffré',
        backup: 'Sauvegarde chiffrée et récupération après sinistre'
      },
      payments: {
        title: 'Traitement Sécurisé des Paiements',
        processors: 'Processeurs de Paiement de Confiance',
        pci: 'Conformité PCI DSS Niveau 1',
        tokenization: 'Tokenisation des cartes de crédit',
        fraud: 'Détection avancée de fraude',
        secure: 'Passerelle de paiement sécurisée',
        buyer: 'Programmes de protection de l\'acheteur',
        encryption: 'Chiffrement de paiement de bout en bout',
        disclaimer: 'Décharge de Responsabilité de Sécurité des Paiements',
        disclaimerText: 'Nous ne stockons pas les informations de carte de crédit sur nos serveurs. Toutes les données de paiement sont traitées par des processeurs de paiement tiers certifiés.'
      },
      infrastructure: {
        title: 'Sécurité de l\'Infrastructure',
        hosting: 'Hébergement Sécurisé',
        cloud: 'Infrastructure cloud de niveau entreprise',
        redundancy: 'Redondance de plusieurs centres de données',
        monitoring: 'Surveillance de sécurité 24/7',
        access: 'Contrôles d\'Accès',
        mfa: 'Authentification multifacteur (MFA)',
        rbac: 'Contrôle d\'accès basé sur les rôles (RBAC)',
        audit: 'Journalisation d\'audit complète',
        backup: 'Sauvegarde et Récupération',
        automated: 'Sauvegardes quotidiennes automatisées',
        geographic: 'Sauvegardes distribuées géographiquement',
        recovery: 'Procédures de récupération après sinistre testées'
      },
      confidentiality: {
        title: 'Confidentialité Professionnelle',
        professional: 'Privilège Comptable-Client',
        description: 'En tant que comptables professionnels, nous maintenons une stricte confidentialité de toutes les informations client conformément aux normes professionnelles et aux exigences légales.',
        privilege: 'Protection du privilège comptable-client',
        disclosure: 'Aucune divulgation non autorisée d\'informations client',
        retention: 'Politiques de rétention sécurisée des documents',
        disposal: 'Élimination sécurisée des documents sensibles'
      },
      compliance: {
        title: 'Conformité de Sécurité',
        standards: 'Normes de Conformité :',
        pipeda: 'Conformité LPRPDE pour la protection de la vie privée',
        sox: 'Conformité SOX pour les contrôles financiers',
        iso: 'Normes de gestion de sécurité ISO 27001',
        audits: 'Audits de Sécurité Réguliers :',
        annual: 'Évaluations de sécurité annuelles par des tiers',
        penetration: 'Tests de pénétration réguliers',
        vulnerability: 'Analyse continue des vulnérabilités'
      },
      incident: {
        title: 'Réponse aux Incidents de Sécurité',
        response: 'Plan de Réponse aux Incidents',
        description: 'Nous maintenons un plan complet de réponse aux incidents pour traiter tout problème de sécurité potentiel :',
        immediate: 'Réponse Immédiate :',
        containment: 'Confinement immédiat des menaces',
        assessment: 'Évaluation rapide de l\'impact',
        notification: 'Notification client dans les 24 heures',
        followup: 'Actions de Suivi :',
        investigation: 'Investigation et analyse approfondies',
        remediation: 'Remédiation complète des vulnérabilités',
        prevention: 'Mesures de prévention renforcées'
      },
      lastUpdated: 'Dernière Mise à Jour',
      contact: 'Pour les préoccupations de sécurité, contactez-nous à'
    }
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || translations.en[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};