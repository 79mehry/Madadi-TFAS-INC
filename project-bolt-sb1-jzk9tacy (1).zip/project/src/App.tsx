import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import PromotionalOffer from './components/PromotionalOffer';
import ClientDashboard from './components/ClientDashboard';
import AdminPanel from './components/AdminPanel';
import EmployeePanel from './components/EmployeePanel';
import SoftwareStore from './components/SoftwareStore';
import SubscriptionPlans from './components/SubscriptionPlans';
import LoginModal from './components/LoginModal';
import Footer from './components/Footer';
import AIAssistant from './components/AIAssistant';
import PrivacyPolicy from './components/legal/PrivacyPolicy';
import TermsConditions from './components/legal/TermsConditions';
import CookiePolicy from './components/legal/CookiePolicy';
import LegalLicensing from './components/legal/LegalLicensing';
import SecurityDisclaimer from './components/legal/SecurityDisclaimer';

type UserRole = 'client' | 'admin' | 'employee' | null;
type CurrentView = 'website' | 'dashboard' | 'admin' | 'employee' | 'software' | 'plans' | 'privacy' | 'terms' | 'cookies' | 'legal' | 'security';

function App() {
  const [userRole, setUserRole] = useState<UserRole>(null);
  const [currentView, setCurrentView] = useState<CurrentView>('website');
  const [showLoginModal, setShowLoginModal] = useState(false);

  const handleLogin = (role: UserRole = 'client') => {
    setUserRole(role);
    setShowLoginModal(false);
    
    // Navigate to appropriate dashboard based on role
    if (role === 'admin') {
      setCurrentView('admin');
    } else if (role === 'employee') {
      setCurrentView('employee');
    } else {
      setCurrentView('dashboard');
    }
  };

  const handleLogout = () => {
    setUserRole(null);
    setCurrentView('website');
  };

  const handleBackToWebsite = () => {
    setCurrentView('website');
  };

  // Render different views based on current state
  if (currentView === 'dashboard') {
    return <ClientDashboard onBack={handleBackToWebsite} />;
  }

  if (currentView === 'admin') {
    return <AdminPanel onBack={handleBackToWebsite} />;
  }

  if (currentView === 'employee') {
    return <EmployeePanel onBack={handleBackToWebsite} />;
  }

  if (currentView === 'software') {
    return <SoftwareStore onBack={handleBackToWebsite} />;
  }

  if (currentView === 'plans') {
    return <SubscriptionPlans onBack={handleBackToWebsite} />;
  }

  if (currentView === 'privacy') {
    return <PrivacyPolicy />;
  }

  if (currentView === 'terms') {
    return <TermsConditions />;
  }

  if (currentView === 'cookies') {
    return <CookiePolicy />;
  }

  if (currentView === 'legal') {
    return <LegalLicensing />;
  }

  if (currentView === 'security') {
    return <SecurityDisclaimer />;
  }

  // Main website view
  return (
    <div className="min-h-screen bg-white">
      <Header 
        isLoggedIn={!!userRole}
        userRole={userRole}
        onLogin={() => setShowLoginModal(true)}
        onLogout={handleLogout}
        onDashboard={() => setCurrentView('dashboard')}
        onAdmin={() => setCurrentView('admin')}
        onEmployee={() => setCurrentView('employee')}
        onSoftware={() => setCurrentView('software')}
        onPlans={() => setCurrentView('plans')}
      />
      <Hero onPlans={() => setCurrentView('plans')} />
      <Services />
      <PromotionalOffer onPlans={() => setCurrentView('plans')} />
      <Footer onPrivacy={() => setCurrentView('privacy')} onTerms={() => setCurrentView('terms')} onCookies={() => setCurrentView('cookies')} onLegal={() => setCurrentView('legal')} onSecurity={() => setCurrentView('security')} />
      <AIAssistant />
      
      <LoginModal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        onLogin={handleLogin}
      />
    </div>
  );
}

export default App;