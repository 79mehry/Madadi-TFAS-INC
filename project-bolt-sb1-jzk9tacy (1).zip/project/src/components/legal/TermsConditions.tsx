import React from 'react';
import { FileText, Scale, AlertTriangle, CreditCard, MapPin } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const TermsConditions: React.FC = () => {
  const { t, language } = useLanguage();
  const isRTL = language === 'fa';

  return (
    <div className={`min-h-screen bg-gray-50 ${isRTL ? 'rtl' : 'ltr'}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-lg flex items-center justify-center">
              <Scale className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-coffee-900">{t('legal.terms.title')}</h1>
              <p className="text-coffee-600">{t('legal.terms.subtitle')}</p>
            </div>
          </div>

          <div className="prose max-w-none">
            <div className="mb-8 p-6 bg-caramel-50 rounded-lg border border-caramel-200">
              <h2 className="text-xl font-semibold text-coffee-900 mb-4">{t('legal.terms.acceptance.title')}</h2>
              <p className="text-coffee-700">{t('legal.terms.acceptance.content')}</p>
            </div>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4 flex items-center">
                <FileText className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.terms.services.title')}
              </h2>
              <div className="space-y-4">
                <p className="text-coffee-700">{t('legal.terms.services.intro')}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-900">{t('legal.terms.services.accounting')}</h4>
                    <ul className="list-disc list-inside text-blue-700 text-sm mt-2 space-y-1">
                      <li>{t('legal.terms.services.bookkeeping')}</li>
                      <li>{t('legal.terms.services.statements')}</li>
                      <li>{t('legal.terms.services.reconciliation')}</li>
                    </ul>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-900">{t('legal.terms.services.tax')}</h4>
                    <ul className="list-disc list-inside text-green-700 text-sm mt-2 space-y-1">
                      <li>{t('legal.terms.services.preparation')}</li>
                      <li>{t('legal.terms.services.filing')}</li>
                      <li>{t('legal.terms.services.planning')}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4 flex items-center">
                <AlertTriangle className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.terms.liability.title')}
              </h2>
              <div className="bg-red-50 p-6 rounded-lg border border-red-200">
                <h4 className="font-semibold text-red-900 mb-3">{t('legal.terms.liability.disclaimer')}</h4>
                <ul className="list-disc list-inside space-y-2 text-red-800 text-sm">
                  <li>{t('legal.terms.liability.professional')}</li>
                  <li>{t('legal.terms.liability.decisions')}</li>
                  <li>{t('legal.terms.liability.accuracy')}</li>
                  <li>{t('legal.terms.liability.thirdParty')}</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.terms.responsibilities.title')}</h2>
              <div className="space-y-4">
                <p className="text-coffee-700">{t('legal.terms.responsibilities.intro')}</p>
                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                  <h4 className="font-semibold text-yellow-900 mb-2">{t('legal.terms.responsibilities.client')}</h4>
                  <ul className="list-disc list-inside space-y-1 text-yellow-800 text-sm">
                    <li>{t('legal.terms.responsibilities.accurate')}</li>
                    <li>{t('legal.terms.responsibilities.timely')}</li>
                    <li>{t('legal.terms.responsibilities.cooperation')}</li>
                    <li>{t('legal.terms.responsibilities.compliance')}</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4 flex items-center">
                <CreditCard className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.terms.payment.title')}
              </h2>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-green-900">{t('legal.terms.payment.terms')}</h4>
                    <ul className="list-disc list-inside text-green-700 text-sm mt-2 space-y-1">
                      <li>{t('legal.terms.payment.monthly')}</li>
                      <li>{t('legal.terms.payment.advance')}</li>
                      <li>{t('legal.terms.payment.late')}</li>
                    </ul>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-blue-900">{t('legal.terms.payment.methods')}</h4>
                    <ul className="list-disc list-inside text-blue-700 text-sm mt-2 space-y-1">
                      <li>{t('legal.terms.payment.credit')}</li>
                      <li>{t('legal.terms.payment.bank')}</li>
                      <li>{t('legal.terms.payment.paypal')}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.terms.refund.title')}</h2>
              <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                <p className="text-purple-800 mb-3">{t('legal.terms.refund.policy')}</p>
                <ul className="list-disc list-inside space-y-2 text-purple-700 text-sm">
                  <li>{t('legal.terms.refund.services')}</li>
                  <li>{t('legal.terms.refund.software')}</li>
                  <li>{t('legal.terms.refund.cancellation')}</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4 flex items-center">
                <MapPin className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.terms.jurisdiction.title')}
              </h2>
              <div className="bg-indigo-50 p-6 rounded-lg border border-indigo-200">
                <p className="text-indigo-800 mb-3">{t('legal.terms.jurisdiction.governing')}</p>
                <ul className="list-disc list-inside space-y-2 text-indigo-700 text-sm">
                  <li>{t('legal.terms.jurisdiction.alberta')}</li>
                  <li>{t('legal.terms.jurisdiction.federal')}</li>
                  <li>{t('legal.terms.jurisdiction.disputes')}</li>
                </ul>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-4">{t('legal.terms.modifications.title')}</h2>
              <p className="text-coffee-700">{t('legal.terms.modifications.content')}</p>
            </section>

            <div className="text-sm text-coffee-500 border-t pt-6">
              <p>{t('legal.terms.lastUpdated')}: {new Date().toLocaleDateString()}</p>
              <p className="mt-2">{t('legal.terms.contact')}: legal@madadi-tfas.com</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsConditions;