import React from 'react';
import { Shield, Lock, CreditCard, Server, Eye, CheckCircle } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const SecurityDisclaimer: React.FC = () => {
  const { t, language } = useLanguage();
  const isRTL = language === 'fa';

  return (
    <div className={`min-h-screen bg-gray-50 ${isRTL ? 'rtl' : 'ltr'}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-lg flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-coffee-900">{t('legal.security.title')}</h1>
              <p className="text-coffee-600">{t('legal.security.subtitle')}</p>
            </div>
          </div>

          <div className="prose max-w-none">
            <div className="mb-8 p-6 bg-green-50 rounded-lg border border-green-200">
              <div className="flex items-center space-x-3 mb-3">
                <CheckCircle className="w-6 h-6 text-green-600" />
                <h2 className="text-xl font-semibold text-green-900">{t('legal.security.commitment.title')}</h2>
              </div>
              <p className="text-green-800">{t('legal.security.commitment.content')}</p>
            </div>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <Lock className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.security.encryption.title')}
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                  <h3 className="text-lg font-semibold text-blue-900 mb-3">{t('legal.security.encryption.ssl')}</h3>
                  <ul className="space-y-2 text-blue-700 text-sm">
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span>{t('legal.security.encryption.tls')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span>{t('legal.security.encryption.certificate')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                      <span>{t('legal.security.encryption.transit')}</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                  <h3 className="text-lg font-semibold text-purple-900 mb-3">{t('legal.security.encryption.data')}</h3>
                  <ul className="space-y-2 text-purple-700 text-sm">
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                      <span>{t('legal.security.encryption.aes')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                      <span>{t('legal.security.encryption.rest')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
                      <span>{t('legal.security.encryption.backup')}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <CreditCard className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.security.payments.title')}
              </h2>
              
              <div className="space-y-6">
                <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                  <h3 className="text-lg font-semibold text-green-900 mb-4">{t('legal.security.payments.processors')}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white p-4 rounded-lg border border-green-300">
                      <h4 className="font-semibold text-green-900 mb-2">Stripe</h4>
                      <ul className="space-y-1 text-green-700 text-sm">
                        <li>• {t('legal.security.payments.pci')}</li>
                        <li>• {t('legal.security.payments.tokenization')}</li>
                        <li>• {t('legal.security.payments.fraud')}</li>
                      </ul>
                    </div>
                    <div className="bg-white p-4 rounded-lg border border-green-300">
                      <h4 className="font-semibold text-green-900 mb-2">PayPal</h4>
                      <ul className="space-y-1 text-green-700 text-sm">
                        <li>• {t('legal.security.payments.secure')}</li>
                        <li>• {t('legal.security.payments.buyer')}</li>
                        <li>• {t('legal.security.payments.encryption')}</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-50 p-6 rounded-lg border border-yellow-200">
                  <h3 className="text-lg font-semibold text-yellow-900 mb-3">{t('legal.security.payments.disclaimer')}</h3>
                  <p className="text-yellow-800 text-sm">{t('legal.security.payments.disclaimerText')}</p>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <Server className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.security.infrastructure.title')}
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-indigo-50 p-6 rounded-lg border border-indigo-200">
                  <h3 className="text-lg font-semibold text-indigo-900 mb-3">{t('legal.security.infrastructure.hosting')}</h3>
                  <ul className="space-y-2 text-indigo-700 text-sm">
                    <li>• {t('legal.security.infrastructure.cloud')}</li>
                    <li>• {t('legal.security.infrastructure.redundancy')}</li>
                    <li>• {t('legal.security.infrastructure.monitoring')}</li>
                  </ul>
                </div>

                <div className="bg-red-50 p-6 rounded-lg border border-red-200">
                  <h3 className="text-lg font-semibold text-red-900 mb-3">{t('legal.security.infrastructure.access')}</h3>
                  <ul className="space-y-2 text-red-700 text-sm">
                    <li>• {t('legal.security.infrastructure.mfa')}</li>
                    <li>• {t('legal.security.infrastructure.rbac')}</li>
                    <li>• {t('legal.security.infrastructure.audit')}</li>
                  </ul>
                </div>

                <div className="bg-teal-50 p-6 rounded-lg border border-teal-200">
                  <h3 className="text-lg font-semibold text-teal-900 mb-3">{t('legal.security.infrastructure.backup')}</h3>
                  <ul className="space-y-2 text-teal-700 text-sm">
                    <li>• {t('legal.security.infrastructure.automated')}</li>
                    <li>• {t('legal.security.infrastructure.geographic')}</li>
                    <li>• {t('legal.security.infrastructure.recovery')}</li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <Eye className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.security.confidentiality.title')}
              </h2>
              
              <div className="bg-orange-50 p-6 rounded-lg border border-orange-200">
                <h3 className="text-lg font-semibold text-orange-900 mb-4">{t('legal.security.confidentiality.professional')}</h3>
                <div className="space-y-4">
                  <p className="text-orange-800">{t('legal.security.confidentiality.description')}</p>
                  <ul className="space-y-2 text-orange-700">
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                      <span>{t('legal.security.confidentiality.privilege')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                      <span>{t('legal.security.confidentiality.disclosure')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                      <span>{t('legal.security.confidentiality.retention')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                      <span>{t('legal.security.confidentiality.disposal')}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6">{t('legal.security.compliance.title')}</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{t('legal.security.compliance.standards')}</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{t('legal.security.compliance.pipeda')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{t('legal.security.compliance.sox')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{t('legal.security.compliance.iso')}</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{t('legal.security.compliance.audits')}</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{t('legal.security.compliance.annual')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{t('legal.security.compliance.penetration')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span>{t('legal.security.compliance.vulnerability')}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6">{t('legal.security.incident.title')}</h2>
              
              <div className="bg-red-50 p-6 rounded-lg border border-red-200">
                <h3 className="text-lg font-semibold text-red-900 mb-3">{t('legal.security.incident.response')}</h3>
                <p className="text-red-800 mb-4">{t('legal.security.incident.description')}</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-red-900 mb-2">{t('legal.security.incident.immediate')}</h4>
                    <ul className="space-y-1 text-red-700 text-sm">
                      <li>• {t('legal.security.incident.containment')}</li>
                      <li>• {t('legal.security.incident.assessment')}</li>
                      <li>• {t('legal.security.incident.notification')}</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-red-900 mb-2">{t('legal.security.incident.followup')}</h4>
                    <ul className="space-y-1 text-red-700 text-sm">
                      <li>• {t('legal.security.incident.investigation')}</li>
                      <li>• {t('legal.security.incident.remediation')}</li>
                      <li>• {t('legal.security.incident.prevention')}</li>
                    </ul>
                  </div>
                </div>
              </div>
            </section>

            <div className="text-sm text-coffee-500 border-t pt-6">
              <p>{t('legal.security.lastUpdated')}: {new Date().toLocaleDateString()}</p>
              <p className="mt-2">{t('legal.security.contact')}: security@madadi-tfas.com</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityDisclaimer;