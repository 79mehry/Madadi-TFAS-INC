import React from 'react';
import { Award, Building, FileCheck, Shield, MapPin, Phone, Mail } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

const LegalLicensing: React.FC = () => {
  const { t, language } = useLanguage();
  const isRTL = language === 'fa';

  return (
    <div className={`min-h-screen bg-gray-50 ${isRTL ? 'rtl' : 'ltr'}`}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="flex items-center space-x-4 mb-8">
            <div className="w-12 h-12 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-lg flex items-center justify-center">
              <Award className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-coffee-900">{t('legal.licensing.title')}</h1>
              <p className="text-coffee-600">{t('legal.licensing.subtitle')}</p>
            </div>
          </div>

          <div className="prose max-w-none">
            <div className="mb-8 p-6 bg-caramel-50 rounded-lg border border-caramel-200">
              <h2 className="text-xl font-semibold text-coffee-900 mb-4">{t('legal.licensing.overview.title')}</h2>
              <p className="text-coffee-700">{t('legal.licensing.overview.content')}</p>
            </div>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <Building className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.licensing.business.title')}
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-50 p-6 rounded-lg border border-blue-200">
                  <h3 className="text-lg font-semibold text-blue-900 mb-3">{t('legal.licensing.business.federal')}</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-blue-700">{t('legal.licensing.business.number')}:</span>
                      <span className="font-mono text-blue-900">123456789RC0001</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-700">{t('legal.licensing.business.status')}:</span>
                      <span className="text-green-600 font-medium">{t('legal.licensing.business.active')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-blue-700">{t('legal.licensing.business.registered')}:</span>
                      <span className="text-blue-900">January 15, 2020</span>
                    </div>
                  </div>
                </div>

                <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                  <h3 className="text-lg font-semibold text-green-900 mb-3">{t('legal.licensing.business.alberta')}</h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-green-700">{t('legal.licensing.business.license')}:</span>
                      <span className="font-mono text-green-900">AB-2020-001234</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-700">{t('legal.licensing.business.status')}:</span>
                      <span className="text-green-600 font-medium">{t('legal.licensing.business.active')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-green-700">{t('legal.licensing.business.expires')}:</span>
                      <span className="text-green-900">December 31, 2024</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <FileCheck className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.licensing.tax.title')}
              </h2>
              
              <div className="bg-purple-50 p-6 rounded-lg border border-purple-200">
                <h3 className="text-lg font-semibold text-purple-900 mb-4">{t('legal.licensing.tax.cra')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-purple-700">{t('legal.licensing.tax.gst')}:</span>
                      <span className="font-mono text-purple-900">123456789RT0001</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-700">{t('legal.licensing.tax.payroll')}:</span>
                      <span className="font-mono text-purple-900">123456789RP0001</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-purple-700">{t('legal.licensing.tax.status')}:</span>
                      <span className="text-green-600 font-medium">{t('legal.licensing.tax.compliant')}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-purple-700">{t('legal.licensing.tax.lastFiled')}:</span>
                      <span className="text-purple-900">December 31, 2023</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <Shield className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.licensing.professional.title')}
              </h2>
              
              <div className="space-y-4">
                <div className="bg-indigo-50 p-6 rounded-lg border border-indigo-200">
                  <h3 className="text-lg font-semibold text-indigo-900 mb-3">{t('legal.licensing.professional.certifications')}</h3>
                  <ul className="space-y-2 text-indigo-700">
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-indigo-600 rounded-full"></div>
                      <span>{t('legal.licensing.professional.cpa')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-indigo-600 rounded-full"></div>
                      <span>{t('legal.licensing.professional.cga')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-indigo-600 rounded-full"></div>
                      <span>{t('legal.licensing.professional.tax')}</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-orange-50 p-6 rounded-lg border border-orange-200">
                  <h3 className="text-lg font-semibold text-orange-900 mb-3">{t('legal.licensing.professional.memberships')}</h3>
                  <ul className="space-y-2 text-orange-700">
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                      <span>{t('legal.licensing.professional.cpaa')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                      <span>{t('legal.licensing.professional.chamber')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-orange-600 rounded-full"></div>
                      <span>{t('legal.licensing.professional.ita')}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6">{t('legal.licensing.compliance.title')}</h2>
              
              <div className="bg-green-50 p-6 rounded-lg border border-green-200">
                <h3 className="text-lg font-semibold text-green-900 mb-4">{t('legal.licensing.compliance.standards')}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <ul className="space-y-2 text-green-700">
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                      <span>{t('legal.licensing.compliance.cra')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                      <span>{t('legal.licensing.compliance.alberta')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                      <span>{t('legal.licensing.compliance.pipeda')}</span>
                    </li>
                  </ul>
                  <ul className="space-y-2 text-green-700">
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                      <span>{t('legal.licensing.compliance.aml')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                      <span>{t('legal.licensing.compliance.professional')}</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <div className="w-2 h-2 bg-green-600 rounded-full"></div>
                      <span>{t('legal.licensing.compliance.ethics')}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </section>

            <section className="mb-8">
              <h2 className="text-2xl font-bold text-coffee-900 mb-6 flex items-center">
                <MapPin className="w-6 h-6 mr-3 text-caramel-600" />
                {t('legal.licensing.contact.title')}
              </h2>
              
              <div className="bg-caramel-50 p-6 rounded-lg border border-caramel-200">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold text-coffee-900 mb-3">{t('legal.licensing.contact.business')}</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Building className="w-4 h-4 text-caramel-600" />
                        <span className="text-coffee-700">Madadi TFAS INC</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4 text-caramel-600" />
                        <span className="text-coffee-700">Calgary, Alberta, Canada</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-coffee-900 mb-3">{t('legal.licensing.contact.info')}</h3>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Phone className="w-4 h-4 text-caramel-600" />
                        <span className="text-coffee-700">+1 (403) 555-0123</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Mail className="w-4 h-4 text-caramel-600" />
                        <span className="text-coffee-700">legal@madadi-tfas.com</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            <div className="text-sm text-coffee-500 border-t pt-6">
              <p>{t('legal.licensing.lastUpdated')}: {new Date().toLocaleDateString()}</p>
              <p className="mt-2">{t('legal.licensing.verification')}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegalLicensing;