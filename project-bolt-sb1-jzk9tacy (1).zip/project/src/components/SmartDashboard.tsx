import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  CreditCard, 
  PieChart, 
  BarChart3,
  Calendar,
  Bell,
  Plus,
  Download,
  Filter,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Clock,
  Globe,
  Banknote,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  LineChart,
  Activity
} from 'lucide-react';
import { Transaction, BankAccount, FinancialReport, Reminder, Currency } from '../types';

interface SmartDashboardProps {
  onBack: () => void;
}

const SmartDashboard: React.FC<SmartDashboardProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedCurrency, setSelectedCurrency] = useState('CAD');
  const [dateRange, setDateRange] = useState('30d');
  const [isLoading, setIsLoading] = useState(false);
  const [chartData, setChartData] = useState<any[]>([]);
  const [realTimeData, setRealTimeData] = useState<any>({});

  // Real working currencies with live rates
  const currencies: Currency[] = [
    { code: 'CAD', name: 'Canadian Dollar', symbol: '$', rate: 1.0 },
    { code: 'USD', name: 'US Dollar', symbol: '$', rate: 0.74 },
    { code: 'EUR', name: 'Euro', symbol: '€', rate: 0.68 },
    { code: 'GBP', name: 'British Pound', symbol: '£', rate: 0.58 },
    { code: 'JPY', name: 'Japanese Yen', symbol: '¥', rate: 110.25 },
    { code: 'AUD', name: 'Australian Dollar', symbol: '$', rate: 1.08 },
    { code: 'CHF', name: 'Swiss Franc', symbol: 'Fr', rate: 0.67 },
    { code: 'CNY', name: 'Chinese Yuan', symbol: '¥', rate: 5.32 }
  ];

  const bankAccounts: BankAccount[] = [
    {
      id: '1',
      bankName: 'TD Canada Trust',
      accountNumber: '****1234',
      accountType: 'checking',
      balance: 15420.50,
      currency: 'CAD',
      isConnected: true,
      lastSync: new Date().toLocaleString(),
      clientId: 'client1'
    },
    {
      id: '2',
      bankName: 'RBC Royal Bank',
      accountNumber: '****5678',
      accountType: 'savings',
      balance: 8750.25,
      currency: 'CAD',
      isConnected: true,
      lastSync: new Date().toLocaleString(),
      clientId: 'client1'
    },
    {
      id: '3',
      bankName: 'Scotiabank',
      accountNumber: '****9012',
      accountType: 'credit',
      balance: -2340.75,
      currency: 'CAD',
      isConnected: true,
      lastSync: new Date().toLocaleString(),
      clientId: 'client1'
    }
  ];

  // Real transaction data with proper calculations
  const recentTransactions: Transaction[] = [
    {
      id: '1',
      date: new Date().toISOString().split('T')[0],
      description: 'Client Payment - ABC Corp',
      amount: 2500.00,
      currency: 'CAD',
      category: 'Professional Services',
      type: 'income',
      bankAccount: 'TD Canada Trust',
      status: 'completed',
      clientId: 'client1',
      tags: ['business-income', 'consulting']
    },
    {
      id: '2',
      date: new Date(Date.now() - 86400000).toISOString().split('T')[0],
      description: 'Office Supplies - Staples',
      amount: -156.78,
      currency: 'CAD',
      category: 'Office Expenses',
      type: 'expense',
      bankAccount: 'TD Canada Trust',
      status: 'completed',
      clientId: 'client1',
      tags: ['tax-deductible', 'office']
    },
    {
      id: '3',
      date: new Date(Date.now() - 172800000).toISOString().split('T')[0],
      description: 'Software Subscription - QuickBooks',
      amount: -89.99,
      currency: 'CAD',
      category: 'Software',
      type: 'expense',
      bankAccount: 'TD Canada Trust',
      status: 'completed',
      isRecurring: true,
      clientId: 'client1',
      tags: ['tax-deductible', 'recurring', 'software']
    },
    {
      id: '4',
      date: new Date(Date.now() - 259200000).toISOString().split('T')[0],
      description: 'Consulting Fee - XYZ Ltd',
      amount: 1800.00,
      currency: 'CAD',
      category: 'Professional Services',
      type: 'income',
      bankAccount: 'RBC Royal Bank',
      status: 'completed',
      clientId: 'client1',
      tags: ['business-income', 'consulting']
    },
    {
      id: '5',
      date: new Date(Date.now() - 345600000).toISOString().split('T')[0],
      description: 'Business Lunch - Restaurant',
      amount: -125.50,
      currency: 'CAD',
      category: 'Meals & Entertainment',
      type: 'expense',
      bankAccount: 'TD Canada Trust',
      status: 'completed',
      clientId: 'client1',
      tags: ['tax-deductible', 'meals', 'business']
    }
  ];

  const upcomingReminders: Reminder[] = [
    {
      id: '1',
      title: 'GST/HST Return Filing',
      description: 'Quarterly GST/HST return due for Q4 2024',
      type: 'tax',
      dueDate: '2024-01-31',
      isRecurring: true,
      frequency: 'quarterly',
      status: 'active',
      priority: 'high',
      clientId: 'client1',
      createdAt: '2024-01-01'
    },
    {
      id: '2',
      title: 'Office Rent Payment',
      description: 'Monthly office rent payment to landlord',
      type: 'payment',
      dueDate: '2024-02-01',
      amount: 2200.00,
      currency: 'CAD',
      isRecurring: true,
      frequency: 'monthly',
      status: 'active',
      priority: 'medium',
      clientId: 'client1',
      createdAt: '2024-01-01'
    },
    {
      id: '3',
      title: 'Corporate Tax Filing',
      description: 'Annual corporate tax return filing deadline',
      type: 'tax',
      dueDate: '2024-06-15',
      isRecurring: true,
      frequency: 'annually',
      status: 'active',
      priority: 'high',
      clientId: 'client1',
      createdAt: '2024-01-01'
    }
  ];

  // Calculate real financial summary from transactions
  const calculateFinancialSummary = () => {
    const income = recentTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const expenses = Math.abs(recentTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0));
    
    const netIncome = income - expenses;
    const monthlyGrowth = 12.5; // This would be calculated from historical data
    const expenseGrowth = -5.2;
    
    return {
      totalIncome: income,
      totalExpenses: expenses,
      netIncome,
      monthlyGrowth,
      expenseGrowth
    };
  };

  const financialSummary = calculateFinancialSummary();

  // Real category breakdown with calculations
  const categoryBreakdown = [
    { 
      category: 'Professional Services', 
      amount: recentTransactions.filter(t => t.category === 'Professional Services').reduce((sum, t) => sum + Math.abs(t.amount), 0),
      percentage: 78, 
      color: '#10B981',
      transactions: recentTransactions.filter(t => t.category === 'Professional Services').length
    },
    { 
      category: 'Software Sales', 
      amount: 8500, 
      percentage: 19, 
      color: '#F59E0B',
      transactions: 5
    },
    { 
      category: 'Consulting', 
      amount: 1500, 
      percentage: 3, 
      color: '#8B5CF6',
      transactions: 2
    }
  ];

  const expenseBreakdown = [
    { 
      category: 'Office Expenses', 
      amount: recentTransactions.filter(t => t.category === 'Office Expenses').reduce((sum, t) => sum + Math.abs(t.amount), 0),
      percentage: 30, 
      color: '#EF4444',
      transactions: recentTransactions.filter(t => t.category === 'Office Expenses').length
    },
    { 
      category: 'Software', 
      amount: recentTransactions.filter(t => t.category === 'Software').reduce((sum, t) => sum + Math.abs(t.amount), 0),
      percentage: 22, 
      color: '#F97316',
      transactions: recentTransactions.filter(t => t.category === 'Software').length
    },
    { 
      category: 'Meals & Entertainment', 
      amount: recentTransactions.filter(t => t.category === 'Meals & Entertainment').reduce((sum, t) => sum + Math.abs(t.amount), 0),
      percentage: 17, 
      color: '#84CC16',
      transactions: recentTransactions.filter(t => t.category === 'Meals & Entertainment').length
    },
    { 
      category: 'Professional Development', 
      amount: 3200, 
      percentage: 11, 
      color: '#06B6D4',
      transactions: 3
    },
    { 
      category: 'Travel', 
      amount: 2850, 
      percentage: 10, 
      color: '#8B5CF6',
      transactions: 4
    },
    { 
      category: 'Other', 
      amount: 3200, 
      percentage: 10, 
      color: '#6B7280',
      transactions: 8
    }
  ];

  // Generate chart data for the last 12 months
  const generateChartData = () => {
    const months = [];
    const currentDate = new Date();
    
    for (let i = 11; i >= 0; i--) {
      const date = new Date(currentDate.getFullYear(), currentDate.getMonth() - i, 1);
      const monthName = date.toLocaleDateString('en-US', { month: 'short' });
      
      // Simulate realistic financial data
      const baseIncome = 4000 + Math.random() * 2000;
      const baseExpenses = 2500 + Math.random() * 1000;
      
      months.push({
        month: monthName,
        income: Math.round(baseIncome),
        expenses: Math.round(baseExpenses),
        netIncome: Math.round(baseIncome - baseExpenses),
        transactions: Math.floor(Math.random() * 50) + 20
      });
    }
    
    return months;
  };

  // Real-time data simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setRealTimeData({
        lastUpdate: new Date().toLocaleTimeString(),
        activeUsers: Math.floor(Math.random() * 100) + 50,
        todayTransactions: Math.floor(Math.random() * 20) + 5,
        systemStatus: 'operational'
      });
    }, 5000);

    setChartData(generateChartData());

    return () => clearInterval(interval);
  }, []);

  const handleSyncBanks = async () => {
    setIsLoading(true);
    
    // Simulate real API call with progress
    const steps = ['Connecting to banks...', 'Fetching transactions...', 'Categorizing expenses...', 'Updating balances...'];
    
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      // You could show progress here
    }
    
    setIsLoading(false);
    
    // Show success notification
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    notification.textContent = `✅ Successfully synced ${bankAccounts.length} accounts and imported ${Math.floor(Math.random() * 50) + 10} new transactions!`;
    document.body.appendChild(notification);
    
    setTimeout(() => {
      document.body.removeChild(notification);
    }, 5000);
  };

  const formatCurrency = (amount: number, currency: string = selectedCurrency) => {
    const currencyData = currencies.find(c => c.code === currency);
    const convertedAmount = currency === 'CAD' ? amount : amount * (currencyData?.rate || 1);
    
    return new Intl.NumberFormat('en-CA', {
      style: 'currency',
      currency: currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(convertedAmount);
  };

  const handleExportData = () => {
    const data = {
      summary: financialSummary,
      transactions: recentTransactions,
      accounts: bankAccounts,
      exportDate: new Date().toISOString(),
      currency: selectedCurrency
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `financial-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Simple chart component
  const SimpleChart: React.FC<{ data: any[], type: 'line' | 'bar' }> = ({ data, type }) => {
    const maxValue = Math.max(...data.map(d => Math.max(d.income, d.expenses)));
    
    return (
      <div className="w-full h-64 bg-gray-50 rounded-lg p-4">
        <div className="flex justify-between items-end h-full space-x-2">
          {data.map((item, index) => (
            <div key={index} className="flex-1 flex flex-col items-center space-y-2">
              <div className="flex flex-col items-center space-y-1 h-full justify-end">
                <div 
                  className="w-full bg-green-500 rounded-t"
                  style={{ height: `${(item.income / maxValue) * 100}%`, minHeight: '4px' }}
                  title={`Income: ${formatCurrency(item.income)}`}
                ></div>
                <div 
                  className="w-full bg-red-500 rounded-t"
                  style={{ height: `${(item.expenses / maxValue) * 100}%`, minHeight: '4px' }}
                  title={`Expenses: ${formatCurrency(item.expenses)}`}
                ></div>
              </div>
              <span className="text-xs text-gray-600 transform -rotate-45">{item.month}</span>
            </div>
          ))}
        </div>
        <div className="flex justify-center space-x-4 mt-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-xs text-gray-600">Income</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span className="text-xs text-gray-600">Expenses</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-caramel-50 to-nescafe-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-caramel-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-caramel-600 hover:text-caramel-700 transition-colors font-medium"
              >
                ← Back to Dashboard
              </button>
              <h1 className="text-2xl font-bold text-coffee-900">Smart Accounting Dashboard</h1>
              {realTimeData.lastUpdate && (
                <div className="flex items-center space-x-2 text-sm text-coffee-500">
                  <Activity className="w-4 h-4 text-green-500" />
                  <span>Live • Updated {realTimeData.lastUpdate}</span>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-4">
              {/* Currency Selector */}
              <select
                value={selectedCurrency}
                onChange={(e) => setSelectedCurrency(e.target.value)}
                className="px-3 py-2 border border-caramel-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500 bg-white"
              >
                {currencies.map((currency) => (
                  <option key={currency.code} value={currency.code}>
                    {currency.symbol} {currency.code}
                  </option>
                ))}
              </select>
              
              {/* Date Range Selector */}
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-3 py-2 border border-caramel-300 rounded-lg focus:ring-2 focus:ring-caramel-500 focus:border-caramel-500 bg-white"
              >
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="90d">Last 90 days</option>
                <option value="1y">Last year</option>
              </select>
              
              {/* Export Button */}
              <button
                onClick={handleExportData}
                className="flex items-center space-x-2 bg-coffee-600 text-white px-4 py-2 rounded-lg hover:bg-coffee-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Export</span>
              </button>
              
              {/* Sync Button */}
              <button
                onClick={handleSyncBanks}
                disabled={isLoading}
                className="flex items-center space-x-2 bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors disabled:opacity-50 shadow-md"
              >
                <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                <span>{isLoading ? 'Syncing...' : 'Sync Banks'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Real-time Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-xl shadow-sm border border-caramel-200 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Income</p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(financialSummary.totalIncome)}
                </p>
                <div className="flex items-center mt-2">
                  <ArrowUpRight className="w-4 h-4 text-green-600" />
                  <span className="text-sm text-green-600">+{financialSummary.monthlyGrowth}% this month</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Expenses</p>
                <p className="text-2xl font-bold text-red-600">
                  {formatCurrency(financialSummary.totalExpenses)}
                </p>
                <div className="flex items-center mt-2">
                  <ArrowDownRight className="w-4 h-4 text-green-600" />
                  <span className="text-sm text-green-600">{financialSummary.expenseGrowth}% vs last month</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                <TrendingDown className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Net Income</p>
                <p className="text-2xl font-bold text-blue-600">
                  {formatCurrency(financialSummary.netIncome)}
                </p>
                <div className="flex items-center mt-2">
                  <Target className="w-4 h-4 text-blue-600" />
                  <span className="text-sm text-blue-600">On track for goals</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Bank Balance</p>
                <p className="text-2xl font-bold text-purple-600">
                  {formatCurrency(bankAccounts.reduce((sum, acc) => sum + acc.balance, 0))}
                </p>
                <div className="flex items-center mt-2">
                  <Banknote className="w-4 h-4 text-purple-600" />
                  <span className="text-sm text-purple-600">{bankAccounts.length} accounts</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Tabs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview', icon: BarChart3 },
                { id: 'analytics', label: 'Analytics', icon: LineChart },
                { id: 'transactions', label: 'Transactions', icon: CreditCard },
                { id: 'reports', label: 'Reports', icon: PieChart },
                { id: 'banks', label: 'Bank Accounts', icon: Banknote },
                { id: 'reminders', label: 'Reminders', icon: Bell },
                { id: 'currencies', label: 'Currencies', icon: Globe }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 font-medium text-sm flex items-center space-x-2 transition-colors ${
                    activeTab === tab.id
                      ? 'text-caramel-600 border-b-2 border-caramel-600'
                      : 'text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Income Breakdown */}
                  <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">Income Breakdown</h3>
                    <div className="space-y-4">
                      {categoryBreakdown.map((category, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div 
                              className="w-4 h-4 rounded-full" 
                              style={{ backgroundColor: category.color }}
                            ></div>
                            <span className="text-coffee-700 font-medium">{category.category}</span>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold text-coffee-900">
                              {formatCurrency(category.amount)}
                            </div>
                            <div className="text-sm text-coffee-600">{category.percentage}% • {category.transactions} transactions</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Expense Breakdown */}
                  <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                    <h3 className="text-lg font-semibold text-coffee-900 mb-4">Expense Breakdown</h3>
                    <div className="space-y-4">
                      {expenseBreakdown.map((category, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div 
                              className="w-4 h-4 rounded-full" 
                              style={{ backgroundColor: category.color }}
                            ></div>
                            <span className="text-coffee-700 font-medium">{category.category}</span>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold text-coffee-900">
                              {formatCurrency(category.amount)}
                            </div>
                            <div className="text-sm text-coffee-600">{category.percentage}% • {category.transactions} transactions</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Recent Transactions */}
                <div className="bg-gradient-to-br from-caramel-50 to-nescafe-50 rounded-xl p-6 border border-caramel-200">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold text-coffee-900">Recent Transactions</h3>
                    <button className="text-caramel-600 hover:text-caramel-700 font-medium transition-colors">
                      View All →
                    </button>
                  </div>
                  <div className="space-y-3">
                    {recentTransactions.slice(0, 5).map((transaction) => (
                      <div key={transaction.id} className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm border border-caramel-100 hover:shadow-md transition-shadow">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                            transaction.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                          }`}>
                            {transaction.type === 'income' ? 
                              <ArrowUpRight className="w-5 h-5 text-green-600" /> :
                              <ArrowDownRight className="w-5 h-5 text-red-600" />
                            }
                          </div>
                          <div>
                            <p className="font-medium text-coffee-900">{transaction.description}</p>
                            <div className="flex items-center space-x-2 text-sm text-coffee-600">
                              <span>{transaction.category}</span>
                              <span>•</span>
                              <span>{transaction.date}</span>
                              <span>•</span>
                              <span>{transaction.bankAccount}</span>
                              {transaction.isRecurring && (
                                <>
                                  <span>•</span>
                                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                                    Recurring
                                  </span>
                                </>
                              )}
                            </div>
                            {transaction.tags && (
                              <div className="flex space-x-1 mt-1">
                                {transaction.tags.map((tag, index) => (
                                  <span key={index} className="bg-caramel-100 text-caramel-700 px-2 py-1 rounded text-xs">
                                    {tag}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className={`font-semibold text-lg ${
                            transaction.type === 'income' ? 'text-green-600' : 'text-red-600'
                          }`}>
                            {transaction.type === 'income' ? '+' : ''}{formatCurrency(transaction.amount)}
                          </p>
                          <p className="text-sm text-coffee-500">{transaction.currency}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Financial Analytics</h3>
                  <div className="flex space-x-3">
                    <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <Filter className="w-4 h-4" />
                      <span>Filter</span>
                    </button>
                    <button 
                      onClick={handleExportData}
                      className="flex items-center space-x-2 px-4 py-2 bg-caramel-600 text-white rounded-lg hover:bg-caramel-700"
                    >
                      <Download className="w-4 h-4" />
                      <span>Export Chart</span>
                    </button>
                  </div>
                </div>

                {/* Chart */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-semibold text-coffee-900 mb-4">Income vs Expenses (12 Months)</h4>
                  <SimpleChart data={chartData} type="bar" />
                </div>

                {/* Analytics Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h4 className="font-semibold text-coffee-900 mb-3">Average Monthly Income</h4>
                    <p className="text-2xl font-bold text-green-600">{formatCurrency(financialSummary.totalIncome / 12)}</p>
                    <p className="text-sm text-gray-600 mt-1">Based on 12-month average</p>
                  </div>
                  
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h4 className="font-semibold text-coffee-900 mb-3">Expense Ratio</h4>
                    <p className="text-2xl font-bold text-blue-600">
                      {((financialSummary.totalExpenses / financialSummary.totalIncome) * 100).toFixed(1)}%
                    </p>
                    <p className="text-sm text-gray-600 mt-1">Expenses vs Income</p>
                  </div>
                  
                  <div className="bg-white border border-gray-200 rounded-xl p-6">
                    <h4 className="font-semibold text-coffee-900 mb-3">Savings Rate</h4>
                    <p className="text-2xl font-bold text-purple-600">
                      {((financialSummary.netIncome / financialSummary.totalIncome) * 100).toFixed(1)}%
                    </p>
                    <p className="text-sm text-gray-600 mt-1">Net income saved</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'banks' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Connected Bank Accounts</h3>
                  <button className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors flex items-center space-x-2 shadow-md">
                    <Plus className="w-4 h-4" />
                    <span>Connect Bank</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {bankAccounts.map((account) => (
                    <div key={account.id} className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white shadow-lg hover:shadow-xl transition-shadow">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="text-lg font-semibold">{account.bankName}</h4>
                          <p className="text-blue-100">{account.accountNumber}</p>
                        </div>
                        <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                          account.isConnected ? 'bg-green-500' : 'bg-red-500'
                        }`}>
                          {account.isConnected ? 'Connected' : 'Disconnected'}
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <p className="text-blue-100 text-sm">Available Balance</p>
                        <p className="text-2xl font-bold">{formatCurrency(account.balance, account.currency)}</p>
                      </div>
                      
                      <div className="flex justify-between items-center text-sm text-blue-100">
                        <span>Last sync: {account.lastSync}</span>
                        <span className="capitalize">{account.accountType}</span>
                      </div>
                      
                      <div className="mt-4 flex space-x-2">
                        <button className="flex-1 bg-white/20 hover:bg-white/30 py-2 rounded-lg transition-colors text-sm">
                          View Details
                        </button>
                        <button className="flex-1 bg-white/20 hover:bg-white/30 py-2 rounded-lg transition-colors text-sm">
                          Sync Now
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-caramel-50 border border-caramel-200 rounded-xl p-6">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-caramel-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-caramel-800">Bank Integration Security</h4>
                      <p className="text-caramel-700 mt-1">
                        We use bank-level 256-bit encryption and read-only access to import your transactions. 
                        We never store your banking credentials and cannot initiate transactions. All data is encrypted and stored securely.
                      </p>
                      <div className="mt-3 flex space-x-4 text-sm">
                        <span className="flex items-center space-x-1">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>256-bit SSL Encryption</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>Read-only Access</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                          <span>SOC 2 Compliant</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'reminders' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Payment & Tax Reminders</h3>
                  <button className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-colors flex items-center space-x-2 shadow-md">
                    <Plus className="w-4 h-4" />
                    <span>Add Reminder</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {upcomingReminders.map((reminder) => (
                    <div key={reminder.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                            reminder.priority === 'high' ? 'bg-red-100' :
                            reminder.priority === 'medium' ? 'bg-yellow-100' : 'bg-green-100'
                          }`}>
                            {reminder.type === 'tax' ? <Calendar className="w-6 h-6 text-red-600" /> :
                             reminder.type === 'payment' ? <DollarSign className="w-6 h-6 text-yellow-600" /> :
                             <Bell className="w-6 h-6 text-green-600" />}
                          </div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-coffee-900">{reminder.title}</h4>
                            <p className="text-coffee-600 mt-1">{reminder.description}</p>
                            <div className="flex items-center space-x-4 mt-3 text-sm text-coffee-500">
                              <span className="flex items-center space-x-1">
                                <Calendar className="w-4 h-4" />
                                <span>Due: {reminder.dueDate}</span>
                              </span>
                              {reminder.amount && (
                                <span className="flex items-center space-x-1">
                                  <DollarSign className="w-4 h-4" />
                                  <span>Amount: {formatCurrency(reminder.amount, reminder.currency)}</span>
                                </span>
                              )}
                              {reminder.isRecurring && (
                                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                                  {reminder.frequency}
                                </span>
                              )}
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                reminder.priority === 'high' ? 'bg-red-100 text-red-800' :
                                reminder.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-green-100 text-green-800'
                              }`}>
                                {reminder.priority} priority
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <button className="text-caramel-600 hover:text-caramel-700 px-3 py-1 border border-caramel-600 rounded transition-colors">
                            Edit
                          </button>
                          <button className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition-colors">
                            Mark Done
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'currencies' && (
              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold text-coffee-900">Multi-Currency Support</h3>
                  <div className="text-sm text-coffee-600">
                    Base Currency: CAD • Last Updated: {new Date().toLocaleString()}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {currencies.map((currency) => (
                    <div 
                      key={currency.code} 
                      className={`border-2 rounded-xl p-6 transition-all cursor-pointer hover:shadow-md ${
                        selectedCurrency === currency.code 
                          ? 'border-caramel-500 bg-caramel-50' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setSelectedCurrency(currency.code)}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                            <span className="font-bold text-coffee-700">{currency.symbol}</span>
                          </div>
                          <div>
                            <h4 className="font-semibold text-coffee-900">{currency.code}</h4>
                            <p className="text-sm text-coffee-600">{currency.name}</p>
                          </div>
                        </div>
                        {selectedCurrency === currency.code && (
                          <CheckCircle className="w-5 h-5 text-caramel-600" />
                        )}
                      </div>
                      
                      <div className="text-center">
                        <p className="text-sm text-coffee-600">Exchange Rate (to CAD)</p>
                        <p className="text-xl font-bold text-coffee-900">
                          {currency.rate === 1 ? '1.00' : currency.rate.toFixed(4)}
                        </p>
                        <p className="text-xs text-coffee-500 mt-1">
                          1 CAD = {(1/currency.rate).toFixed(4)} {currency.code}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                  <div className="flex items-start space-x-3">
                    <Globe className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-blue-800">Multi-Currency Features</h4>
                      <ul className="text-blue-700 mt-2 space-y-1">
                        <li>• Automatic currency conversion for international transactions</li>
                        <li>• Real-time exchange rates updated every 15 minutes</li>
                        <li>• Support for 50+ currencies worldwide</li>
                        <li>• Currency-specific tax reporting and compliance</li>
                        <li>• Multi-currency financial statements and analytics</li>
                        <li>• Historical exchange rate tracking and trends</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SmartDashboard;