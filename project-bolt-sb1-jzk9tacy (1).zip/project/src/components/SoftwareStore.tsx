import React, { useState } from 'react';
import { 
  Package, 
  Star, 
  Download, 
  ShoppingCart, 
  Search, 
  Filter,
  Check,
  ArrowRight,
  CreditCard,
  Shield,
  Headphones
} from 'lucide-react';

interface SoftwareStoreProps {
  onBack: () => void;
}

const SoftwareStore: React.FC<SoftwareStoreProps> = ({ onBack }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<any>(null);

  const handlePurchase = (product: any) => {
    setSelectedProduct(product);
    setShowPaymentModal(true);
  };

  const handlePayment = () => {
    // This would integrate with your payment processor
    alert(`Payment processed for ${selectedProduct.name}! Payment sent to your connected bank account.`);
    setShowPaymentModal(false);
    setSelectedProduct(null);
  };

  const softwareProducts = [
    {
      id: '1',
      name: 'QuickBooks Pro 2024',
      category: 'accounting',
      price: 299,
      originalPrice: 399,
      rating: 4.8,
      reviews: 1250,
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Complete accounting solution for small to medium businesses',
      features: ['Invoice Management', 'Expense Tracking', 'Financial Reports', 'Tax Preparation', 'Inventory Management'],
      popular: true,
      installation: 'Included',
      training: '4 Hours',
      support: '1 Year'
    },
    {
      id: '2',
      name: 'Sage 50 Accounting',
      category: 'accounting',
      price: 449,
      originalPrice: 549,
      rating: 4.6,
      reviews: 890,
      image: 'https://images.pexels.com/photos/6863183/pexels-photo-6863183.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Advanced accounting software with comprehensive features',
      features: ['Advanced Reporting', 'Multi-Currency', 'Job Costing', 'Budgeting', 'Cash Flow Management'],
      popular: false,
      installation: 'Included',
      training: '6 Hours',
      support: '1 Year'
    },
    {
      id: '3',
      name: 'PayrollMate 2024',
      category: 'payroll',
      price: 199,
      originalPrice: 249,
      rating: 4.7,
      reviews: 650,
      image: 'https://images.pexels.com/photos/6863515/pexels-photo-6863515.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Comprehensive payroll management system',
      features: ['Automated Calculations', 'Tax Compliance', 'Direct Deposit', 'Employee Self-Service', 'Reporting'],
      popular: false,
      installation: 'Included',
      training: '3 Hours',
      support: '1 Year'
    },
    {
      id: '4',
      name: 'TaxPrep Professional',
      category: 'tax',
      price: 349,
      originalPrice: 429,
      rating: 4.9,
      reviews: 1100,
      image: 'https://images.pexels.com/photos/6863332/pexels-photo-6863332.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Professional tax preparation software',
      features: ['All Tax Forms', 'E-Filing', 'Audit Support', 'Client Management', 'Error Checking'],
      popular: true,
      installation: 'Included',
      training: '5 Hours',
      support: '1 Year'
    },
    {
      id: '5',
      name: 'CRM Business Suite',
      category: 'crm',
      price: 179,
      originalPrice: 229,
      rating: 4.5,
      reviews: 420,
      image: 'https://images.pexels.com/photos/3184639/pexels-photo-3184639.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Customer relationship management system',
      features: ['Contact Management', 'Sales Pipeline', 'Email Integration', 'Reporting', 'Mobile Access'],
      popular: false,
      installation: 'Included',
      training: '4 Hours',
      support: '1 Year'
    },
    {
      id: '6',
      name: 'Inventory Pro Manager',
      category: 'accounting',
      price: 259,
      originalPrice: 319,
      rating: 4.4,
      reviews: 380,
      image: 'https://images.pexels.com/photos/6863668/pexels-photo-6863668.jpeg?auto=compress&cs=tinysrgb&w=400',
      description: 'Advanced inventory management solution',
      features: ['Real-time Tracking', 'Barcode Scanning', 'Purchase Orders', 'Stock Alerts', 'Multi-Location'],
      popular: false,
      installation: 'Included',
      training: '3 Hours',
      support: '1 Year'
    }
  ];

  const categories = [
    { id: 'all', name: 'All Software', count: softwareProducts.length },
    { id: 'accounting', name: 'Accounting', count: softwareProducts.filter(p => p.category === 'accounting').length },
    { id: 'payroll', name: 'Payroll', count: softwareProducts.filter(p => p.category === 'payroll').length },
    { id: 'tax', name: 'Tax', count: softwareProducts.filter(p => p.category === 'tax').length },
    { id: 'crm', name: 'CRM', count: softwareProducts.filter(p => p.category === 'crm').length }
  ];

  const filteredProducts = softwareProducts.filter(product => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="text-amber-600 hover:text-amber-700 transition-colors"
              >
                ← Back to Website
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Software Store</h1>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <ShoppingCart className="w-6 h-6 text-gray-600" />
                <span className="absolute -top-2 -right-2 w-4 h-4 bg-amber-600 rounded-full text-white text-xs flex items-center justify-center">2</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-amber-600 to-orange-600 rounded-2xl p-8 mb-8 text-white">
          <div className="max-w-3xl">
            <h2 className="text-3xl font-bold mb-4">Professional Accounting Software</h2>
            <p className="text-lg mb-6">
              Get the right software for your business with professional installation, 
              comprehensive training, and ongoing support included.
            </p>
            <div className="flex flex-wrap gap-4">
              <div className="flex items-center space-x-2">
                <Shield className="w-5 h-5" />
                <span>Professional Installation</span>
              </div>
              <div className="flex items-center space-x-2">
                <Check className="w-5 h-5" />
                <span>Complete Training</span>
              </div>
              <div className="flex items-center space-x-2">
                <Headphones className="w-5 h-5" />
                <span>1 Year Support</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-1/4">
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <h3 className="font-semibold text-gray-900 mb-4">Search</h3>
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search software..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                />
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Categories</h3>
              <div className="space-y-2">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setSelectedCategory(category.id)}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                      selectedCategory === category.id
                        ? 'bg-amber-100 text-amber-800'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span>{category.name}</span>
                      <span className="text-sm text-gray-500">{category.count}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:w-3/4">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-semibold text-gray-900">
                {filteredProducts.length} Software Products
              </h3>
              <div className="flex items-center space-x-4">
                <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <Filter className="w-4 h-4" />
                  <span>Filter</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredProducts.map((product) => (
                <div key={product.id} className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition-shadow">
                  {product.popular && (
                    <div className="bg-amber-600 text-white text-center py-1 text-sm font-medium">
                      Most Popular
                    </div>
                  )}
                  
                  <div className="p-6">
                    <div className="flex items-start space-x-4 mb-4">
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-gray-900 mb-1">{product.name}</h4>
                        <p className="text-gray-600 text-sm mb-2">{product.description}</p>
                        <div className="flex items-center space-x-2">
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star 
                                key={i} 
                                className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
                              />
                            ))}
                          </div>
                          <span className="text-sm text-gray-600">({product.reviews})</span>
                        </div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-2xl font-bold text-gray-900">${product.price}</span>
                        {product.originalPrice > product.price && (
                          <span className="text-lg text-gray-500 line-through">${product.originalPrice}</span>
                        )}
                        {product.originalPrice > product.price && (
                          <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                            Save ${product.originalPrice - product.price}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mb-4">
                      <h5 className="font-medium text-gray-900 mb-2">Key Features:</h5>
                      <ul className="space-y-1">
                        {product.features.slice(0, 3).map((feature, index) => (
                          <li key={index} className="flex items-center space-x-2 text-sm text-gray-600">
                            <Check className="w-3 h-3 text-green-600" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mb-4 p-3 bg-amber-50 rounded-lg">
                      <h5 className="font-medium text-amber-800 mb-2">Included Services:</h5>
                      <div className="grid grid-cols-3 gap-2 text-xs text-amber-700">
                        <div className="text-center">
                          <Package className="w-4 h-4 mx-auto mb-1" />
                          <span>{product.installation}</span>
                        </div>
                        <div className="text-center">
                          <Download className="w-4 h-4 mx-auto mb-1" />
                          <span>{product.training}</span>
                        </div>
                        <div className="text-center">
                          <Headphones className="w-4 h-4 mx-auto mb-1" />
                          <span>{product.support}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      <button className="flex-1 bg-amber-600 text-white py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center justify-center space-x-2">
                        <ShoppingCart className="w-4 h-4" />
                        <span>Add to Cart</span>
                      </button>
                      <button 
                        onClick={() => handlePurchase(product)}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center space-x-2"
                      >
                        <CreditCard className="w-4 h-4" />
                        <span>Buy Now</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className="text-center py-12">
                <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No software found</h3>
                <p className="text-gray-600">Try adjusting your search or filter criteria.</p>
              </div>
            )}
          </div>
        </div>

        {/* Payment Modal */}
        {showPaymentModal && selectedProduct && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Complete Purchase</h3>
              <div className="mb-6">
                <h4 className="font-semibold text-gray-900">{selectedProduct.name}</h4>
                <p className="text-2xl font-bold text-amber-600">${selectedProduct.price}</p>
              </div>
              
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Card Number</label>
                  <input
                    type="text"
                    placeholder="1234 5678 9012 3456"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Expiry</label>
                    <input
                      type="text"
                      placeholder="MM/YY"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">CVV</label>
                    <input
                      type="text"
                      placeholder="123"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePayment}
                  className="flex-1 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors"
                >
                  Pay ${selectedProduct.price}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Bottom CTA */}
        <div className="mt-12 bg-white rounded-xl shadow-sm p-8 text-center">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">Need Help Choosing?</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            Our experts can help you select the perfect software solution for your business needs. 
            Get a free consultation and personalized recommendations.
          </p>
          <button className="bg-amber-600 text-white px-8 py-3 rounded-lg hover:bg-amber-700 transition-colors font-semibold">
            Schedule Free Consultation
          </button>
        </div>
      </div>
    </div>
  );
};

export default SoftwareStore;