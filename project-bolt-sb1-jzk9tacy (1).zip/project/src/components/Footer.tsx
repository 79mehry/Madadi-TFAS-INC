import React from 'react';
import { MapPin, Phone, Mail, Clock } from 'lucide-react';

interface FooterProps {
  onPrivacy?: () => void;
  onTerms?: () => void;
  onCookies?: () => void;
  onLegal?: () => void;
  onSecurity?: () => void;
}

const Footer: React.FC<FooterProps> = ({ onPrivacy, onTerms, onCookies, onLegal, onSecurity }) => {
  return (
    <footer className="bg-gradient-to-b from-coffee-900 to-black text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-caramel-500 to-nescafe-500 rounded-lg flex items-center justify-center mr-3 shadow-lg">
                <span className="text-white font-bold text-xl">M</span>
              </div>
              <span className="text-xl font-bold">Madadi TFAS INC</span>
            </div>
            <p className="text-caramel-200 mb-4">
              Professional accounting and financial services in Calgary, Alberta.
              Precision in numbers, vision in finance.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2 text-caramel-200">
              <li><a href="#" className="hover:text-caramel-100 transition-colors">Tax Services</a></li>
              <li><a href="#" className="hover:text-caramel-100 transition-colors">Bookkeeping</a></li>
              <li><a href="#" className="hover:text-caramel-100 transition-colors">Business Consulting</a></li>
              <li><a href="#" className="hover:text-caramel-100 transition-colors">Payroll Services</a></li>
              <li><a href="#" className="hover:text-caramel-100 transition-colors">Company Registration</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Info</h3>
            <div className="space-y-3 text-caramel-200">
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-caramel-300" />
                <span>Calgary, Alberta, Canada</span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-caramel-300" />
                <span>+1 (403) 555-0123</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-caramel-300" />
                <span>info@madadi-tfas.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <Clock className="w-5 h-5 text-caramel-300" />
                <span>Mon-Fri: 9AM-6PM</span>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-caramel-200">
              <li><button onClick={onPrivacy} className="hover:text-caramel-100 transition-colors text-left">Privacy Policy</button></li>
              <li><button onClick={onTerms} className="hover:text-caramel-100 transition-colors text-left">Terms & Conditions</button></li>
              <li><button onClick={onCookies} className="hover:text-caramel-100 transition-colors text-left">Cookie Policy</button></li>
              <li><button onClick={onLegal} className="hover:text-caramel-100 transition-colors text-left">Legal & Licensing</button></li>
              <li><button onClick={onSecurity} className="hover:text-caramel-100 transition-colors text-left">Security</button></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-coffee-700 mt-12 pt-8 text-center text-caramel-200">
          <p>&copy; 2024 Madadi Financial and Accounting Services INC. All rights reserved.</p>
          <p className="mt-2">Licensed in Alberta, Canada | Serving Calgary and surrounding areas</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;