import React, { useState } from 'react';
import { 
  Edit3, 
  Save, 
  X, 
  Image, 
  Type, 
  Palette,
  Eye,
  Code,
  Undo,
  Redo,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  Link
} from 'lucide-react';
import MediaManager from './MediaManager';

interface ContentSection {
  id: string;
  type: 'text' | 'image' | 'hero' | 'service' | 'footer';
  title: string;
  content: any;
  editable: boolean;
}

interface ContentEditorProps {
  onSave?: (sections: ContentSection[]) => void;
}

const ContentEditor: React.FC<ContentEditorProps> = ({ onSave }) => {
  const [contentSections, setContentSections] = useState<ContentSection[]>([
    {
      id: 'hero-title',
      type: 'text',
      title: 'Hero Section - Main Title',
      content: {
        text: 'Precision in Numbers, Vision in Finance',
        fontSize: '4xl',
        color: 'amber-600',
        alignment: 'center',
        fontWeight: 'bold'
      },
      editable: true
    },
    {
      id: 'hero-subtitle',
      type: 'text',
      title: 'Hero Section - Subtitle',
      content: {
        text: 'Madadi Financial and Accounting Services INC - Professional accounting solutions for Calgary businesses',
        fontSize: 'xl',
        color: 'gray-600',
        alignment: 'center',
        fontWeight: 'normal'
      },
      editable: true
    },
    {
      id: 'hero-image',
      type: 'image',
      title: 'Hero Section - Background Image',
      content: {
        url: '/photo_2025-07-15 16.37.18.jpeg',
        alt: 'Professional business meeting',
        caption: 'Hero background image'
      },
      editable: true
    },
    {
      id: 'company-logo',
      type: 'image',
      title: 'Company Logo',
      content: {
        url: '/photo_2025-07-15 16.37.18.jpeg',
        alt: 'Madadi TFAS INC Logo',
        caption: 'Main company logo'
      },
      editable: true
    },
    {
      id: 'services-title',
      type: 'text',
      title: 'Services Section - Title',
      content: {
        text: 'Our Services',
        fontSize: '3xl',
        color: 'gray-900',
        alignment: 'center',
        fontWeight: 'bold'
      },
      editable: true
    },
    {
      id: 'services-description',
      type: 'text',
      title: 'Services Section - Description',
      content: {
        text: 'Comprehensive financial and accounting solutions designed to support your business at every stage',
        fontSize: 'lg',
        color: 'gray-600',
        alignment: 'center',
        fontWeight: 'normal'
      },
      editable: true
    },
    {
      id: 'footer-company-name',
      type: 'text',
      title: 'Footer - Company Name',
      content: {
        text: 'Madadi TFAS INC',
        fontSize: 'xl',
        color: 'white',
        alignment: 'left',
        fontWeight: 'bold'
      },
      editable: true
    },
    {
      id: 'footer-description',
      type: 'text',
      title: 'Footer - Company Description',
      content: {
        text: 'Professional accounting and financial services in Calgary, Alberta. Precision in numbers, vision in finance.',
        fontSize: 'base',
        color: 'gray-400',
        alignment: 'left',
        fontWeight: 'normal'
      },
      editable: true
    },
    {
      id: 'contact-phone',
      type: 'text',
      title: 'Contact - Phone Number',
      content: {
        text: '+1 (403) 555-0123',
        fontSize: 'base',
        color: 'gray-400',
        alignment: 'left',
        fontWeight: 'normal'
      },
      editable: true
    },
    {
      id: 'contact-email',
      type: 'text',
      title: 'Contact - Email Address',
      content: {
        text: 'info@madadi-tfas.com',
        fontSize: 'base',
        color: 'gray-400',
        alignment: 'left',
        fontWeight: 'normal'
      },
      editable: true
    },
    {
      id: 'contact-address',
      type: 'text',
      title: 'Contact - Address',
      content: {
        text: 'Calgary, Alberta, Canada',
        fontSize: 'base',
        color: 'gray-400',
        alignment: 'left',
        fontWeight: 'normal'
      },
      editable: true
    }
  ]);

  const [editingSection, setEditingSection] = useState<ContentSection | null>(null);
  const [showMediaManager, setShowMediaManager] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);

  const handleEditSection = (section: ContentSection) => {
    setEditingSection({ ...section });
  };

  const handleSaveSection = () => {
    if (editingSection) {
      setContentSections(prev => 
        prev.map(section => 
          section.id === editingSection.id ? editingSection : section
        )
      );
      setEditingSection(null);
      onSave?.(contentSections);
    }
  };

  const handleMediaSelect = (media: any) => {
    if (editingSection && editingSection.type === 'image') {
      setEditingSection({
        ...editingSection,
        content: {
          ...editingSection.content,
          url: media.url,
          alt: media.alt,
          caption: media.caption
        }
      });
      setShowMediaManager(false);
    }
  };

  const renderTextEditor = (section: ContentSection) => (
    <div className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Text Content</label>
        <textarea
          value={section.content.text}
          onChange={(e) => setEditingSection({
            ...section,
            content: { ...section.content, text: e.target.value }
          })}
          rows={4}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Font Size</label>
          <select
            value={section.content.fontSize}
            onChange={(e) => setEditingSection({
              ...section,
              content: { ...section.content, fontSize: e.target.value }
            })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          >
            <option value="xs">Extra Small</option>
            <option value="sm">Small</option>
            <option value="base">Base</option>
            <option value="lg">Large</option>
            <option value="xl">Extra Large</option>
            <option value="2xl">2X Large</option>
            <option value="3xl">3X Large</option>
            <option value="4xl">4X Large</option>
            <option value="5xl">5X Large</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Font Weight</label>
          <select
            value={section.content.fontWeight}
            onChange={(e) => setEditingSection({
              ...section,
              content: { ...section.content, fontWeight: e.target.value }
            })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          >
            <option value="normal">Normal</option>
            <option value="medium">Medium</option>
            <option value="semibold">Semi Bold</option>
            <option value="bold">Bold</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Text Color</label>
          <select
            value={section.content.color}
            onChange={(e) => setEditingSection({
              ...section,
              content: { ...section.content, color: e.target.value }
            })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          >
            <option value="gray-900">Dark Gray</option>
            <option value="gray-600">Medium Gray</option>
            <option value="gray-400">Light Gray</option>
            <option value="white">White</option>
            <option value="amber-600">Amber</option>
            <option value="blue-600">Blue</option>
            <option value="green-600">Green</option>
            <option value="red-600">Red</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Alignment</label>
          <select
            value={section.content.alignment}
            onChange={(e) => setEditingSection({
              ...section,
              content: { ...section.content, alignment: e.target.value }
            })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          >
            <option value="left">Left</option>
            <option value="center">Center</option>
            <option value="right">Right</option>
          </select>
        </div>
      </div>
    </div>
  );

  const renderImageEditor = (section: ContentSection) => (
    <div className="space-y-4">
      <div className="text-center">
        <img
          src={section.content.url}
          alt={section.content.alt}
          className="max-w-full h-48 object-cover rounded-lg mx-auto mb-4"
        />
        <button
          onClick={() => setShowMediaManager(true)}
          className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2 mx-auto"
        >
          <Image className="w-4 h-4" />
          <span>Change Image</span>
        </button>
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Alt Text</label>
        <input
          type="text"
          value={section.content.alt}
          onChange={(e) => setEditingSection({
            ...section,
            content: { ...section.content, alt: e.target.value }
          })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          placeholder="Describe this image for accessibility"
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Caption</label>
        <input
          type="text"
          value={section.content.caption}
          onChange={(e) => setEditingSection({
            ...section,
            content: { ...section.content, caption: e.target.value }
          })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
          placeholder="Optional caption"
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Content Editor</h3>
        <div className="flex space-x-3">
          <button
            onClick={() => setPreviewMode(!previewMode)}
            className={`px-4 py-2 rounded-lg transition-colors flex items-center space-x-2 ${
              previewMode ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-700'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>{previewMode ? 'Edit Mode' : 'Preview Mode'}</span>
          </button>
          <button
            onClick={() => onSave?.(contentSections)}
            className="bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors flex items-center space-x-2"
          >
            <Save className="w-4 h-4" />
            <span>Save All Changes</span>
          </button>
        </div>
      </div>

      {/* Content Sections List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {contentSections.map((section) => (
          <div key={section.id} className="bg-white border border-gray-200 rounded-xl p-6">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="font-semibold text-gray-900">{section.title}</h4>
                <p className="text-sm text-gray-500 capitalize">{section.type} content</p>
              </div>
              <button
                onClick={() => handleEditSection(section)}
                className="text-amber-600 hover:text-amber-700 p-2"
              >
                <Edit3 className="w-4 h-4" />
              </button>
            </div>
            
            {section.type === 'text' ? (
              <div className="bg-gray-50 p-3 rounded-lg">
                <p className={`text-${section.content.fontSize} text-${section.content.color} font-${section.content.fontWeight} text-${section.content.alignment}`}>
                  {section.content.text.length > 100 
                    ? section.content.text.substring(0, 100) + '...' 
                    : section.content.text}
                </p>
              </div>
            ) : (
              <div className="bg-gray-50 p-3 rounded-lg">
                <img
                  src={section.content.url}
                  alt={section.content.alt}
                  className="w-full h-32 object-cover rounded"
                />
                <p className="text-xs text-gray-600 mt-2">{section.content.alt}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Edit Modal */}
      {editingSection && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-2xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900">Edit {editingSection.title}</h3>
              <button
                onClick={() => setEditingSection(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            {editingSection.type === 'text' 
              ? renderTextEditor(editingSection)
              : renderImageEditor(editingSection)
            }
            
            <div className="flex space-x-4 mt-6">
              <button
                onClick={() => setEditingSection(null)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveSection}
                className="flex-1 bg-amber-600 text-white px-4 py-2 rounded-lg hover:bg-amber-700 transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Media Manager Modal */}
      {showMediaManager && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 max-w-6xl w-full mx-4 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900">Select Media</h3>
              <button
                onClick={() => setShowMediaManager(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <MediaManager
              onSelectMedia={handleMediaSelect}
              fileTypes={['image/*']}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default ContentEditor;