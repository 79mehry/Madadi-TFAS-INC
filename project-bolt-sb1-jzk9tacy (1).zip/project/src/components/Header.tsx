import React, { useState } from 'react';
import { Menu, X, User, LogOut, Settings, Users, Package, CreditCard } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import LanguageSelector from './LanguageSelector';

interface HeaderProps {
  isLoggedIn: boolean;
  userRole: 'client' | 'admin' | 'employee' | null;
  onLogin: () => void;
  onLogout: () => void;
  onDashboard: () => void;
  onAdmin: () => void;
  onEmployee: () => void;
  onSoftware: () => void;
  onPlans: () => void;
}

const Header: React.FC<HeaderProps> = ({ 
  isLoggedIn, 
  userRole, 
  onLogin, 
  onLogout, 
  onDashboard, 
  onAdmin, 
  onEmployee,
  onSoftware,
  onPlans
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const { t } = useLanguage();

  const getUserMenuItems = () => {
    const items = [];
    
    if (userRole === 'admin') {
      items.push(
        { label: t('header.admin'), icon: Settings, action: onAdmin },
        { label: t('header.employee'), icon: Users, action: onEmployee },
        { label: t('header.dashboard'), icon: User, action: onDashboard }
      );
    } else if (userRole === 'employee') {
      items.push(
        { label: t('header.employee'), icon: Users, action: onEmployee },
        { label: t('header.dashboard'), icon: User, action: onDashboard }
      );
    } else {
      items.push(
        { label: t('header.dashboard'), icon: User, action: onDashboard }
      );
    }
    
    return items;
  };

  return (
    <header className="bg-gradient-to-r from-white to-caramel-50 shadow-lg sticky top-0 z-50 border-b border-caramel-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <img 
                src="/photo_2025-07-15 16.37.18.jpeg" 
                alt="Madadi TFAS INC Logo"
                className="w-16 h-16 rounded-xl mr-4 shadow-xl border-2 border-caramel-200 object-cover"
              />
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-coffee-800">Madadi TFAS INC</span>
                <span className="text-xs text-caramel-600 font-medium">Smart Accounting Solutions</span>
              </div>
            </div>
          </div>

          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-coffee-700 hover:text-caramel-600 transition-colors font-medium">{t('header.home')}</a>
            <a href="#services" className="text-coffee-700 hover:text-caramel-600 transition-colors font-medium">{t('header.services')}</a>
            <button 
              onClick={onSoftware}
              className="text-coffee-700 hover:text-caramel-600 transition-colors font-medium"
            >
              {t('header.software')}
            </button>
            <button 
              onClick={onPlans}
              className="text-coffee-700 hover:text-caramel-600 transition-colors font-medium"
            >
              {t('header.pricing')}
            </button>
            <a href="#contact" className="text-coffee-700 hover:text-caramel-600 transition-colors font-medium">{t('header.contact')}</a>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <LanguageSelector />
            {isLoggedIn ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-all shadow-md"
                >
                  <User className="w-4 h-4" />
                  <span>
                    {userRole === 'admin' ? 'Admin' : userRole === 'employee' ? 'Employee' : 'Client'}
                  </span>
                </button>
                
                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-caramel-200 py-1 z-50">
                    {getUserMenuItems().map((item, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          item.action();
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-4 py-2 text-coffee-700 hover:bg-caramel-50 flex items-center space-x-2 transition-colors"
                      >
                        <item.icon className="w-4 h-4" />
                        <span>{item.label}</span>
                      </button>
                    ))}
                    <hr className="my-1" />
                    <button
                      onClick={() => {
                        onLogout();
                        setShowUserMenu(false);
                      }}
                      className="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50 flex items-center space-x-2 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{t('header.logout')}</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onLogin}
                className="bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-6 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-all shadow-md font-medium"
              >
                {t('header.login')}
              </button>
            )}
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-coffee-700 hover:text-caramel-600 transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-gradient-to-b from-caramel-50 to-white border-t border-caramel-200">
            <div className="px-3 py-2">
              <LanguageSelector />
            </div>
            <a href="#home" className="block px-3 py-2 text-coffee-700 hover:text-caramel-600 transition-colors font-medium">{t('header.home')}</a>
            <a href="#services" className="block px-3 py-2 text-coffee-700 hover:text-caramel-600 transition-colors font-medium">{t('header.services')}</a>
            <button 
              onClick={() => {
                onSoftware();
                setIsMenuOpen(false);
              }}
              className="block w-full text-left px-3 py-2 text-coffee-700 hover:text-caramel-600 transition-colors font-medium"
            >
              {t('header.software')}
            </button>
            <button 
              onClick={() => {
                onPlans();
                setIsMenuOpen(false);
              }}
              className="block w-full text-left px-3 py-2 text-coffee-700 hover:text-caramel-600 transition-colors font-medium"
            >
              {t('header.pricing')}
            </button>
            <a href="#contact" className="block px-3 py-2 text-coffee-700 hover:text-caramel-600 transition-colors font-medium">{t('header.contact')}</a>
            
            {isLoggedIn ? (
              <div className="px-3 py-2 space-y-2">
                {getUserMenuItems().map((item, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      item.action();
                      setIsMenuOpen(false);
                    }}
                    className="w-full text-left bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-4 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-all flex items-center space-x-2 shadow-md"
                  >
                    <item.icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                ))}
                <button
                  onClick={() => {
                    onLogout();
                    setIsMenuOpen(false);
                  }}
                  className="w-full text-left text-red-600 hover:text-red-800 hover:bg-red-50 transition-colors flex items-center space-x-2 px-4 py-2 rounded-lg"
                >
                  <LogOut className="w-4 h-4" />
                  <span>{t('header.logout')}</span>
                </button>
              </div>
            ) : (
              <div className="px-3 py-2">
                <button
                  onClick={() => {
                    onLogin();
                    setIsMenuOpen(false);
                  }}
                  className="w-full bg-gradient-to-r from-caramel-500 to-nescafe-500 text-white px-6 py-2 rounded-lg hover:from-caramel-600 hover:to-nescafe-600 transition-all shadow-md font-medium"
                >
                  {t('header.login')}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;